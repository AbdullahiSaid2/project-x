# Prop Dual Mode Lifecycle Simulator V2

This package replaces:

```text
src/strategies/manual/researched_prop_trend/prop_dual_mode_lifecycle_simulator.py
```

## Adds

```text
--eval-risk-multiplier
--pa-risk-multiplier
--target-payout-frequency-days
--min-weekly-payout-amount
--aggressive-eval-until-pass
```

## New output

```text
dual_mode_payout_cycles.csv
```

This measures whether the PA account is hitting the desired payout cadence, such as weekly.

## Run aggressive eval + safer PA

```bash
PYTHONPATH=. python -m src.strategies.manual.researched_prop_trend.prop_dual_mode_lifecycle_simulator \
  --trade-log src/backtesting/event_engine/outputs/ict_fractal_v2_quality_be_partial_no_mym_long_event_trade_log.csv \
  --profile apex_50k_dual_mode \
  --eval-risk-multiplier 2.0 \
  --pa-risk-multiplier 1.0 \
  --target-payout-frequency-days 7 \
  --min-weekly-payout-amount 1000 \
  --aggressive-eval-until-pass
```

## What to check

```bash
cat src/strategies/manual/researched_prop_trend/dual_mode_outputs/dual_mode_cycles.csv
cat src/strategies/manual/researched_prop_trend/dual_mode_outputs/dual_mode_payouts.csv
cat src/strategies/manual/researched_prop_trend/dual_mode_outputs/dual_mode_payout_cycles.csv
```
