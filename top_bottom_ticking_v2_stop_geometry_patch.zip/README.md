
# Top Bottom Ticking V2 — Wider Stop Geometry Patch

This patch widens the structure stops so MNQ and other symbols
can survive normal ICT retracement behaviour before expansion.

## Main change

OLD:

MNQ:
  min_stop = 6
  max_stop = 30

NEW:

MNQ:
  min_stop = 12
  max_stop = 45

## Recommended command

PYTHONPATH=. python -m src.backtesting.event_engine.run_event_backtest \
  --strategy top_bottom_ticking_v2 \
  --symbols MNQ \
  --prop-profile apex_50k_pa \
  --days-back 365 \
  --timeframe 1m \
  --no-tail \
  --commission-per-contract-side 2.0 \
  --target-r 5.0 \
  --min-planned-target-dollars 500 \
  --disable-account-drawdown-lock \
  --news-events src/strategies/manual/researched_prop_trend/news_events.csv \
  --output-prefix top_bottom_ticking_v2_wide_stop_mnq_365_raw

Expected effect:

- fewer premature stopouts
- lower fake MSS failures
- improved winrate
- lower RR but better payout consistency
