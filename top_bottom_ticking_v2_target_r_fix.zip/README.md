# Top Bottom Ticking V2 Target-R Fix

This fixes an important bug:

```text
You ran --target-r 2.0,
but V2 was still hardcoded to use 4R targets.
```

This package replaces:

```text
src/strategies/manual/ict_top_bottom_ticking_v2.py
src/strategies/adapters/top_bottom_ticking_v2_event_adapter.py
```

It also includes a small patch note for:

```text
src/backtesting/event_engine/run_event_backtest.py
```

## Install

```bash
cd /Users/Abdullahi/trading-project/trading_system

unzip /path/to/top_bottom_ticking_v2_target_r_fix.zip -d /tmp/tbt_v2_targetr

cp -R /tmp/tbt_v2_targetr/src/* src/
```

## Patch run_event_backtest.py

Find this line:

```python
df = adapter.build_features(sym, df)
```

Replace with:

```python
if hasattr(adapter, "build_features_with_args"):
    df = adapter.build_features_with_args(sym, df, args)
else:
    df = adapter.build_features(sym, df)
```

## Recommended smoke test

Because 2R with $150 risk is about $300 planned target, use:

```bash
PYTHONPATH=. python -m src.backtesting.event_engine.run_event_backtest \
  --strategy top_bottom_ticking_v2 \
  --symbols MNQ \
  --prop-profile apex_50k_pa \
  --days-back 60 \
  --timeframe 1m \
  --no-tail \
  --commission-per-contract-side 2.0 \
  --target-r 2.0 \
  --min-planned-target-dollars 250 \
  --news-events src/strategies/manual/researched_prop_trend/news_events.csv \
  --output-prefix top_bottom_ticking_v2_targetr_smoke
```
