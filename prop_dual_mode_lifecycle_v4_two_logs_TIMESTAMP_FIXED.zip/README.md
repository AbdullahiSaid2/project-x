# Prop Dual Mode Lifecycle Simulator V4 Timestamp Fixed

Fixes two-log simulator timestamp leakage.

Install:
cd /Users/Abdullahi/trading-project/trading_system
unzip /path/to/prop_dual_mode_lifecycle_v4_two_logs_TIMESTAMP_FIXED.zip -d /tmp/lifecycle_v4_ts
cp -R /tmp/lifecycle_v4_ts/src/* src/

Run the same two-log command again.
