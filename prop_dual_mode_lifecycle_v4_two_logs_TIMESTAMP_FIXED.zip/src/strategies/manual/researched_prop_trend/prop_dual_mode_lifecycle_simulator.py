import argparse
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import pandas as pd
import yaml


# ============================================================
# DATA CLASSES
# ============================================================

@dataclass
class EvalConfig:
    account_size: float
    profit_target: float
    max_drawdown: float
    drawdown_type: str

    risk_per_trade: float
    daily_profit_target: float
    daily_soft_loss_stop: float
    max_trades_per_day: int
    pause_after_consecutive_losses: int


@dataclass
class PAConfig:
    account_size: float
    max_drawdown: float
    drawdown_type: str

    risk_per_trade: float
    daily_profit_target: float
    daily_soft_loss_stop: float
    max_trades_per_day: int
    pause_after_consecutive_losses: int

    payout_buffer: float
    payout_lock_days: int

    reduce_risk_after_payout: bool
    reduced_risk_per_trade: float


@dataclass
class DualModeProfile:
    name: str
    eval: EvalConfig
    pa: PAConfig


# ============================================================
# HELPERS
# ============================================================

def load_profiles(profile_path: str) -> dict:

    with open(profile_path, "r") as f:
        raw = yaml.safe_load(f)

    out = {}

    for name, cfg in raw.items():

        eval_cfg = EvalConfig(**cfg["eval"])
        pa_cfg = PAConfig(**cfg["pa"])

        out[name] = DualModeProfile(
            name=name,
            eval=eval_cfg,
            pa=pa_cfg,
        )

    return out


# ============================================================
# TRADE LOG LOADER
# ============================================================

def load_trade_log(path: str) -> pd.DataFrame:
    """
    Load a trade log from either the older research backtests or the newer
    event engine.

    Important fix:
        Event-engine logs use columns such as exit_time_et / entry_time_et.
        These values can contain mixed timezone offsets around DST changes.
        Pandas may parse that as object dtype unless utc=True is used, which
        then breaks `.dt.date`.

    This function therefore:
        1. Preferentially uses exit_time_et / exit_time for closed-trade date.
        2. Parses timestamps with utc=True and errors="coerce".
        3. Drops rows where timestamp parsing failed.
        4. Normalizes PnL to a common `pnl` column.
    """

    df = pd.read_csv(path)

    # Prefer exit timestamp because payout/eval lifecycle should be based on
    # when the trade actually realized PnL.
    timestamp_candidates = [
        # NEW EVENT ENGINE
        "exit_time_et",
        "exit_time",
        "exit_timestamp",
        "closed_at",

        # FALLBACKS
        "timestamp",
        "entry_time_et",
        "entry_time",
        "entry_timestamp",
        "opened_at",
    ]

    pnl_candidates = [
        "net_pnl_dollars",
        "net_pnl",
        "pnl",
        "realized_pnl",
    ]

    timestamp_col = None
    pnl_col = None

    # =====================================================
    # FIND TIMESTAMP COLUMN
    # =====================================================

    for col in timestamp_candidates:
        if col in df.columns:
            timestamp_col = col
            break

    if timestamp_col is None:
        print("\nAvailable columns:")
        print(df.columns.tolist())
        raise ValueError("No timestamp column found")

    # =====================================================
    # FIND PNL COLUMN
    # =====================================================

    for col in pnl_candidates:
        if col in df.columns:
            pnl_col = col
            break

    if pnl_col is None:
        print("\nAvailable columns:")
        print(df.columns.tolist())
        raise ValueError("No pnl column found")

    # =====================================================
    # NORMALIZE
    # =====================================================

    df["timestamp"] = pd.to_datetime(
        df[timestamp_col],
        utc=True,
        errors="coerce",
    )

    bad_timestamp_rows = int(df["timestamp"].isna().sum())
    if bad_timestamp_rows:
        print(
            f"⚠️ Dropping {bad_timestamp_rows} rows with unparseable timestamps "
            f"from column {timestamp_col!r}"
        )

    df = df.dropna(subset=["timestamp"]).copy()

    df["pnl"] = pd.to_numeric(
        df[pnl_col],
        errors="coerce",
    ).fillna(0.0)

    df = df.sort_values("timestamp").reset_index(drop=True)

    # `.dt` is safe now because utc=True guarantees datetime64[ns, UTC].
    df["trade_date"] = df["timestamp"].dt.date

    return df


# ============================================================
# MAIN SIMULATOR
# ============================================================

class DualModeLifecycleSimulator:

    def __init__(
        self,
        df: pd.DataFrame,
        profile: DualModeProfile,
        pa_df: pd.DataFrame | None = None,
        eval_risk_multiplier: float = 1.0,
        pa_risk_multiplier: float = 1.0,
        target_payout_frequency_days: int = 7,
        min_weekly_payout_amount: float = 1000.0,
        pa_min_payout_trading_days: int = 5,
        pa_consistency_rule_pct: float = 50.0,
        pa_min_payout_amount: float = 250.0,
        pa_max_payout_amount: float = 2000.0,
        aggressive_eval_until_pass: bool = False,
    ):

        self.df = df
        self.pa_df = pa_df
        self.profile = profile

        self.eval_risk_multiplier = float(eval_risk_multiplier)
        self.pa_risk_multiplier = float(pa_risk_multiplier)
        self.target_payout_frequency_days = int(target_payout_frequency_days)
        self.min_weekly_payout_amount = float(min_weekly_payout_amount)
        self.pa_min_payout_trading_days = int(pa_min_payout_trading_days)
        self.pa_consistency_rule_pct = float(pa_consistency_rule_pct)
        self.pa_min_payout_amount = float(pa_min_payout_amount)
        self.pa_max_payout_amount = float(pa_max_payout_amount)
        self.aggressive_eval_until_pass = bool(aggressive_eval_until_pass)

        self.cycles = []
        self.events = []
        self.daily_rows = []
        self.payout_rows = []
        self.payout_cycle_rows = []

    # ========================================================

    def log_event(self, ts, event_type, cycle_id, details=None):

        self.events.append({
            "timestamp": ts,
            "event_type": event_type,
            "cycle_id": cycle_id,
            "details": details,
        })

    # ========================================================

    def run(self):

        eval_trades = self.df.to_dict("records")
        pa_trades = (
            self.pa_df.to_dict("records")
            if self.pa_df is not None
            else eval_trades
        )

        idx = 0
        cycle_id = 1

        while idx < len(eval_trades):

            result = self.run_single_cycle(
                trades=eval_trades,
                pa_trades=pa_trades,
                start_idx=idx,
                cycle_id=cycle_id,
            )

            self.cycles.append(result["cycle"])

            idx = result["next_idx"]

            cycle_id += 1

        return self.build_summary()

    # ========================================================

    def run_single_cycle(
        self,
        trades,
        pa_trades,
        start_idx,
        cycle_id,
    ):

        mode = "eval"

        def advance_current_mode():
            nonlocal current_idx, pa_idx

            if mode == "eval":
                current_idx += 1
            else:
                pa_idx += 1

        eval_cfg = self.profile.eval
        pa_cfg = self.profile.pa

        balance = eval_cfg.account_size

        high_watermark = balance

        current_idx = start_idx
        eval_next_idx = start_idx + 1
        pa_idx = 0

        current_day = None

        daily_pnl = 0.0
        daily_trade_count = 0
        consecutive_losses = 0
        trading_locked = False

        payout_count = 0
        payout_total = 0.0

        payout_lock_days_remaining = 0

        pa_start_balance = None
        eval_start_ts = trades[start_idx]["timestamp"]
        eval_pass_ts = None
        pa_start_ts = None
        last_payout_ts = None
        pa_first_trade_ts = None

        eval_trade_count = 0
        pa_trade_count = 0
        eval_active_days = set()
        pa_active_days = set()

        weekly_cycle_start_ts = None
        weekly_cycle_start_balance = None
        weekly_cycle_trade_count = 0
        weekly_cycle_active_days = set()
        weekly_cycle_day_pnls = {}
        weekly_cycle_number = 1
        last_ts_seen = trades[start_idx]["timestamp"]

        self.log_event(
            trades[start_idx]["timestamp"],
            "EVAL_STARTED",
            cycle_id,
        )

        max_loop_iterations = (len(trades) + len(pa_trades) + 10) * 5
        loop_iterations = 0

        while True:
            loop_iterations += 1
            if loop_iterations > max_loop_iterations:
                raise RuntimeError(
                    "Lifecycle simulator loop guard triggered. "
                    "This usually means an index was not advanced in two-log mode."
                )

            if mode == "eval":
                if current_idx >= len(trades):
                    break
                trade = trades[current_idx]
            else:
                while (
                    pa_idx < len(pa_trades)
                    and pa_start_ts is not None
                    and pa_trades[pa_idx]["timestamp"] < pa_start_ts
                ):
                    pa_idx += 1

                if pa_idx >= len(pa_trades):
                    break

                trade = pa_trades[pa_idx]

            ts = trade["timestamp"]

            if mode == "pa" and pa_start_ts is not None and ts < pa_start_ts:
                raise RuntimeError(
                    f"PA timestamp leak: trade timestamp {ts} is before PA start {pa_start_ts}"
                )
            last_ts_seen = ts
            pnl = float(trade["pnl"])
            trade_day = trade["trade_date"]

            # =================================================
            # NEW DAY RESET
            # =================================================

            if current_day != trade_day:

                current_day = trade_day

                daily_pnl = 0.0
                daily_trade_count = 0
                consecutive_losses = 0
                trading_locked = False

                if payout_lock_days_remaining > 0:
                    payout_lock_days_remaining -= 1

                # Weekly payout-cycle measurement. This does not block trading;
                # it records whether the PA account is on pace for the desired
                # payout rhythm, for example every 7 days.
                if (
                    mode == "pa"
                    and weekly_cycle_start_ts is not None
                    and self.target_payout_frequency_days > 0
                ):
                    days_elapsed = (
                        pd.Timestamp(ts).date()
                        - pd.Timestamp(weekly_cycle_start_ts).date()
                    ).days

                    if days_elapsed >= self.target_payout_frequency_days:
                        cycle_pnl = balance - float(weekly_cycle_start_balance)

                        self.payout_cycle_rows.append({
                            "cycle_id": cycle_id,
                            "pa_start_timestamp": pa_start_ts,
                            "timestamp_valid": (
                                pa_start_ts is None or ts >= pa_start_ts
                            ),
                            "weekly_cycle_number": weekly_cycle_number,
                            "cycle_start": weekly_cycle_start_ts,
                            "cycle_end": ts,
                            "target_frequency_days": self.target_payout_frequency_days,
                            "calendar_days": days_elapsed,
                            "active_trading_days": len(weekly_cycle_active_days),
                            "trades": weekly_cycle_trade_count,
                            "cycle_pnl": cycle_pnl,
                            "target_met": cycle_pnl >= self.min_weekly_payout_amount,
                            "min_weekly_payout_amount": self.min_weekly_payout_amount,
                            "payout_triggered": False,
                            "payout_amount": 0.0,
                            "best_payout_cycle_day": (
                                max(weekly_cycle_day_pnls.values())
                                if weekly_cycle_day_pnls else 0.0
                            ),
                            "consistency_rule_pct": self.pa_consistency_rule_pct,
                            "min_trading_days_required": self.pa_min_payout_trading_days,
                            "min_payout_amount": self.pa_min_payout_amount,
                            "max_payout_amount": self.pa_max_payout_amount,
                        })

                        weekly_cycle_number += 1
                        weekly_cycle_start_ts = ts
                        weekly_cycle_start_balance = balance
                        weekly_cycle_trade_count = 0
                        weekly_cycle_active_days = set()
                        weekly_cycle_day_pnls = {}

            # =================================================
            # CONFIG
            # =================================================

            if mode == "eval":
                cfg = eval_cfg
            else:
                cfg = pa_cfg

            # =================================================
            # DAY LOCKS
            # =================================================

            if trading_locked:
                advance_current_mode()
                continue

            if daily_trade_count >= cfg.max_trades_per_day:

                trading_locked = True

                self.log_event(
                    ts,
                    "MAX_TRADES_DAY_LOCK",
                    cycle_id,
                )

                advance_current_mode()
                continue

            if daily_pnl <= -cfg.daily_soft_loss_stop:

                trading_locked = True

                self.log_event(
                    ts,
                    "DAILY_SOFT_LOSS_LOCK",
                    cycle_id,
                )

                advance_current_mode()
                continue

            # =================================================
            # POST-PAYOUT RISK REDUCTION
            # =================================================

            effective_risk = cfg.risk_per_trade

            if mode == "eval":
                # Aggressive eval mode: scale risk only during evaluation so
                # the account can pass faster. PA mode can then be safer.
                effective_risk = effective_risk * self.eval_risk_multiplier

            if mode == "pa":
                effective_risk = effective_risk * self.pa_risk_multiplier

                if (
                    payout_lock_days_remaining > 0
                    and pa_cfg.reduce_risk_after_payout
                ):
                    effective_risk = min(
                        effective_risk,
                        pa_cfg.reduced_risk_per_trade
                    )

                retained_profit = balance - pa_start_balance

                if retained_profit >= 2000:
                    effective_risk = min(
                        effective_risk,
                        pa_cfg.reduced_risk_per_trade
                    )

            # =================================================
            # APPLY TRADE
            # =================================================

            scale_factor = effective_risk / 150.0

            scaled_pnl = pnl * scale_factor

            balance += scaled_pnl

            daily_pnl += scaled_pnl

            daily_trade_count += 1

            if mode == "eval":
                eval_trade_count += 1
                eval_active_days.add(trade_day)
            else:
                pa_trade_count += 1
                pa_active_days.add(trade_day)

                if pa_first_trade_ts is None:
                    pa_first_trade_ts = ts

                if weekly_cycle_start_ts is None:
                    weekly_cycle_start_ts = ts
                    weekly_cycle_start_balance = balance - scaled_pnl
                    weekly_cycle_trade_count = 0
                    weekly_cycle_active_days = set()
                    weekly_cycle_day_pnls = {}
                    weekly_cycle_day_pnls = {}

                weekly_cycle_trade_count += 1
                weekly_cycle_active_days.add(trade_day)
                weekly_cycle_day_pnls[trade_day] = (
                    weekly_cycle_day_pnls.get(trade_day, 0.0)
                    + scaled_pnl
                )

            # =================================================
            # CONSECUTIVE LOSSES
            # =================================================

            if scaled_pnl < 0:
                consecutive_losses += 1
            else:
                consecutive_losses = 0

            if (
                consecutive_losses
                >= cfg.pause_after_consecutive_losses
            ):

                trading_locked = True

                self.log_event(
                    ts,
                    "CONSECUTIVE_LOSS_LOCK",
                    cycle_id,
                )

            # =================================================
            # DAILY PROFIT LOCK
            # =================================================

            if daily_pnl >= cfg.daily_profit_target:

                trading_locked = True

                self.log_event(
                    ts,
                    "DAILY_PROFIT_TARGET_LOCK",
                    cycle_id,
                )

            # =================================================
            # DRAWDOWN
            # =================================================

            high_watermark = max(
                high_watermark,
                balance,
            )

            drawdown = balance - high_watermark

            # =================================================
            # EVAL MODE
            # =================================================

            if mode == "eval":

                if drawdown <= -eval_cfg.max_drawdown:

                    self.log_event(
                        ts,
                        "EVAL_FAILED_MAX_LOSS",
                        cycle_id,
                    )

                    return {
                        "next_idx": current_idx + 1,
                        "cycle": {
                            "cycle_id": cycle_id,
                            "next_eval_idx": current_idx + 1,
                            "result": "eval_failed",
                            "eval_passed": False,
                            "pa_blown": False,
                            "payout_count": 0,
                            "payout_total": 0.0,
                            "final_balance": balance,
                            "net_pnl": (
                                balance
                                - eval_cfg.account_size
                            ),
                            "eval_start": eval_start_ts,
                            "eval_end": ts,
                            "eval_calendar_days": (
                                pd.Timestamp(ts).date()
                                - pd.Timestamp(eval_start_ts).date()
                            ).days,
                            "eval_active_days": len(eval_active_days),
                            "eval_trades": eval_trade_count,
                            "pa_start": None,
                            "pa_calendar_days": 0,
                            "pa_active_days": 0,
                            "pa_trades": 0,
                        }
                    }

                if balance >= (
                    eval_cfg.account_size
                    + eval_cfg.profit_target
                ):

                    mode = "pa"

                    eval_pass_ts = ts
                    pa_start_ts = ts
                    pa_start_balance = balance
                    eval_next_idx = current_idx + 1

                    # Start the PA cursor at the first PA-log trade at or
                    # after PA start. This prevents reusing old PA trades.
                    pa_idx = 0
                    while (
                        pa_idx < len(pa_trades)
                        and pa_trades[pa_idx]["timestamp"] < pa_start_ts
                    ):
                        pa_idx += 1

                    weekly_cycle_start_ts = ts
                    weekly_cycle_start_balance = balance
                    weekly_cycle_trade_count = 0
                    weekly_cycle_active_days = set()
                    weekly_cycle_day_pnls = {}

                    high_watermark = balance

                    self.log_event(
                        ts,
                        "EVAL_PASSED",
                        cycle_id,
                    )

                    self.log_event(
                        ts,
                        "PA_STARTED",
                        cycle_id,
                    )

            # =================================================
            # PA MODE
            # =================================================

            else:

                if drawdown <= -pa_cfg.max_drawdown:

                    self.log_event(
                        ts,
                        "PA_BLOWN_MAX_LOSS",
                        cycle_id,
                    )

                    return {
                        "next_idx": eval_next_idx,
                        "cycle": {
                            "cycle_id": cycle_id,
                            "next_eval_idx": eval_next_idx,
                            "result": "pa_blown",
                            "eval_passed": True,
                            "pa_blown": True,
                            "payout_count": payout_count,
                            "payout_total": payout_total,
                            "final_balance": balance,
                            "net_pnl": (
                                balance
                                - pa_start_balance
                            ),
                            "eval_start": eval_start_ts,
                            "eval_end": eval_pass_ts,
                            "eval_calendar_days": (
                                pd.Timestamp(eval_pass_ts).date()
                                - pd.Timestamp(eval_start_ts).date()
                            ).days if eval_pass_ts is not None else None,
                            "eval_active_days": len(eval_active_days),
                            "eval_trades": eval_trade_count,
                            "pa_start": pa_start_ts,
                            "pa_end": ts,
                            "pa_calendar_days": (
                                pd.Timestamp(ts).date()
                                - pd.Timestamp(pa_start_ts).date()
                            ).days if pa_start_ts is not None else 0,
                            "pa_active_days": len(pa_active_days),
                            "pa_trades": pa_trade_count,
                        }
                    }

                # =============================================
                # PAYOUT PROTECTION
                # =============================================

                retained_profit = (
                    balance - pa_start_balance
                )

                if retained_profit >= 2500:

                    trading_locked = True

                    self.log_event(
                        ts,
                        "PA_PROFIT_LOCK",
                        cycle_id,
                    )

                # =============================================
                # PAYOUT LOGIC
                # =============================================

                available_payout = max(
                    0.0,
                    retained_profit - pa_cfg.payout_buffer,
                )

                payout_cycle_profit = 0.0
                if weekly_cycle_start_balance is not None:
                    payout_cycle_profit = max(
                        0.0,
                        balance - float(weekly_cycle_start_balance),
                    )

                best_payout_cycle_day = (
                    max(weekly_cycle_day_pnls.values())
                    if weekly_cycle_day_pnls else 0.0
                )

                consistency_limit = (
                    payout_cycle_profit
                    * (self.pa_consistency_rule_pct / 100.0)
                )

                consistency_ok = (
                    payout_cycle_profit <= 0
                    or best_payout_cycle_day <= consistency_limit
                )

                min_days_ok = (
                    len(weekly_cycle_active_days)
                    >= self.pa_min_payout_trading_days
                )

                min_payout_ok = (
                    available_payout >= self.pa_min_payout_amount
                )

                if (
                    min_days_ok
                    and consistency_ok
                    and min_payout_ok
                ):

                    payout_amount = min(
                        available_payout,
                        self.pa_max_payout_amount,
                    )

                    payout_total += payout_amount

                    payout_count += 1

                    balance -= payout_amount

                    payout_lock_days_remaining = (
                        pa_cfg.payout_lock_days
                    )

                    days_since_pa_start = (
                        pd.Timestamp(ts).date()
                        - pd.Timestamp(pa_start_ts).date()
                    ).days if pa_start_ts is not None else None

                    days_since_last_payout = (
                        pd.Timestamp(ts).date()
                        - pd.Timestamp(last_payout_ts).date()
                    ).days if last_payout_ts is not None else days_since_pa_start

                    if pa_start_ts is not None and ts < pa_start_ts:
                        raise RuntimeError(
                            f"Invalid payout timestamp {ts}: before PA start {pa_start_ts}"
                        )

                    self.payout_rows.append({
                        "cycle_id": cycle_id,
                        "timestamp": ts,
                        "pa_start_timestamp": pa_start_ts,
                        "timestamp_valid": (
                            pa_start_ts is None or ts >= pa_start_ts
                        ),
                        "payout_number": payout_count,
                        "payout_amount": payout_amount,
                        "days_since_pa_start": days_since_pa_start,
                        "days_since_last_payout": days_since_last_payout,
                        "pa_trades_to_payout": pa_trade_count,
                        "pa_active_days_to_payout": len(pa_active_days),
                        "payout_cycle_active_days": len(weekly_cycle_active_days),
                        "payout_cycle_trades": weekly_cycle_trade_count,
                        "payout_cycle_profit": payout_cycle_profit,
                        "best_payout_cycle_day": best_payout_cycle_day,
                        "consistency_limit": consistency_limit,
                        "consistency_ok": consistency_ok,
                        "min_days_ok": min_days_ok,
                        "min_payout_ok": min_payout_ok,
                        "min_payout_amount": self.pa_min_payout_amount,
                        "max_payout_amount": self.pa_max_payout_amount,
                        "consistency_rule_pct": self.pa_consistency_rule_pct,
                    })

                    if weekly_cycle_start_ts is not None:
                        cycle_days = (
                            pd.Timestamp(ts).date()
                            - pd.Timestamp(weekly_cycle_start_ts).date()
                        ).days

                        self.payout_cycle_rows.append({
                            "cycle_id": cycle_id,
                            "pa_start_timestamp": pa_start_ts,
                            "timestamp_valid": (
                                pa_start_ts is None or ts >= pa_start_ts
                            ),
                            "weekly_cycle_number": weekly_cycle_number,
                            "cycle_start": weekly_cycle_start_ts,
                            "cycle_end": ts,
                            "target_frequency_days": self.target_payout_frequency_days,
                            "calendar_days": cycle_days,
                            "active_trading_days": len(weekly_cycle_active_days),
                            "trades": weekly_cycle_trade_count,
                            "cycle_pnl": balance + payout_amount - float(weekly_cycle_start_balance),
                            "target_met": True,
                            "min_weekly_payout_amount": self.min_weekly_payout_amount,
                            "payout_triggered": True,
                            "payout_amount": payout_amount,
                            "best_payout_cycle_day": best_payout_cycle_day,
                            "consistency_limit": consistency_limit,
                            "consistency_ok": consistency_ok,
                            "min_days_ok": min_days_ok,
                            "min_payout_ok": min_payout_ok,
                            "consistency_rule_pct": self.pa_consistency_rule_pct,
                            "min_trading_days_required": self.pa_min_payout_trading_days,
                            "min_payout_amount": self.pa_min_payout_amount,
                            "max_payout_amount": self.pa_max_payout_amount,
                        })

                    last_payout_ts = ts
                    weekly_cycle_number += 1
                    weekly_cycle_start_ts = ts
                    weekly_cycle_start_balance = balance
                    weekly_cycle_trade_count = 0
                    weekly_cycle_active_days = set()

                    self.log_event(
                        ts,
                        "PAYOUT_APPROVED",
                        cycle_id,
                        details=f"${payout_amount:.2f}",
                    )

                    # =========================================
                    # POST PAYOUT ACCOUNT LOCK
                    # =========================================

                    trading_locked = True

                    self.log_event(
                        ts,
                        "POST_PAYOUT_LOCK",
                        cycle_id,
                    )

            # =================================================
            # DAILY ROWS
            # =================================================

            self.daily_rows.append({
                "cycle_id": cycle_id,
                "date": trade_day,
                "mode": mode,
                "balance": balance,
                "daily_pnl": daily_pnl,
            })

            if mode == "eval":
                current_idx += 1
            else:
                pa_idx += 1

        # =====================================================
        # END OF DATA
        # =====================================================

        return {
            "next_idx": eval_next_idx if mode == "pa" else current_idx,
            "cycle": {
                "cycle_id": cycle_id,
                "next_eval_idx": eval_next_idx if mode == "pa" else current_idx,
                "result": "data_end",
                "eval_passed": (
                    mode == "pa"
                ),
                "pa_blown": False,
                "payout_count": payout_count,
                "payout_total": payout_total,
                "final_balance": balance,
                "net_pnl": (
                    balance - eval_cfg.account_size
                ),
                "eval_start": eval_start_ts,
                "eval_end": eval_pass_ts,
                "eval_calendar_days": (
                    pd.Timestamp(eval_pass_ts).date()
                    - pd.Timestamp(eval_start_ts).date()
                ).days if eval_pass_ts is not None else (
                    pd.Timestamp(last_ts_seen).date()
                    - pd.Timestamp(eval_start_ts).date()
                ).days,
                "eval_active_days": len(eval_active_days),
                "eval_trades": eval_trade_count,
                "pa_start": pa_start_ts,
                "pa_end": last_ts_seen if mode == "pa" else None,
                "pa_calendar_days": (
                    pd.Timestamp(last_ts_seen).date()
                    - pd.Timestamp(pa_start_ts).date()
                ).days if mode == "pa" and pa_start_ts is not None else 0,
                "pa_active_days": len(pa_active_days),
                "pa_trades": pa_trade_count,
            }
        }

    # ========================================================

    def build_summary(self):

        cycles_df = pd.DataFrame(self.cycles)
        payout_cycles_df = pd.DataFrame(self.payout_cycle_rows)

        eval_passed = (
            cycles_df["eval_passed"].sum()
            if len(cycles_df) > 0 else 0
        )

        pa_blown = (
            cycles_df["pa_blown"].sum()
            if len(cycles_df) > 0 else 0
        )

        payout_total = (
            cycles_df["payout_total"].sum()
            if len(cycles_df) > 0 else 0
        )

        payout_cycle_hit_rate = 0.0
        avg_days_per_payout_cycle = 0.0

        if len(payout_cycles_df) > 0:
            payout_cycle_hit_rate = float(
                payout_cycles_df["target_met"].mean()
            )
            avg_days_per_payout_cycle = float(
                payout_cycles_df["calendar_days"].mean()
            )

        return {
            "eval_attempts": len(cycles_df),
            "eval_passed": int(eval_passed),
            "eval_pass_rate": (
                float(eval_passed) / len(cycles_df)
                if len(cycles_df) > 0 else 0
            ),
            "pa_blown": int(pa_blown),
            "total_payouts": payout_total,
            "avg_payouts_per_account": (
                cycles_df["payout_count"].mean()
                if len(cycles_df) > 0 else 0
            ),
            "avg_pa_net_pnl": (
                cycles_df["net_pnl"].mean()
                if len(cycles_df) > 0 else 0
            ),
            "avg_eval_calendar_days": (
                cycles_df["eval_calendar_days"].mean()
                if "eval_calendar_days" in cycles_df.columns and len(cycles_df) > 0 else 0
            ),
            "avg_eval_active_days": (
                cycles_df["eval_active_days"].mean()
                if "eval_active_days" in cycles_df.columns and len(cycles_df) > 0 else 0
            ),
            "avg_eval_trades": (
                cycles_df["eval_trades"].mean()
                if "eval_trades" in cycles_df.columns and len(cycles_df) > 0 else 0
            ),
            "avg_pa_calendar_days": (
                cycles_df["pa_calendar_days"].mean()
                if "pa_calendar_days" in cycles_df.columns and len(cycles_df) > 0 else 0
            ),
            "avg_pa_active_days": (
                cycles_df["pa_active_days"].mean()
                if "pa_active_days" in cycles_df.columns and len(cycles_df) > 0 else 0
            ),
            "avg_pa_trades": (
                cycles_df["pa_trades"].mean()
                if "pa_trades" in cycles_df.columns and len(cycles_df) > 0 else 0
            ),
            "payout_cycle_hit_rate": payout_cycle_hit_rate,
            "avg_days_per_payout_cycle": avg_days_per_payout_cycle,
            "pa_min_payout_trading_days": self.pa_min_payout_trading_days,
            "pa_consistency_rule_pct": self.pa_consistency_rule_pct,
            "pa_min_payout_amount": self.pa_min_payout_amount,
            "pa_max_payout_amount": self.pa_max_payout_amount,
        }


# ============================================================
# OUTPUTS
# ============================================================

def write_outputs(sim, output_dir):

    output_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    pd.DataFrame(sim.cycles).to_csv(
        output_dir / "dual_mode_cycles.csv",
        index=False,
    )

    pd.DataFrame(sim.events).to_csv(
        output_dir / "dual_mode_events.csv",
        index=False,
    )

    pd.DataFrame(sim.daily_rows).to_csv(
        output_dir / "dual_mode_daily.csv",
        index=False,
    )

    pd.DataFrame(sim.payout_rows).to_csv(
        output_dir / "dual_mode_payouts.csv",
        index=False,
    )

    pd.DataFrame(sim.payout_cycle_rows).to_csv(
        output_dir / "dual_mode_payout_cycles.csv",
        index=False,
    )


# ============================================================
# CLI
# ============================================================

def parse_args():

    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--trade-log",
        required=False,
        default="",
        help="Single-log mode. Used for both eval and PA if --eval-trade-log/--pa-trade-log are not supplied.",
    )

    parser.add_argument(
        "--eval-trade-log",
        default="",
        help="Two-log mode: trade log used for the eval phase.",
    )

    parser.add_argument(
        "--pa-trade-log",
        default="",
        help="Two-log mode: trade log used for the PA/payout phase after eval pass.",
    )

    parser.add_argument(
        "--profile",
        required=True,
    )

    parser.add_argument(
        "--profiles-file",
        default=(
            "src/strategies/manual/"
            "researched_prop_trend/"
            "dual_mode_profiles.yaml"
        ),
    )

    parser.add_argument(
        "--output-dir",
        default=(
            "src/strategies/manual/"
            "researched_prop_trend/"
            "dual_mode_outputs"
        ),
    )

    parser.add_argument(
        "--eval-risk-multiplier",
        type=float,
        default=1.0,
        help="Scale trade PnL/risk during eval mode only. Example: 2.0 for faster eval attempts.",
    )

    parser.add_argument(
        "--pa-risk-multiplier",
        type=float,
        default=1.0,
        help="Scale trade PnL/risk during PA mode only. Example: 0.75 for safer payout farming.",
    )

    parser.add_argument(
        "--target-payout-frequency-days",
        type=int,
        default=7,
        help="Target payout cadence to measure, e.g. 7 for weekly payouts.",
    )

    parser.add_argument(
        "--min-weekly-payout-amount",
        type=float,
        default=1000.0,
        help="Minimum cycle PnL needed to count a weekly payout cycle as successful.",
    )

    parser.add_argument(
        "--pa-min-payout-trading-days",
        type=int,
        default=5,
        help="PA-only payout rule: minimum active trading days required before payout.",
    )

    parser.add_argument(
        "--pa-consistency-rule-pct",
        type=float,
        default=50.0,
        help="PA-only payout rule: best single day must be <= this percent of payout-cycle profit.",
    )

    parser.add_argument(
        "--pa-min-payout-amount",
        type=float,
        default=250.0,
        help="PA-only payout rule: minimum payout request amount.",
    )

    parser.add_argument(
        "--pa-max-payout-amount",
        type=float,
        default=2000.0,
        help="PA payout cap/target per payout request.",
    )

    parser.add_argument(
        "--aggressive-eval-until-pass",
        action="store_true",
        help="Labels this run as aggressive eval optimisation. Risk scaling is controlled by --eval-risk-multiplier.",
    )

    return parser.parse_args()


# ============================================================
# MAIN
# ============================================================

def main():

    args = parse_args()

    profiles = load_profiles(
        args.profiles_file
    )

    if args.profile not in profiles:
        raise ValueError(
            f"Unknown profile: {args.profile}"
        )

    profile = profiles[args.profile]

    eval_trade_log = args.eval_trade_log or args.trade_log
    pa_trade_log = args.pa_trade_log or args.trade_log

    if not eval_trade_log:
        raise ValueError("Provide --trade-log or --eval-trade-log")

    if not pa_trade_log:
        raise ValueError("Provide --trade-log or --pa-trade-log")

    df = load_trade_log(eval_trade_log)
    pa_df = load_trade_log(pa_trade_log)

    sim = DualModeLifecycleSimulator(
        df=df,
        pa_df=pa_df,
        profile=profile,
        eval_risk_multiplier=args.eval_risk_multiplier,
        pa_risk_multiplier=args.pa_risk_multiplier,
        target_payout_frequency_days=args.target_payout_frequency_days,
        min_weekly_payout_amount=args.min_weekly_payout_amount,
        pa_min_payout_trading_days=args.pa_min_payout_trading_days,
        pa_consistency_rule_pct=args.pa_consistency_rule_pct,
        pa_min_payout_amount=args.pa_min_payout_amount,
        pa_max_payout_amount=args.pa_max_payout_amount,
        aggressive_eval_until_pass=args.aggressive_eval_until_pass,
    )

    summary = sim.run()

    output_dir = Path(
        args.output_dir
    )

    write_outputs(
        sim,
        output_dir,
    )

    print(
        "\n================ "
        "DUAL MODE SUMMARY "
        "================"
    )

    for k, v in summary.items():

        if isinstance(v, float):
            print(f"{k}: {v:.2f}")
        else:
            print(f"{k}: {v}")

    print("\nWrote files:")

    print(output_dir / "dual_mode_cycles.csv")
    print(output_dir / "dual_mode_events.csv")
    print(output_dir / "dual_mode_daily.csv")
    print(output_dir / "dual_mode_payouts.csv")
    print(output_dir / "dual_mode_payout_cycles.csv")


if __name__ == "__main__":
    main()