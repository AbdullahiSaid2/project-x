# ICT Fractal V2 Improvements Package

This package adds a safe improved wrapper strategy:

```text
--strategy ict_fractal_v2
```

It keeps the old strategy untouched:

```text
--strategy ict_fractal
```

## Files included

```text
src/backtesting/event_engine/run_event_backtest.py
src/strategies/adapters/ict_fractal_v2_event_adapter.py
```

## Improvements added

- setup scoring
- regime filtering
- session-quality filtering
- overextension protection
- HTF bias quality scoring
- 30m bridge/displacement scoring
- 3m execution quality scoring
- liquidity-context scoring

## Important

Your current event engine does not model partial exits / breakeven directly.
This V2 package improves signal quality first. Partial/BE needs a separate execution-engine upgrade.

## Install

```bash
cd /Users/Abdullahi/trading-project/trading_system

unzip /path/to/ict_fractal_v2_improvements_package.zip -d /tmp/ict_fractal_v2

cp -R /tmp/ict_fractal_v2/src/* src/
```

## Run comparison

Old:

```bash
PYTHONPATH=. python -m src.backtesting.event_engine.run_event_backtest   --strategy ict_fractal   --symbols MNQ MES MYM MGC   --prop-profile apex_50k_pa   --days-back 365   --timeframe 1m   --no-tail   --commission-per-contract-side 2.0   --min-trend-score 3   --target-r 10.0   --min-planned-target-dollars 500   --news-events src/strategies/manual/researched_prop_trend/news_events.csv   --output-prefix ict_fractal_old_365
```

New:

```bash
PYTHONPATH=. python -m src.backtesting.event_engine.run_event_backtest   --strategy ict_fractal_v2   --symbols MNQ MES MYM MGC   --prop-profile apex_50k_pa   --days-back 365   --timeframe 1m   --no-tail   --commission-per-contract-side 2.0   --min-trend-score 4   --target-r 10.0   --min-planned-target-dollars 500   --news-events src/strategies/manual/researched_prop_trend/news_events.csv   --output-prefix ict_fractal_v2_365
```
