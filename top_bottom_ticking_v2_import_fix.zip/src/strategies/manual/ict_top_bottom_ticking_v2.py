from __future__ import annotations

from datetime import time

import pandas as pd


# =========================================================
# TOP BOTTOM TICKING V2
# =========================================================
#
# Purpose:
#   Refined ICT-style top/bottom ticking model.
#
# Core idea:
#   Rejection Block CE
#   + liquidity sweep
#   + displacement MSS
#   + FVG confirmation
#   + tight stop
#   + asymmetric target.
#
# This file intentionally lives beside the old strategy:
#
#   OLD: src/strategies/manual/ict_top_bottom_ticking.py
#   NEW: src/strategies/manual/ict_top_bottom_ticking_v2.py
#
# Do NOT put this under:
#
#   src/strategies/manual/ict_top_bottom_ticking/top_bottom_ticking_v2.py
#
# because your repo uses ict_top_bottom_ticking.py as a module file,
# not a package folder.
# =========================================================


# =========================================================
# CONFIG
# =========================================================

TARGET_R = 10.0
STOP_BUFFER = 0.10
CE_TOLERANCE = 0.10

MIN_DISPLACEMENT_ATR = 1.5
MIN_BODY_RATIO = 0.60

MIN_RB_DISPLACEMENT = 1.2
MIN_RB_BODY_RATIO = 0.55

MIN_VOLATILITY_RATIO = 0.75
EXPANSION_THRESHOLD = 1.0

MAX_TRADES_PER_DAY = 3
MAX_CONSECUTIVE_LOSSES = 2
MAX_DAILY_R_LOSS = -1.5
DAILY_PROFIT_LOCK = 3.0

PARTIAL_R = 2.0
PARTIAL_CLOSE = 0.50

LONDON_KILLZONE = (time(8, 0), time(11, 30))
NY_AM = (time(13, 30), time(16, 0))


# =========================================================
# COLUMN NORMALIZATION
# =========================================================

def _normalise_columns(df: pd.DataFrame) -> pd.DataFrame:
    """
    Supports both lowercase OHLC and event-engine OHLC names.

    Event engine usually uses:
        Open, High, Low, Close

    Some older strategy files use:
        open, high, low, close
    """
    out = df.copy()

    rename_map = {
        "Open": "open",
        "High": "high",
        "Low": "low",
        "Close": "close",
        "Volume": "volume",
    }

    for old, new in rename_map.items():
        if old in out.columns and new not in out.columns:
            out[new] = out[old]

    required = ["open", "high", "low", "close"]
    missing = [c for c in required if c not in out.columns]

    if missing:
        raise ValueError(
            f"top_bottom_ticking_v2 missing required columns: {missing}. "
            f"Available columns: {list(out.columns)}"
        )

    return out


# =========================================================
# PAYOUT RISK MANAGER
# =========================================================

class PayoutRiskManager:
    def __init__(self):
        self.daily_r = 0.0
        self.daily_trades = 0
        self.consecutive_losses = 0
        self.locked = False

    def reset_day(self):
        self.daily_r = 0.0
        self.daily_trades = 0
        self.consecutive_losses = 0
        self.locked = False

    def can_trade(self):
        return not self.locked

    def register_trade(self, planned_r: float):
        """
        This is a signal-stage throttle, not realised trade accounting.
        It prevents excessive signal generation per day.

        Actual realised PnL/risk is handled by the event engine.
        """
        self.daily_trades += 1
        self.daily_r += planned_r

        if planned_r < 0:
            self.consecutive_losses += 1
        else:
            self.consecutive_losses = 0

        if self.daily_trades >= MAX_TRADES_PER_DAY:
            self.locked = True

        if self.consecutive_losses >= MAX_CONSECUTIVE_LOSSES:
            self.locked = True

        if self.daily_r <= MAX_DAILY_R_LOSS:
            self.locked = True

        if self.daily_r >= DAILY_PROFIT_LOCK:
            self.locked = True


# =========================================================
# TIMEZONE / SESSION HELPERS
# =========================================================

def _to_et_timestamp(ts):
    ts = pd.Timestamp(ts)

    if ts.tzinfo is None:
        ts = ts.tz_localize("UTC")

    return ts.tz_convert("America/New_York")


def allowed_session(timestamp_value):
    """
    Trade only London and NY AM style windows in ET.

    This is intentionally strict to reduce overtrading.
    """
    ts_et = _to_et_timestamp(timestamp_value)
    t = ts_et.time()

    return (
        LONDON_KILLZONE[0] <= t <= LONDON_KILLZONE[1]
        or NY_AM[0] <= t <= NY_AM[1]
    )


# =========================================================
# VOLATILITY / REGIME FILTERS
# =========================================================

def _atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
    high = df["high"]
    low = df["low"]
    close = df["close"]
    prev_close = close.shift(1)

    tr = pd.concat(
        [
            high - low,
            (high - prev_close).abs(),
            (low - prev_close).abs(),
        ],
        axis=1,
    ).max(axis=1)

    return tr.rolling(period, min_periods=period).mean()


def volatility_ok(current_atr, rolling_atr):
    return current_atr >= (rolling_atr * MIN_VOLATILITY_RATIO)


def expansion_regime(current_atr, rolling_atr):
    return current_atr > (rolling_atr * EXPANSION_THRESHOLD)


# =========================================================
# LIQUIDITY SWEEPS
# =========================================================

def bullish_sweep(current_low, previous_low):
    return current_low < previous_low


def bearish_sweep(current_high, previous_high):
    return current_high > previous_high


# =========================================================
# MSS LOGIC
# =========================================================

def displacement_strength(candle, atr):
    return (float(candle.high) - float(candle.low)) / max(float(atr), 0.01)


def candle_body_ratio(candle):
    rng = float(candle.high) - float(candle.low)

    if rng <= 0:
        return 0.0

    return abs(float(candle.close) - float(candle.open)) / rng


def valid_displacement(candle, atr):
    return (
        displacement_strength(candle, atr) >= MIN_DISPLACEMENT_ATR
        and candle_body_ratio(candle) >= MIN_BODY_RATIO
    )


def bullish_mss(candle, prior_high, atr):
    return valid_displacement(candle, atr) and float(candle.close) > float(prior_high)


def bearish_mss(candle, prior_low, atr):
    return valid_displacement(candle, atr) and float(candle.close) < float(prior_low)


# =========================================================
# REJECTION BLOCKS
# =========================================================

def calculate_ce(high, low):
    return (float(high) + float(low)) / 2.0


def valid_rejection_block(candle, atr):
    body = candle_body_ratio(candle)
    displacement = (float(candle.high) - float(candle.low)) / max(float(atr), 0.01)

    return (
        displacement >= MIN_RB_DISPLACEMENT
        and body >= MIN_RB_BODY_RATIO
    )


def build_rejection_block(candle, direction, atr):
    if not valid_rejection_block(candle, atr):
        return None

    return {
        "direction": direction,
        "high": float(candle.high),
        "low": float(candle.low),
        "open": float(candle.open),
        "close": float(candle.close),
        "ce": calculate_ce(candle.high, candle.low),
        "timestamp": candle.name,
    }


# =========================================================
# FAIR VALUE GAPS
# =========================================================

def bullish_fvg(c1, c2, c3):
    if float(c1.high) < float(c3.low):
        return {
            "direction": "bullish",
            "upper": float(c3.low),
            "lower": float(c1.high),
            "midpoint": (float(c3.low) + float(c1.high)) / 2.0,
        }

    return None


def bearish_fvg(c1, c2, c3):
    if float(c1.low) > float(c3.high):
        return {
            "direction": "bearish",
            "upper": float(c1.low),
            "lower": float(c3.high),
            "midpoint": (float(c1.low) + float(c3.high)) / 2.0,
        }

    return None


# =========================================================
# PARTIALS PLACEHOLDERS
# =========================================================

def should_take_partial(current_r):
    return current_r >= PARTIAL_R


def partial_size(position_size):
    return max(1, int(position_size * PARTIAL_CLOSE))


# =========================================================
# ENTRY HELPERS
# =========================================================

def near_ce(price, ce_level, rb_range):
    if rb_range <= 0:
        return False

    tolerance = rb_range * CE_TOLERANCE

    return abs(float(price) - float(ce_level)) <= tolerance


# =========================================================
# MAIN STRATEGY ENGINE
# =========================================================

def generate_top_bottom_ticking_v2_signals(df: pd.DataFrame) -> pd.DataFrame:
    """
    Generates planned entry signals only.

    The event engine is still responsible for:
      - position sizing
      - stop/target fills
      - same-bar exit prevention
      - commission
      - daily rules
      - prop profile logic
    """
    df = _normalise_columns(df)

    trades = []
    risk_manager = PayoutRiskManager()

    if "atr" not in df.columns:
        df["atr"] = _atr(df, 14)

    df["rolling_atr"] = df["atr"].rolling(50, min_periods=50).mean()

    current_day = None

    for i in range(50, len(df) - 1):
        candle = df.iloc[i]
        timestamp = candle.name
        timestamp_et = _to_et_timestamp(timestamp)

        if current_day != timestamp_et.date():
            current_day = timestamp_et.date()
            risk_manager.reset_day()

        if not risk_manager.can_trade():
            continue

        if not allowed_session(timestamp):
            continue

        atr = candle.atr
        rolling_atr = candle.rolling_atr

        if pd.isna(atr) or pd.isna(rolling_atr):
            continue

        if not volatility_ok(atr, rolling_atr):
            continue

        if not expansion_regime(atr, rolling_atr):
            continue

        prev = df.iloc[i - 1]
        prev2 = df.iloc[i - 2]

        bullish_rb = build_rejection_block(prev, "bullish", atr)
        bearish_rb = build_rejection_block(prev, "bearish", atr)

        bullish_setup = (
            bullish_sweep(candle.low, prev.low)
            and bullish_mss(candle, prev2.high, atr)
        )

        bearish_setup = (
            bearish_sweep(candle.high, prev.high)
            and bearish_mss(candle, prev2.low, atr)
        )

        if bullish_setup:
            fvg = bullish_fvg(prev2, prev, candle)

            if fvg and bullish_rb:
                rb_range = bullish_rb["high"] - bullish_rb["low"]

                if near_ce(candle.close, bullish_rb["ce"], rb_range):
                    entry = float(candle.close)
                    stop = float(bullish_rb["low"]) - STOP_BUFFER
                    risk = entry - stop

                    if risk > 0:
                        target = entry + (risk * TARGET_R)

                        trades.append(
                            {
                                "timestamp": timestamp,
                                "side": "LONG",
                                "entry": entry,
                                "stop": stop,
                                "target": target,
                                "risk": risk,
                                "setup": "top_bottom_ticking_v2_bullish_rb_ce_mss",
                            }
                        )

                        risk_manager.register_trade(1.0)

        if bearish_setup:
            fvg = bearish_fvg(prev2, prev, candle)

            if fvg and bearish_rb:
                rb_range = bearish_rb["high"] - bearish_rb["low"]

                if near_ce(candle.close, bearish_rb["ce"], rb_range):
                    entry = float(candle.close)
                    stop = float(bearish_rb["high"]) + STOP_BUFFER
                    risk = stop - entry

                    if risk > 0:
                        target = entry - (risk * TARGET_R)

                        trades.append(
                            {
                                "timestamp": timestamp,
                                "side": "SHORT",
                                "entry": entry,
                                "stop": stop,
                                "target": target,
                                "risk": risk,
                                "setup": "top_bottom_ticking_v2_bearish_rb_ce_mss",
                            }
                        )

                        risk_manager.register_trade(1.0)

    return pd.DataFrame(trades)
