from src.strategies.manual.ict_top_bottom_ticking_v2 import (
    generate_top_bottom_ticking_v2_signals,
)


class TopBottomTickingV2Adapter:
    """
    Adapter for the refined Top Bottom Ticking V2 strategy.

    This keeps the old ict_top_bottom_ticking.py strategy untouched and loads
    the new v2 strategy from:

        src/strategies/manual/ict_top_bottom_ticking_v2.py
    """

    name = "top_bottom_ticking_v2"
    strategy_name = "top_bottom_ticking_v2"

    def build_features(self, symbol, df):
        # The v2 signal generator builds its own required columns.
        return df.copy()

    def signal_for_row(self, symbol, row, history, spec, profile, args):
        """
        Event-engine compatible row-by-row signal interface.

        The shared event engine calls signal_for_row(...), not generate_signals(...).
        We evaluate only on the latest available history window and return the
        newest signal if its timestamp matches the current row.
        """
        from src.backtesting.event_engine.models import OrderPlan

        if history is None or len(history) < 60:
            return None

        signals_df = generate_top_bottom_ticking_v2_signals(history)

        if signals_df is None or signals_df.empty:
            return None

        latest = signals_df.iloc[-1]

        if latest["timestamp"] != row.name:
            return None

        side = str(latest["side"]).upper()
        entry = float(latest["entry"])
        stop = float(latest["stop"])
        target = float(latest["target"])
        trade_type = str(latest.get("setup", "top_bottom_ticking_v2"))

        return OrderPlan(
            symbol=symbol,
            side=side,
            entry_price=entry,
            stop_price=stop,
            target_price=target,
            trade_type=trade_type,
            reason=trade_type,
            strategy_name=self.name,
            setup_score=1.0,
        )

    def generate_signals(self, symbol, df, profile=None, args=None):
        """
        Batch-style compatibility helper for older callers.
        """
        signals_df = generate_top_bottom_ticking_v2_signals(df)

        signals = []

        if signals_df is None or signals_df.empty:
            return signals

        for _, row in signals_df.iterrows():
            signals.append(
                {
                    "timestamp": row["timestamp"],
                    "symbol": symbol,
                    "side": row["side"],
                    "entry_price": row["entry"],
                    "stop_price": row["stop"],
                    "target_price": row["target"],
                    "trade_type": row["setup"],
                }
            )

        return signals
