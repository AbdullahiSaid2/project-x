import argparse
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import pandas as pd
import yaml


# ============================================================
# DATA CLASSES
# ============================================================

@dataclass
class EvalConfig:
    account_size: float
    profit_target: float
    max_drawdown: float
    drawdown_type: str

    risk_per_trade: float
    daily_profit_target: float
    daily_soft_loss_stop: float
    max_trades_per_day: int
    pause_after_consecutive_losses: int


@dataclass
class PAConfig:
    account_size: float
    max_drawdown: float
    drawdown_type: str

    risk_per_trade: float
    daily_profit_target: float
    daily_soft_loss_stop: float
    max_trades_per_day: int
    pause_after_consecutive_losses: int

    payout_buffer: float
    payout_lock_days: int

    reduce_risk_after_payout: bool
    reduced_risk_per_trade: float


@dataclass
class DualModeProfile:
    name: str
    eval: EvalConfig
    pa: PAConfig


# ============================================================
# HELPERS
# ============================================================

def load_profiles(profile_path: str) -> dict:

    with open(profile_path, "r") as f:
        raw = yaml.safe_load(f)

    out = {}

    for name, cfg in raw.items():

        eval_cfg = EvalConfig(**cfg["eval"])
        pa_cfg = PAConfig(**cfg["pa"])

        out[name] = DualModeProfile(
            name=name,
            eval=eval_cfg,
            pa=pa_cfg,
        )

    return out


# ============================================================
# TRADE LOG LOADER
# ============================================================

def load_trade_log(path: str) -> pd.DataFrame:
    """
    Load a trade log from either the older research backtests or the newer
    event engine.

    Important fix:
        Event-engine logs use columns such as exit_time_et / entry_time_et.
        These values can contain mixed timezone offsets around DST changes.
        Pandas may parse that as object dtype unless utc=True is used, which
        then breaks `.dt.date`.

    This function therefore:
        1. Preferentially uses exit_time_et / exit_time for closed-trade date.
        2. Parses timestamps with utc=True and errors="coerce".
        3. Drops rows where timestamp parsing failed.
        4. Normalizes PnL to a common `pnl` column.
    """

    df = pd.read_csv(path)

    # Prefer exit timestamp because payout/eval lifecycle should be based on
    # when the trade actually realized PnL.
    timestamp_candidates = [
        # NEW EVENT ENGINE
        "exit_time_et",
        "exit_time",
        "exit_timestamp",
        "closed_at",

        # FALLBACKS
        "timestamp",
        "entry_time_et",
        "entry_time",
        "entry_timestamp",
        "opened_at",
    ]

    pnl_candidates = [
        "net_pnl_dollars",
        "net_pnl",
        "pnl",
        "realized_pnl",
    ]

    timestamp_col = None
    pnl_col = None

    # =====================================================
    # FIND TIMESTAMP COLUMN
    # =====================================================

    for col in timestamp_candidates:
        if col in df.columns:
            timestamp_col = col
            break

    if timestamp_col is None:
        print("\nAvailable columns:")
        print(df.columns.tolist())
        raise ValueError("No timestamp column found")

    # =====================================================
    # FIND PNL COLUMN
    # =====================================================

    for col in pnl_candidates:
        if col in df.columns:
            pnl_col = col
            break

    if pnl_col is None:
        print("\nAvailable columns:")
        print(df.columns.tolist())
        raise ValueError("No pnl column found")

    # =====================================================
    # NORMALIZE
    # =====================================================

    df["timestamp"] = pd.to_datetime(
        df[timestamp_col],
        utc=True,
        errors="coerce",
    )

    bad_timestamp_rows = int(df["timestamp"].isna().sum())
    if bad_timestamp_rows:
        print(
            f"⚠️ Dropping {bad_timestamp_rows} rows with unparseable timestamps "
            f"from column {timestamp_col!r}"
        )

    df = df.dropna(subset=["timestamp"]).copy()

    df["pnl"] = pd.to_numeric(
        df[pnl_col],
        errors="coerce",
    ).fillna(0.0)

    df = df.sort_values("timestamp").reset_index(drop=True)

    # `.dt` is safe now because utc=True guarantees datetime64[ns, UTC].
    df["trade_date"] = df["timestamp"].dt.date

    return df



# ============================================================
# MAIN SIMULATOR
# ============================================================

class DualModeLifecycleSimulator:
    """
    Correct account lifecycle:

        1. Start eval.
        2. If eval passes, eval account closes.
        3. PA account starts at/after eval pass timestamp.
        4. PA keeps trading through multiple payout cycles.
        5. Payouts do NOT start a new eval.
        6. Only PA blow or data end ends the PA lifecycle.
        7. If PA blows, start a new eval after the eval trade that passed.

    In two-log mode:
        - eval trades come from eval log.
        - PA trades come from PA log.
        - PA cursor always starts at the first PA trade >= PA start timestamp.
    """

    def __init__(
        self,
        df: pd.DataFrame,
        profile: DualModeProfile,
        pa_df: pd.DataFrame | None = None,
        eval_risk_multiplier: float = 1.0,
        pa_risk_multiplier: float = 1.0,
        target_payout_frequency_days: int = 10,
        min_weekly_payout_amount: float = 1000.0,
        pa_min_payout_trading_days: int = 5,
        pa_consistency_rule_pct: float = 50.0,
        pa_min_payout_amount: float = 250.0,
        pa_max_payout_amount: float = 2000.0,
        aggressive_eval_until_pass: bool = False,
    ):
        self.df = df
        self.pa_df = pa_df if pa_df is not None else df
        self.profile = profile

        self.eval_risk_multiplier = float(eval_risk_multiplier)
        self.pa_risk_multiplier = float(pa_risk_multiplier)
        self.target_payout_frequency_days = int(target_payout_frequency_days)
        self.min_weekly_payout_amount = float(min_weekly_payout_amount)

        self.pa_min_payout_trading_days = int(pa_min_payout_trading_days)
        self.pa_consistency_rule_pct = float(pa_consistency_rule_pct)
        self.pa_min_payout_amount = float(pa_min_payout_amount)
        self.pa_max_payout_amount = float(pa_max_payout_amount)
        self.aggressive_eval_until_pass = bool(aggressive_eval_until_pass)

        self.cycles = []
        self.events = []
        self.daily_rows = []
        self.payout_rows = []
        self.payout_cycle_rows = []

    def log_event(self, ts, event_type, cycle_id, details=None):
        self.events.append({
            "timestamp": ts,
            "event_type": event_type,
            "cycle_id": cycle_id,
            "details": details,
        })

    @staticmethod
    def _first_index_at_or_after(trades, ts):
        for i, trade in enumerate(trades):
            if trade["timestamp"] >= ts:
                return i
        return len(trades)

    def run(self):
        eval_trades = self.df.to_dict("records")
        pa_trades = self.pa_df.to_dict("records")

        eval_idx = 0
        cycle_id = 1

        while eval_idx < len(eval_trades):
            result = self.run_one_account_lifecycle(
                eval_trades=eval_trades,
                pa_trades=pa_trades,
                eval_start_idx=eval_idx,
                cycle_id=cycle_id,
            )

            self.cycles.append(result["cycle"])

            next_idx = int(result["next_eval_idx"])
            if next_idx <= eval_idx:
                next_idx = eval_idx + 1

            eval_idx = next_idx
            cycle_id += 1

        return self.build_summary()

    def _apply_day_locks(
        self,
        ts,
        cycle_id,
        cfg,
        daily_pnl,
        daily_trade_count,
        consecutive_losses,
    ):
        if daily_trade_count >= cfg.max_trades_per_day:
            self.log_event(ts, "MAX_TRADES_DAY_LOCK", cycle_id)
            return True, "max_trades_per_day"

        if daily_pnl <= -abs(cfg.daily_soft_loss_stop):
            self.log_event(ts, "DAILY_SOFT_LOSS_LOCK", cycle_id)
            return True, "daily_soft_loss_stop"

        if daily_pnl >= cfg.daily_profit_target:
            self.log_event(ts, "DAILY_PROFIT_TARGET_LOCK", cycle_id)
            return True, "daily_profit_target"

        if consecutive_losses >= cfg.pause_after_consecutive_losses:
            self.log_event(ts, "CONSECUTIVE_LOSS_LOCK", cycle_id)
            return True, "consecutive_losses"

        return False, ""

    def _record_daily_row(
        self,
        cycle_id,
        trade_day,
        mode,
        balance,
        daily_pnl,
        daily_trade_count,
        day_locked,
        day_lock_reason,
    ):
        self.daily_rows.append({
            "cycle_id": cycle_id,
            "date": trade_day,
            "mode": mode,
            "balance": balance,
            "daily_pnl": daily_pnl,
            "daily_trade_count": daily_trade_count,
            "day_locked": day_locked,
            "day_lock_reason": day_lock_reason,
        })

    def run_one_account_lifecycle(self, eval_trades, pa_trades, eval_start_idx, cycle_id):
        eval_cfg = self.profile.eval
        pa_cfg = self.profile.pa

        # =====================================================
        # EVAL PHASE
        # =====================================================

        eval_balance = eval_cfg.account_size
        eval_high_watermark = eval_balance

        eval_start_ts = eval_trades[eval_start_idx]["timestamp"]
        eval_end_ts = None
        eval_pass_ts = None

        eval_active_days = set()
        eval_trade_count = 0
        eval_daily_pnl = 0.0
        eval_daily_trade_count = 0
        eval_consecutive_losses = 0
        eval_current_day = None
        eval_day_locked = False
        eval_day_lock_reason = ""

        self.log_event(eval_start_ts, "EVAL_STARTED", cycle_id)

        eval_idx = eval_start_idx

        while eval_idx < len(eval_trades):
            trade = eval_trades[eval_idx]
            ts = trade["timestamp"]
            trade_day = trade["trade_date"]

            if eval_current_day != trade_day:
                eval_current_day = trade_day
                eval_daily_pnl = 0.0
                eval_daily_trade_count = 0
                eval_consecutive_losses = 0
                eval_day_locked = False
                eval_day_lock_reason = ""

            if eval_day_locked:
                eval_idx += 1
                continue

            scaled_pnl = float(trade["pnl"]) * self.eval_risk_multiplier
            eval_balance += scaled_pnl
            eval_daily_pnl += scaled_pnl
            eval_daily_trade_count += 1
            eval_trade_count += 1
            eval_active_days.add(trade_day)
            eval_end_ts = ts

            if scaled_pnl < 0:
                eval_consecutive_losses += 1
            else:
                eval_consecutive_losses = 0

            eval_high_watermark = max(eval_high_watermark, eval_balance)
            eval_drawdown = eval_balance - eval_high_watermark

            self._record_daily_row(
                cycle_id=cycle_id,
                trade_day=trade_day,
                mode="eval",
                balance=eval_balance,
                daily_pnl=eval_daily_pnl,
                daily_trade_count=eval_daily_trade_count,
                day_locked=eval_day_locked,
                day_lock_reason=eval_day_lock_reason,
            )

            if eval_drawdown <= -abs(eval_cfg.max_drawdown):
                self.log_event(ts, "EVAL_FAILED_MAX_LOSS", cycle_id)
                return {
                    "next_eval_idx": eval_idx + 1,
                    "cycle": {
                        "cycle_id": cycle_id,
                        "result": "eval_failed",
                        "eval_passed": False,
                        "pa_blown": False,
                        "payout_count": 0,
                        "payout_total": 0.0,
                        "final_balance": eval_balance,
                        "net_pnl": eval_balance - eval_cfg.account_size,
                        "eval_start": eval_start_ts,
                        "eval_end": ts,
                        "eval_calendar_days": (pd.Timestamp(ts).date() - pd.Timestamp(eval_start_ts).date()).days,
                        "eval_active_days": len(eval_active_days),
                        "eval_trades": eval_trade_count,
                        "pa_start": None,
                        "pa_end": None,
                        "pa_calendar_days": 0,
                        "pa_active_days": 0,
                        "pa_trades": 0,
                    }
                }

            if eval_balance >= eval_cfg.account_size + eval_cfg.profit_target:
                eval_pass_ts = ts
                eval_end_ts = ts
                self.log_event(ts, "EVAL_PASSED", cycle_id)
                break

            eval_day_locked, eval_day_lock_reason = self._apply_day_locks(
                ts=ts,
                cycle_id=cycle_id,
                cfg=eval_cfg,
                daily_pnl=eval_daily_pnl,
                daily_trade_count=eval_daily_trade_count,
                consecutive_losses=eval_consecutive_losses,
            )

            eval_idx += 1

        if eval_pass_ts is None:
            last_ts = eval_end_ts or eval_start_ts
            return {
                "next_eval_idx": len(eval_trades),
                "cycle": {
                    "cycle_id": cycle_id,
                    "result": "data_end_before_eval_pass",
                    "eval_passed": False,
                    "pa_blown": False,
                    "payout_count": 0,
                    "payout_total": 0.0,
                    "final_balance": eval_balance,
                    "net_pnl": eval_balance - eval_cfg.account_size,
                    "eval_start": eval_start_ts,
                    "eval_end": last_ts,
                    "eval_calendar_days": (pd.Timestamp(last_ts).date() - pd.Timestamp(eval_start_ts).date()).days,
                    "eval_active_days": len(eval_active_days),
                    "eval_trades": eval_trade_count,
                    "pa_start": None,
                    "pa_end": None,
                    "pa_calendar_days": 0,
                    "pa_active_days": 0,
                    "pa_trades": 0,
                }
            }

        next_eval_idx_after_this_account = eval_idx + 1

        # =====================================================
        # PA PHASE: same PA account continues through payouts
        # until PA blown or data end.
        # =====================================================

        pa_start_ts = eval_pass_ts
        pa_balance = pa_cfg.account_size
        pa_start_balance = pa_balance
        pa_high_watermark = pa_balance

        pa_idx = self._first_index_at_or_after(pa_trades, pa_start_ts)

        pa_current_day = None
        pa_daily_pnl = 0.0
        pa_daily_trade_count = 0
        pa_consecutive_losses = 0
        pa_day_locked = False
        pa_day_lock_reason = ""
        payout_lock_days_remaining = 0

        pa_active_days = set()
        pa_trade_count = 0
        pa_end_ts = pa_start_ts

        payout_count = 0
        payout_total = 0.0
        last_payout_ts = None

        payout_cycle_number = 1
        payout_cycle_start_ts = pa_start_ts
        payout_cycle_start_balance = pa_balance
        payout_cycle_trade_count = 0
        payout_cycle_active_days = set()
        payout_cycle_day_pnls = {}

        self.log_event(pa_start_ts, "PA_STARTED", cycle_id)

        while pa_idx < len(pa_trades):
            trade = pa_trades[pa_idx]
            ts = trade["timestamp"]

            if ts < pa_start_ts:
                raise RuntimeError(
                    f"PA timestamp leak: PA trade {ts} before PA start {pa_start_ts}"
                )

            trade_day = trade["trade_date"]
            pa_end_ts = ts

            if pa_current_day != trade_day:
                # Record missed/measurement payout cycle every target window.
                if (
                    payout_cycle_start_ts is not None
                    and self.target_payout_frequency_days > 0
                ):
                    days_elapsed = (
                        pd.Timestamp(ts).date()
                        - pd.Timestamp(payout_cycle_start_ts).date()
                    ).days

                    if days_elapsed >= self.target_payout_frequency_days:
                        cycle_pnl = pa_balance - payout_cycle_start_balance
                        best_day = max(payout_cycle_day_pnls.values()) if payout_cycle_day_pnls else 0.0
                        consistency_limit = max(0.0, cycle_pnl) * (self.pa_consistency_rule_pct / 100.0)

                        self.payout_cycle_rows.append({
                            "cycle_id": cycle_id,
                            "pa_start_timestamp": pa_start_ts,
                            "timestamp_valid": ts >= pa_start_ts,
                            "weekly_cycle_number": payout_cycle_number,
                            "cycle_start": payout_cycle_start_ts,
                            "cycle_end": ts,
                            "target_frequency_days": self.target_payout_frequency_days,
                            "calendar_days": days_elapsed,
                            "active_trading_days": len(payout_cycle_active_days),
                            "trades": payout_cycle_trade_count,
                            "cycle_pnl": cycle_pnl,
                            "target_met": cycle_pnl >= self.min_weekly_payout_amount,
                            "min_weekly_payout_amount": self.min_weekly_payout_amount,
                            "payout_triggered": False,
                            "payout_amount": 0.0,
                            "best_payout_cycle_day": best_day,
                            "consistency_limit": consistency_limit,
                            "consistency_ok": best_day <= consistency_limit if cycle_pnl > 0 else False,
                            "min_days_ok": len(payout_cycle_active_days) >= self.pa_min_payout_trading_days,
                            "min_payout_ok": max(0.0, (pa_balance - pa_start_balance) - pa_cfg.payout_buffer) >= self.pa_min_payout_amount,
                            "consistency_rule_pct": self.pa_consistency_rule_pct,
                            "min_trading_days_required": self.pa_min_payout_trading_days,
                            "min_payout_amount": self.pa_min_payout_amount,
                            "max_payout_amount": self.pa_max_payout_amount,
                        })

                        payout_cycle_number += 1
                        payout_cycle_start_ts = ts
                        payout_cycle_start_balance = pa_balance
                        payout_cycle_trade_count = 0
                        payout_cycle_active_days = set()
                        payout_cycle_day_pnls = {}

                pa_current_day = trade_day
                pa_daily_pnl = 0.0
                pa_daily_trade_count = 0
                pa_consecutive_losses = 0
                pa_day_locked = False
                pa_day_lock_reason = ""

                if payout_lock_days_remaining > 0:
                    payout_lock_days_remaining -= 1

            if pa_day_locked:
                pa_idx += 1
                continue

            effective_risk = pa_cfg.risk_per_trade * self.pa_risk_multiplier

            if (
                payout_lock_days_remaining > 0
                and pa_cfg.reduce_risk_after_payout
            ):
                effective_risk = min(
                    effective_risk,
                    pa_cfg.reduced_risk_per_trade,
                )

            retained_profit = pa_balance - pa_start_balance
            if retained_profit >= 2000:
                effective_risk = min(
                    effective_risk,
                    pa_cfg.reduced_risk_per_trade,
                )

            scaled_pnl = float(trade["pnl"]) * (effective_risk / 150.0)

            pa_balance += scaled_pnl
            pa_daily_pnl += scaled_pnl
            pa_daily_trade_count += 1
            pa_trade_count += 1
            pa_active_days.add(trade_day)

            payout_cycle_trade_count += 1
            payout_cycle_active_days.add(trade_day)
            payout_cycle_day_pnls[trade_day] = payout_cycle_day_pnls.get(trade_day, 0.0) + scaled_pnl

            if scaled_pnl < 0:
                pa_consecutive_losses += 1
            else:
                pa_consecutive_losses = 0

            pa_high_watermark = max(pa_high_watermark, pa_balance)
            pa_drawdown = pa_balance - pa_high_watermark

            self._record_daily_row(
                cycle_id=cycle_id,
                trade_day=trade_day,
                mode="pa",
                balance=pa_balance,
                daily_pnl=pa_daily_pnl,
                daily_trade_count=pa_daily_trade_count,
                day_locked=pa_day_locked,
                day_lock_reason=pa_day_lock_reason,
            )

            if pa_drawdown <= -abs(pa_cfg.max_drawdown):
                self.log_event(ts, "PA_BLOWN_MAX_LOSS", cycle_id)
                return {
                    "next_eval_idx": next_eval_idx_after_this_account,
                    "cycle": {
                        "cycle_id": cycle_id,
                        "result": "pa_blown",
                        "eval_passed": True,
                        "pa_blown": True,
                        "payout_count": payout_count,
                        "payout_total": payout_total,
                        "final_balance": pa_balance,
                        "net_pnl": pa_balance - pa_start_balance,
                        "eval_start": eval_start_ts,
                        "eval_end": eval_pass_ts,
                        "eval_calendar_days": (pd.Timestamp(eval_pass_ts).date() - pd.Timestamp(eval_start_ts).date()).days,
                        "eval_active_days": len(eval_active_days),
                        "eval_trades": eval_trade_count,
                        "pa_start": pa_start_ts,
                        "pa_end": ts,
                        "pa_calendar_days": (pd.Timestamp(ts).date() - pd.Timestamp(pa_start_ts).date()).days,
                        "pa_active_days": len(pa_active_days),
                        "pa_trades": pa_trade_count,
                    }
                }

            # PA daily locks.
            pa_day_locked, pa_day_lock_reason = self._apply_day_locks(
                ts=ts,
                cycle_id=cycle_id,
                cfg=pa_cfg,
                daily_pnl=pa_daily_pnl,
                daily_trade_count=pa_daily_trade_count,
                consecutive_losses=pa_consecutive_losses,
            )

            # Payout eligibility: PA only.
            retained_profit = pa_balance - pa_start_balance
            available_payout = max(0.0, retained_profit - pa_cfg.payout_buffer)

            payout_cycle_profit = max(0.0, pa_balance - payout_cycle_start_balance)
            best_cycle_day = max(payout_cycle_day_pnls.values()) if payout_cycle_day_pnls else 0.0
            consistency_limit = payout_cycle_profit * (self.pa_consistency_rule_pct / 100.0)
            consistency_ok = payout_cycle_profit > 0 and best_cycle_day <= consistency_limit
            min_days_ok = len(payout_cycle_active_days) >= self.pa_min_payout_trading_days
            min_payout_ok = available_payout >= self.pa_min_payout_amount

            if min_days_ok and consistency_ok and min_payout_ok:
                payout_amount = min(available_payout, self.pa_max_payout_amount)

                if ts < pa_start_ts:
                    raise RuntimeError(
                        f"Invalid payout timestamp {ts}: before PA start {pa_start_ts}"
                    )

                payout_total += payout_amount
                payout_count += 1
                pa_balance -= payout_amount
                payout_lock_days_remaining = pa_cfg.payout_lock_days

                days_since_pa_start = (pd.Timestamp(ts).date() - pd.Timestamp(pa_start_ts).date()).days
                days_since_last_payout = (
                    (pd.Timestamp(ts).date() - pd.Timestamp(last_payout_ts).date()).days
                    if last_payout_ts is not None
                    else days_since_pa_start
                )

                self.payout_rows.append({
                    "cycle_id": cycle_id,
                    "timestamp": ts,
                    "pa_start_timestamp": pa_start_ts,
                    "timestamp_valid": ts >= pa_start_ts,
                    "payout_number": payout_count,
                    "payout_amount": payout_amount,
                    "days_since_pa_start": days_since_pa_start,
                    "days_since_last_payout": days_since_last_payout,
                    "pa_trades_to_payout": pa_trade_count,
                    "pa_active_days_to_payout": len(pa_active_days),
                    "payout_cycle_active_days": len(payout_cycle_active_days),
                    "payout_cycle_trades": payout_cycle_trade_count,
                    "payout_cycle_profit": payout_cycle_profit,
                    "best_payout_cycle_day": best_cycle_day,
                    "consistency_limit": consistency_limit,
                    "consistency_ok": consistency_ok,
                    "min_days_ok": min_days_ok,
                    "min_payout_ok": min_payout_ok,
                    "min_payout_amount": self.pa_min_payout_amount,
                    "max_payout_amount": self.pa_max_payout_amount,
                    "consistency_rule_pct": self.pa_consistency_rule_pct,
                })

                cycle_days = (pd.Timestamp(ts).date() - pd.Timestamp(payout_cycle_start_ts).date()).days

                self.payout_cycle_rows.append({
                    "cycle_id": cycle_id,
                    "pa_start_timestamp": pa_start_ts,
                    "timestamp_valid": ts >= pa_start_ts,
                    "weekly_cycle_number": payout_cycle_number,
                    "cycle_start": payout_cycle_start_ts,
                    "cycle_end": ts,
                    "target_frequency_days": self.target_payout_frequency_days,
                    "calendar_days": cycle_days,
                    "active_trading_days": len(payout_cycle_active_days),
                    "trades": payout_cycle_trade_count,
                    "cycle_pnl": payout_cycle_profit,
                    "target_met": True,
                    "min_weekly_payout_amount": self.min_weekly_payout_amount,
                    "payout_triggered": True,
                    "payout_amount": payout_amount,
                    "best_payout_cycle_day": best_cycle_day,
                    "consistency_limit": consistency_limit,
                    "consistency_ok": consistency_ok,
                    "min_days_ok": min_days_ok,
                    "min_payout_ok": min_payout_ok,
                    "consistency_rule_pct": self.pa_consistency_rule_pct,
                    "min_trading_days_required": self.pa_min_payout_trading_days,
                    "min_payout_amount": self.pa_min_payout_amount,
                    "max_payout_amount": self.pa_max_payout_amount,
                })

                self.log_event(
                    ts,
                    "PAYOUT_APPROVED",
                    cycle_id,
                    details=f"${payout_amount:.2f}",
                )
                self.log_event(ts, "POST_PAYOUT_LOCK", cycle_id)

                last_payout_ts = ts
                payout_cycle_number += 1
                payout_cycle_start_ts = ts
                payout_cycle_start_balance = pa_balance
                payout_cycle_trade_count = 0
                payout_cycle_active_days = set()
                payout_cycle_day_pnls = {}

                pa_day_locked = True
                pa_day_lock_reason = "post_payout_lock"

            pa_idx += 1

        # PA data end: PA did not blow. No new eval is started because data is over.
        return {
            "next_eval_idx": len(eval_trades),
            "cycle": {
                "cycle_id": cycle_id,
                "result": "data_end",
                "eval_passed": True,
                "pa_blown": False,
                "payout_count": payout_count,
                "payout_total": payout_total,
                "final_balance": pa_balance,
                "net_pnl": pa_balance - pa_start_balance,
                "eval_start": eval_start_ts,
                "eval_end": eval_pass_ts,
                "eval_calendar_days": (pd.Timestamp(eval_pass_ts).date() - pd.Timestamp(eval_start_ts).date()).days,
                "eval_active_days": len(eval_active_days),
                "eval_trades": eval_trade_count,
                "pa_start": pa_start_ts,
                "pa_end": pa_end_ts,
                "pa_calendar_days": (pd.Timestamp(pa_end_ts).date() - pd.Timestamp(pa_start_ts).date()).days,
                "pa_active_days": len(pa_active_days),
                "pa_trades": pa_trade_count,
            }
        }

    def build_summary(self):
        cycles_df = pd.DataFrame(self.cycles)
        payout_cycles_df = pd.DataFrame(self.payout_cycle_rows)

        eval_passed = cycles_df["eval_passed"].sum() if len(cycles_df) else 0
        pa_blown = cycles_df["pa_blown"].sum() if len(cycles_df) else 0
        payout_total = cycles_df["payout_total"].sum() if len(cycles_df) else 0

        payout_cycle_hit_rate = (
            float(payout_cycles_df["target_met"].mean())
            if len(payout_cycles_df) else 0.0
        )
        avg_days_per_payout_cycle = (
            float(payout_cycles_df["calendar_days"].mean())
            if len(payout_cycles_df) else 0.0
        )

        return {
            "eval_attempts": len(cycles_df),
            "eval_passed": int(eval_passed),
            "eval_pass_rate": float(eval_passed) / len(cycles_df) if len(cycles_df) else 0.0,
            "pa_blown": int(pa_blown),
            "total_payouts": payout_total,
            "avg_payouts_per_account": cycles_df["payout_count"].mean() if len(cycles_df) else 0,
            "avg_pa_net_pnl": cycles_df["net_pnl"].mean() if len(cycles_df) else 0,
            "avg_eval_calendar_days": cycles_df["eval_calendar_days"].mean() if "eval_calendar_days" in cycles_df.columns and len(cycles_df) else 0,
            "avg_eval_active_days": cycles_df["eval_active_days"].mean() if "eval_active_days" in cycles_df.columns and len(cycles_df) else 0,
            "avg_eval_trades": cycles_df["eval_trades"].mean() if "eval_trades" in cycles_df.columns and len(cycles_df) else 0,
            "avg_pa_calendar_days": cycles_df["pa_calendar_days"].mean() if "pa_calendar_days" in cycles_df.columns and len(cycles_df) else 0,
            "avg_pa_active_days": cycles_df["pa_active_days"].mean() if "pa_active_days" in cycles_df.columns and len(cycles_df) else 0,
            "avg_pa_trades": cycles_df["pa_trades"].mean() if "pa_trades" in cycles_df.columns and len(cycles_df) else 0,
            "payout_cycle_hit_rate": payout_cycle_hit_rate,
            "avg_days_per_payout_cycle": avg_days_per_payout_cycle,
            "pa_min_payout_trading_days": self.pa_min_payout_trading_days,
            "pa_consistency_rule_pct": self.pa_consistency_rule_pct,
            "pa_min_payout_amount": self.pa_min_payout_amount,
            "pa_max_payout_amount": self.pa_max_payout_amount,
        }


# ============================================================
# OUTPUTS
# ============================================================

def write_outputs(sim, output_dir):
    output_dir.mkdir(parents=True, exist_ok=True)

    pd.DataFrame(sim.cycles).to_csv(
        output_dir / "dual_mode_cycles.csv",
        index=False,
    )

    pd.DataFrame(sim.events).to_csv(
        output_dir / "dual_mode_events.csv",
        index=False,
    )

    pd.DataFrame(sim.daily_rows).to_csv(
        output_dir / "dual_mode_daily.csv",
        index=False,
    )

    pd.DataFrame(sim.payout_rows).to_csv(
        output_dir / "dual_mode_payouts.csv",
        index=False,
    )

    pd.DataFrame(sim.payout_cycle_rows).to_csv(
        output_dir / "dual_mode_payout_cycles.csv",
        index=False,
    )


# ============================================================
# CLI
# ============================================================

def parse_args():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--trade-log",
        required=False,
        default="",
        help="Single-log mode. Used for both eval and PA if --eval-trade-log/--pa-trade-log are not supplied.",
    )

    parser.add_argument(
        "--eval-trade-log",
        default="",
        help="Two-log mode: trade log used for the eval phase.",
    )

    parser.add_argument(
        "--pa-trade-log",
        default="",
        help="Two-log mode: trade log used for the PA/payout phase after eval pass.",
    )

    parser.add_argument(
        "--profile",
        required=True,
    )

    parser.add_argument(
        "--profiles-file",
        default=(
            "src/strategies/manual/"
            "researched_prop_trend/"
            "dual_mode_profiles.yaml"
        ),
    )

    parser.add_argument(
        "--output-dir",
        default=(
            "src/strategies/manual/"
            "researched_prop_trend/"
            "dual_mode_outputs"
        ),
    )

    parser.add_argument("--eval-risk-multiplier", type=float, default=1.0)
    parser.add_argument("--pa-risk-multiplier", type=float, default=1.0)
    parser.add_argument("--target-payout-frequency-days", type=int, default=10)
    parser.add_argument("--min-weekly-payout-amount", type=float, default=1000.0)
    parser.add_argument("--pa-min-payout-trading-days", type=int, default=5)
    parser.add_argument("--pa-consistency-rule-pct", type=float, default=50.0)
    parser.add_argument("--pa-min-payout-amount", type=float, default=250.0)
    parser.add_argument("--pa-max-payout-amount", type=float, default=2000.0)
    parser.add_argument("--aggressive-eval-until-pass", action="store_true")

    return parser.parse_args()


# ============================================================
# MAIN
# ============================================================

def main():
    args = parse_args()

    profiles = load_profiles(args.profiles_file)

    if args.profile not in profiles:
        raise ValueError(f"Unknown profile: {args.profile}")

    profile = profiles[args.profile]

    eval_trade_log = args.eval_trade_log or args.trade_log
    pa_trade_log = args.pa_trade_log or args.trade_log

    if not eval_trade_log:
        raise ValueError("Provide --trade-log or --eval-trade-log")

    if not pa_trade_log:
        raise ValueError("Provide --trade-log or --pa-trade-log")

    df = load_trade_log(eval_trade_log)
    pa_df = load_trade_log(pa_trade_log)

    sim = DualModeLifecycleSimulator(
        df=df,
        pa_df=pa_df,
        profile=profile,
        eval_risk_multiplier=args.eval_risk_multiplier,
        pa_risk_multiplier=args.pa_risk_multiplier,
        target_payout_frequency_days=args.target_payout_frequency_days,
        min_weekly_payout_amount=args.min_weekly_payout_amount,
        pa_min_payout_trading_days=args.pa_min_payout_trading_days,
        pa_consistency_rule_pct=args.pa_consistency_rule_pct,
        pa_min_payout_amount=args.pa_min_payout_amount,
        pa_max_payout_amount=args.pa_max_payout_amount,
        aggressive_eval_until_pass=args.aggressive_eval_until_pass,
    )

    summary = sim.run()

    output_dir = Path(args.output_dir)
    write_outputs(sim, output_dir)

    print("\n================ DUAL MODE SUMMARY ================")

    for k, v in summary.items():
        if isinstance(v, float):
            print(f"{k}: {v:.2f}")
        else:
            print(f"{k}: {v}")

    print("\nWrote files:")
    print(output_dir / "dual_mode_cycles.csv")
    print(output_dir / "dual_mode_events.csv")
    print(output_dir / "dual_mode_daily.csv")
    print(output_dir / "dual_mode_payouts.csv")
    print(output_dir / "dual_mode_payout_cycles.csv")


if __name__ == "__main__":
    main()
