# Prop Dual Mode Lifecycle Simulator V5 Correct Flow

This version implements the correct lifecycle:

eval pass -> PA starts -> trade payout cycle -> payout received -> continue same PA -> more payouts -> if PA blows start new eval.

Payouts do NOT start a new eval.

Install:
cd /Users/Abdullahi/trading-project/trading_system
unzip /path/to/prop_dual_mode_lifecycle_v5_correct_flow.zip -d /tmp/lifecycle_v5
cp -R /tmp/lifecycle_v5/src/* src/

Run:
PYTHONPATH=. python -m src.strategies.manual.researched_prop_trend.prop_dual_mode_lifecycle_simulator \
  --eval-trade-log src/backtesting/event_engine/outputs/ict_fractal_v2_eval_365_event_trade_log.csv \
  --pa-trade-log src/backtesting/event_engine/outputs/ict_fractal_v2_quality_be_partial_no_mym_long_event_trade_log.csv \
  --profile apex_50k_dual_mode \
  --eval-risk-multiplier 2.5 \
  --pa-risk-multiplier 1.0 \
  --target-payout-frequency-days 10 \
  --min-weekly-payout-amount 1000 \
  --pa-min-payout-trading-days 5 \
  --pa-consistency-rule-pct 50 \
  --pa-min-payout-amount 250 \
  --pa-max-payout-amount 2000 \
  --aggressive-eval-until-pass
