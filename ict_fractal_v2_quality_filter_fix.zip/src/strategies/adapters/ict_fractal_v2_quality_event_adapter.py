from __future__ import annotations

from dataclasses import dataclass
from datetime import time
from pathlib import Path
from typing import Any

import pandas as pd


# =========================================================
# ICT FRACTAL V2 QUALITY FILTER — SAFE FIX
# =========================================================
#
# Why this version exists:
#
# The first ict_fractal_v2_quality adapter filtered everything and produced
# 0 trades. That means the filter assumptions were too strict or the setup
# names/scores did not match the real OrderPlan fields.
#
# This version is intentionally safer:
#
#   1. Wraps the existing ICTFractalV2Adapter first.
#   2. Does NOT require exact setup-name matches.
#   3. Does NOT block sessions aggressively.
#   4. Does NOT impose daily caps yet.
#   5. Only blocks the known weak setup family if it appears.
#   6. Writes diagnostics to show what the adapter actually sees.
#
# Strategy:
#
#   --strategy ict_fractal_v2_quality
#
# =========================================================


STRATEGY_NAME = "ict_fractal_v2_quality"

# Keep this narrow for now so we do not block everything.
BLOCKED_SETUP_KEYWORDS = (
    "ASIA_CONTINUATION_iFVG_B_LONG",
)

# Do NOT block symbols in this safe version.
BLOCKED_SYMBOLS = set()

# Do NOT enforce strict session filtering yet.
ENABLE_SESSION_FILTER = False

# Optional session windows in ET, only active if ENABLE_SESSION_FILTER=True.
LONDON_START = time(2, 0)
LONDON_END = time(5, 30)

NY_AM_START = time(8, 30)
NY_AM_END = time(11, 30)

ASIA_START = time(18, 0)
ASIA_END = time(23, 59)

ASIA_START_2 = time(0, 0)
ASIA_END_2 = time(1, 30)

DIAG_DIR = Path("src/backtesting/event_engine/outputs")
DIAG_DIR.mkdir(parents=True, exist_ok=True)
DIAG_PATH = DIAG_DIR / "ict_fractal_v2_quality_filter_diagnostics.csv"


def _to_et_timestamp(ts):
    ts = pd.Timestamp(ts)

    if ts.tzinfo is None:
        ts = ts.tz_localize("UTC")

    return ts.tz_convert("America/New_York")


def _in_window(t, start, end):
    return start <= t <= end


def _in_allowed_session(ts) -> bool:
    if not ENABLE_SESSION_FILTER:
        return True

    t = _to_et_timestamp(ts).time()

    return (
        _in_window(t, LONDON_START, LONDON_END)
        or _in_window(t, NY_AM_START, NY_AM_END)
        or _in_window(t, ASIA_START, ASIA_END)
        or _in_window(t, ASIA_START_2, ASIA_END_2)
    )


def _get_attr_or_key(obj: Any, name: str, default=None):
    if obj is None:
        return default

    if isinstance(obj, dict):
        return obj.get(name, default)

    return getattr(obj, name, default)


def _set_attr_if_possible(obj: Any, name: str, value: Any):
    if isinstance(obj, dict):
        obj[name] = value
        return obj

    try:
        setattr(obj, name, value)
    except Exception:
        pass

    return obj


def _extract_side(order: Any) -> str:
    value = _get_attr_or_key(order, "side", "")
    return str(value or "").upper()


def _extract_trade_type(order: Any) -> str:
    parts = []

    for field in (
        "trade_type",
        "reason",
        "setup",
        "signal_name",
        "model_signal",
        "strategy_name",
    ):
        value = _get_attr_or_key(order, field, None)
        if value:
            parts.append(str(value))

    return "|".join(parts)


def _extract_score(order: Any):
    for field in ("setup_score", "trend_score", "score", "signal_score"):
        value = _get_attr_or_key(order, field, None)
        if value is None:
            continue
        try:
            return float(value)
        except Exception:
            pass

    return None


def _empty_diag():
    return {
        "base_orders_seen": 0,
        "accepted": 0,
        "blocked_symbol": 0,
        "blocked_session": 0,
        "blocked_setup_keyword": 0,
        "long_seen": 0,
        "short_seen": 0,
        "missing_trade_type": 0,
        "missing_score": 0,
        "sample_trade_types": "",
    }


class ICTFractalV2QualityAdapter:
    """
    Safe wrapper around the existing ICTFractalV2Adapter.

    This version is deliberately conservative with filtering so we avoid
    accidentally blocking all trades.
    """

    name = STRATEGY_NAME
    strategy_name = STRATEGY_NAME

    def __init__(self):
        from src.strategies.adapters.ict_fractal_v2_event_adapter import (
            ICTFractalV2Adapter,
        )

        self.base = ICTFractalV2Adapter()
        self.diag = _empty_diag()
        self.sample_trade_types = []

    def _write_diag(self):
        self.diag["sample_trade_types"] = " || ".join(self.sample_trade_types[:25])
        pd.DataFrame([self.diag]).to_csv(DIAG_PATH, index=False)

    def build_features(self, symbol, df):
        if hasattr(self.base, "build_features"):
            return self.base.build_features(symbol, df)
        return df.copy()

    def build_features_with_args(self, symbol, df, args=None):
        if hasattr(self.base, "build_features_with_args"):
            return self.base.build_features_with_args(symbol, df, args)
        if hasattr(self.base, "build_features"):
            return self.base.build_features(symbol, df)
        return df.copy()

    def signal_for_row(self, symbol, row, history, spec, profile, args):
        # Support both positional and keyword-compatible base adapters.
        try:
            order = self.base.signal_for_row(
                symbol=symbol,
                row=row,
                history=history,
                spec=spec,
                profile=profile,
                args=args,
            )
        except TypeError:
            order = self.base.signal_for_row(symbol, row, history, spec, profile, args)

        if order is None:
            return None

        self.diag["base_orders_seen"] += 1

        side = _extract_side(order)
        trade_type = _extract_trade_type(order)
        score = _extract_score(order)

        if side == "LONG":
            self.diag["long_seen"] += 1
        elif side == "SHORT":
            self.diag["short_seen"] += 1

        if not trade_type:
            self.diag["missing_trade_type"] += 1
        elif len(self.sample_trade_types) < 25 and trade_type not in self.sample_trade_types:
            self.sample_trade_types.append(trade_type)

        if score is None:
            self.diag["missing_score"] += 1

        symbol = str(symbol).upper()

        if symbol in BLOCKED_SYMBOLS:
            self.diag["blocked_symbol"] += 1
            self._write_diag()
            return None

        ts = getattr(row, "name", None)
        if ts is not None and not _in_allowed_session(ts):
            self.diag["blocked_session"] += 1
            self._write_diag()
            return None

        for keyword in BLOCKED_SETUP_KEYWORDS:
            if keyword and keyword in trade_type:
                self.diag["blocked_setup_keyword"] += 1
                self._write_diag()
                return None

        _set_attr_if_possible(order, "strategy_name", self.name)

        existing_reason = _get_attr_or_key(order, "reason", "")
        if existing_reason:
            _set_attr_if_possible(order, "reason", f"{existing_reason}|v2_quality_safe")
        else:
            _set_attr_if_possible(order, "reason", "v2_quality_safe")

        self.diag["accepted"] += 1
        self._write_diag()

        return order
