# ICT Fractal V2 Quality Filter Fix

This replaces:

```text
src/strategies/adapters/ict_fractal_v2_quality_event_adapter.py
```

The first quality adapter was too strict and produced 0 trades.

This fixed version:
- wraps `ICTFractalV2Adapter`
- does not require exact setup-name matches
- does not enforce strict session filters yet
- does not block MGC yet
- only blocks the known weak keyword if it appears
- writes diagnostics here:

```text
src/backtesting/event_engine/outputs/ict_fractal_v2_quality_filter_diagnostics.csv
```

## Install

```bash
cd /Users/Abdullahi/trading-project/trading_system

unzip /path/to/ict_fractal_v2_quality_filter_fix.zip -d /tmp/ict_quality_fix

cp -R /tmp/ict_quality_fix/src/* src/
```

## Rerun

```bash
PYTHONPATH=. python -m src.backtesting.event_engine.run_event_backtest \
  --strategy ict_fractal_v2_quality \
  --symbols MNQ MES MYM MGC \
  --prop-profile apex_50k_pa \
  --days-back 365 \
  --timeframe 1m \
  --no-tail \
  --commission-per-contract-side 2.0 \
  --min-trend-score 4 \
  --target-r 10.0 \
  --min-planned-target-dollars 500 \
  --news-events src/strategies/manual/researched_prop_trend/news_events.csv \
  --output-prefix ict_fractal_v2_quality_365
```

Then inspect:

```bash
cat src/backtesting/event_engine/outputs/ict_fractal_v2_quality_filter_diagnostics.csv
```
