# Prop Dual Mode Lifecycle Simulator V7 Consistency Repair

Adds PA-only consistency repair mode.

When:
- minimum PA payout trading days are met
- minimum payout amount is met
- but 50% consistency fails

The same PA account keeps trading with reduced risk and a smaller daily profit target until consistency passes.

New options:
--disable-consistency-repair
--consistency-repair-risk-multiplier 0.50
--consistency-repair-daily-profit-target 250

Install:
cd /Users/Abdullahi/trading-project/trading_system
unzip /path/to/prop_dual_mode_lifecycle_v7_consistency_repair.zip -d /tmp/lifecycle_v7
cp -R /tmp/lifecycle_v7/src/* src/
