from __future__ import annotations

from dataclasses import dataclass
from datetime import time
from pathlib import Path
from typing import Optional

import pandas as pd


# =========================================================
# TOP BOTTOM TICKING V2 — ZONE-FIRST REBUILD
# =========================================================
#
# This rebuild fixes the major logic issue in the discovery build:
#
#   OLD DISCOVERY FLOW:
#       sweep / shift happens
#       then find recent RB
#       then enter from current candle
#
#   CORRECT INTENDED FLOW:
#       1. identify Rejection Block first
#       2. calculate CE
#       3. wait for price to return into RB/CE zone
#       4. require sweep at/near zone
#       5. require displacement MSS after CE interaction
#       6. enter with tight invalidation
#
# This file intentionally lives beside the old strategy:
#
#   OLD: src/strategies/manual/ict_top_bottom_ticking.py
#   NEW: src/strategies/manual/ict_top_bottom_ticking_v2.py
#
# The old strategy stays untouched.
# =========================================================


# =========================================================
# CONFIG
# =========================================================

TARGET_R = 4.0

# Stop buffer in raw points.
STOP_BUFFER = 0.10

# How close price must be to RB CE.
# 0.35 = within 35% of RB range around CE.
CE_TOLERANCE = 0.35

# How many bars a zone stays valid after it forms.
ZONE_EXPIRY_BARS = 80

# How many bars after CE touch we allow MSS confirmation.
CONFIRMATION_WINDOW_BARS = 15

# Local liquidity and MSS lookbacks.
SWEEP_LOOKBACK = 20
MSS_LOOKBACK = 6

# RB quality.
MIN_RB_ATR_MULTIPLE = 0.65
MIN_RB_BODY_RATIO = 0.35

# MSS quality.
MIN_MSS_ATR_MULTIPLE = 0.75
MIN_MSS_BODY_RATIO = 0.45

# Volatility gate.
MIN_VOLATILITY_RATIO = 0.45

# Signal throttling.
MAX_SIGNALS_PER_DAY = 3
MIN_BARS_BETWEEN_SIGNALS = 20

# ET session windows.
LONDON_KILLZONE = (time(2, 0), time(5, 30))
NY_AM = (time(8, 30), time(11, 30))
NY_PM = (time(13, 30), time(15, 30))

DIAG_DIR = Path("src/backtesting/event_engine/outputs")
DIAG_DIR.mkdir(parents=True, exist_ok=True)
DIAG_PATH = DIAG_DIR / "top_bottom_ticking_v2_zone_first_diagnostics.csv"


# =========================================================
# DATA STRUCTURES
# =========================================================

@dataclass
class RejectionZone:
    direction: str
    high: float
    low: float
    ce: float
    created_i: int
    created_ts: object
    touched_i: Optional[int] = None
    touched_ts: Optional[object] = None
    swept: bool = False
    sweep_i: Optional[int] = None
    sweep_ts: Optional[object] = None
    used: bool = False

    @property
    def width(self) -> float:
        return self.high - self.low

    def expired(self, i: int) -> bool:
        return (i - self.created_i) > ZONE_EXPIRY_BARS

    def touched(self) -> bool:
        return self.touched_i is not None


# =========================================================
# COLUMN / TIME HELPERS
# =========================================================

def _normalise_columns(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()

    rename_map = {
        "Open": "open",
        "High": "high",
        "Low": "low",
        "Close": "close",
        "Volume": "volume",
    }

    for old, new in rename_map.items():
        if old in out.columns and new not in out.columns:
            out[new] = out[old]

    required = ["open", "high", "low", "close"]
    missing = [c for c in required if c not in out.columns]

    if missing:
        raise ValueError(
            f"top_bottom_ticking_v2 missing required OHLC columns: {missing}. "
            f"Available columns: {list(out.columns)}"
        )

    return out


def _to_et_timestamp(ts):
    ts = pd.Timestamp(ts)
    if ts.tzinfo is None:
        ts = ts.tz_localize("UTC")
    return ts.tz_convert("America/New_York")


def allowed_session(ts) -> bool:
    ts_et = _to_et_timestamp(ts)
    t = ts_et.time()

    return (
        LONDON_KILLZONE[0] <= t <= LONDON_KILLZONE[1]
        or NY_AM[0] <= t <= NY_AM[1]
        or NY_PM[0] <= t <= NY_PM[1]
    )


# =========================================================
# BASIC INDICATORS
# =========================================================

def _atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
    high = df["high"]
    low = df["low"]
    close = df["close"]
    prev_close = close.shift(1)

    tr = pd.concat(
        [
            high - low,
            (high - prev_close).abs(),
            (low - prev_close).abs(),
        ],
        axis=1,
    ).max(axis=1)

    return tr.rolling(period, min_periods=period).mean()


def candle_range(candle) -> float:
    return float(candle.high) - float(candle.low)


def candle_body(candle) -> float:
    return abs(float(candle.close) - float(candle.open))


def candle_body_ratio(candle) -> float:
    rng = candle_range(candle)
    if rng <= 0:
        return 0.0
    return candle_body(candle) / rng


def is_bullish(candle) -> bool:
    return float(candle.close) > float(candle.open)


def is_bearish(candle) -> bool:
    return float(candle.close) < float(candle.open)


def volatility_ok(current_atr, rolling_atr) -> bool:
    if pd.isna(current_atr) or pd.isna(rolling_atr):
        return False
    return float(current_atr) >= float(rolling_atr) * MIN_VOLATILITY_RATIO


# =========================================================
# REJECTION BLOCK / CE LOGIC
# =========================================================

def calculate_ce(high: float, low: float) -> float:
    return (float(high) + float(low)) / 2.0


def valid_rejection_candle(candle, atr: float) -> bool:
    if pd.isna(atr) or atr <= 0:
        return False

    return (
        candle_range(candle) >= float(atr) * MIN_RB_ATR_MULTIPLE
        and candle_body_ratio(candle) >= MIN_RB_BODY_RATIO
    )


def detect_new_rejection_zone(df: pd.DataFrame, i: int, atr: float) -> Optional[RejectionZone]:
    """
    Zone-first RB detection.

    We define:
      - bullish zone from a bullish rejection candle after taking local lows
      - bearish zone from a bearish rejection candle after taking local highs

    This is intentionally simple and measurable. Later we can make HTF/MTF.
    """
    if i - SWEEP_LOOKBACK < 0:
        return None

    candle = df.iloc[i]
    ts = candle.name

    if not valid_rejection_candle(candle, atr):
        return None

    prior_low = float(df.iloc[i - SWEEP_LOOKBACK:i]["low"].min())
    prior_high = float(df.iloc[i - SWEEP_LOOKBACK:i]["high"].max())

    swept_low = float(candle.low) < prior_low
    swept_high = float(candle.high) > prior_high

    # Bullish RB: price raids lows then rejects upward.
    if swept_low and is_bullish(candle):
        return RejectionZone(
            direction="long",
            high=float(candle.high),
            low=float(candle.low),
            ce=calculate_ce(candle.high, candle.low),
            created_i=i,
            created_ts=ts,
        )

    # Bearish RB: price raids highs then rejects downward.
    if swept_high and is_bearish(candle):
        return RejectionZone(
            direction="short",
            high=float(candle.high),
            low=float(candle.low),
            ce=calculate_ce(candle.high, candle.low),
            created_i=i,
            created_ts=ts,
        )

    return None


def price_touches_zone(candle, zone: RejectionZone) -> bool:
    return float(candle.low) <= zone.high and float(candle.high) >= zone.low


def price_touches_ce(candle, zone: RejectionZone) -> bool:
    if zone.width <= 0:
        return False

    tolerance = zone.width * CE_TOLERANCE

    # Candle trades through CE area.
    return (
        float(candle.low) <= zone.ce + tolerance
        and float(candle.high) >= zone.ce - tolerance
    )


def mark_zone_touch(zone: RejectionZone, candle, i: int):
    if zone.touched_i is None:
        zone.touched_i = i
        zone.touched_ts = candle.name


# =========================================================
# SWEEP + MSS AFTER CE TOUCH
# =========================================================

def sweep_after_touch(df: pd.DataFrame, i: int, zone: RejectionZone) -> bool:
    """
    After price returns to CE/zone, require local internal liquidity sweep.

    Long: sweep a recent low.
    Short: sweep a recent high.
    """
    if i - SWEEP_LOOKBACK < 0:
        return False

    candle = df.iloc[i]

    if zone.direction == "long":
        prior_low = float(df.iloc[i - SWEEP_LOOKBACK:i]["low"].min())
        return float(candle.low) < prior_low

    prior_high = float(df.iloc[i - SWEEP_LOOKBACK:i]["high"].max())
    return float(candle.high) > prior_high


def valid_mss_displacement(candle, atr: float) -> bool:
    if pd.isna(atr) or atr <= 0:
        return False

    return (
        candle_range(candle) >= float(atr) * MIN_MSS_ATR_MULTIPLE
        and candle_body_ratio(candle) >= MIN_MSS_BODY_RATIO
    )


def mss_after_touch(df: pd.DataFrame, i: int, zone: RejectionZone, atr: float) -> bool:
    """
    MSS must happen after CE/zone touch and within confirmation window.

    Long: body close above recent local high.
    Short: body close below recent local low.
    """
    if zone.touched_i is None:
        return False

    if i <= zone.touched_i:
        return False

    if (i - zone.touched_i) > CONFIRMATION_WINDOW_BARS:
        return False

    if i - MSS_LOOKBACK < 0:
        return False

    candle = df.iloc[i]

    if not valid_mss_displacement(candle, atr):
        return False

    if zone.direction == "long":
        prior_high = float(df.iloc[i - MSS_LOOKBACK:i]["high"].max())
        return float(candle.close) > prior_high and is_bullish(candle)

    prior_low = float(df.iloc[i - MSS_LOOKBACK:i]["low"].min())
    return float(candle.close) < prior_low and is_bearish(candle)


# =========================================================
# OPTIONAL FVG TAGGING
# =========================================================

def bullish_fvg(c1, c2, c3) -> bool:
    return float(c1.high) < float(c3.low)


def bearish_fvg(c1, c2, c3) -> bool:
    return float(c1.low) > float(c3.high)


def recent_fvg_tag(df: pd.DataFrame, i: int, direction: str, lookback: int = 5) -> bool:
    start = max(2, i - lookback + 1)

    for j in range(i, start - 1, -1):
        if direction == "long" and bullish_fvg(df.iloc[j - 2], df.iloc[j - 1], df.iloc[j]):
            return True
        if direction == "short" and bearish_fvg(df.iloc[j - 2], df.iloc[j - 1], df.iloc[j]):
            return True

    return False


# =========================================================
# ORDER PLAN
# =========================================================

def build_trade_plan(candle, zone: RejectionZone, fvg_tag: bool) -> Optional[dict]:
    entry = float(candle.close)

    if zone.direction == "long":
        stop = float(zone.low) - STOP_BUFFER
        risk = entry - stop
        if risk <= 0:
            return None

        return {
            "timestamp": candle.name,
            "side": "LONG",
            "entry": entry,
            "stop": stop,
            "target": entry + (risk * TARGET_R),
            "risk": risk,
            "setup": (
                "top_bottom_ticking_v2_zone_first_long_"
                + ("fvg_" if fvg_tag else "")
                + "ce_sweep_mss"
            ),
            "zone_created_ts": zone.created_ts,
            "zone_high": zone.high,
            "zone_low": zone.low,
            "zone_ce": zone.ce,
        }

    stop = float(zone.high) + STOP_BUFFER
    risk = stop - entry
    if risk <= 0:
        return None

    return {
        "timestamp": candle.name,
        "side": "SHORT",
        "entry": entry,
        "stop": stop,
        "target": entry - (risk * TARGET_R),
        "risk": risk,
        "setup": (
            "top_bottom_ticking_v2_zone_first_short_"
            + ("fvg_" if fvg_tag else "")
            + "ce_sweep_mss"
        ),
        "zone_created_ts": zone.created_ts,
        "zone_high": zone.high,
        "zone_low": zone.low,
        "zone_ce": zone.ce,
    }


# =========================================================
# DIAGNOSTICS
# =========================================================

def _empty_diag() -> dict:
    return {
        "bars_seen": 0,
        "blocked_session": 0,
        "blocked_atr": 0,
        "blocked_volatility": 0,
        "zones_created_long": 0,
        "zones_created_short": 0,
        "zones_expired": 0,
        "zone_touches": 0,
        "ce_touches": 0,
        "sweeps_after_touch": 0,
        "mss_after_touch": 0,
        "fvg_tags": 0,
        "long_signals": 0,
        "short_signals": 0,
    }


def _write_diag(diag: dict):
    pd.DataFrame([diag]).to_csv(DIAG_PATH, index=False)


# =========================================================
# MAIN SIGNAL GENERATOR
# =========================================================

def generate_top_bottom_ticking_v2_signals(df: pd.DataFrame) -> pd.DataFrame:
    """
    Zone-first signal generator.

    This produces planned orders only. The event engine handles:
      - position sizing
      - fills
      - commissions
      - stops/targets
      - daily locks
      - prop drawdown logic
    """
    df = _normalise_columns(df)

    if "atr" not in df.columns:
        df["atr"] = _atr(df, 14)

    df["rolling_atr"] = df["atr"].rolling(50, min_periods=50).mean()

    active_zones: list[RejectionZone] = []
    trades: list[dict] = []
    diag = _empty_diag()

    current_day = None
    signals_today = 0
    last_signal_i = -999999

    for i in range(60, len(df) - 1):
        diag["bars_seen"] += 1

        candle = df.iloc[i]
        ts = candle.name
        ts_et = _to_et_timestamp(ts)

        if current_day != ts_et.date():
            current_day = ts_et.date()
            signals_today = 0

        if not allowed_session(ts):
            diag["blocked_session"] += 1
            continue

        atr = candle.atr
        rolling_atr = candle.rolling_atr

        if pd.isna(atr) or pd.isna(rolling_atr):
            diag["blocked_atr"] += 1
            continue

        if not volatility_ok(atr, rolling_atr):
            diag["blocked_volatility"] += 1
            continue

        # Remove old/used zones.
        still_active = []
        for z in active_zones:
            if z.used:
                continue
            if z.expired(i):
                diag["zones_expired"] += 1
                continue
            still_active.append(z)
        active_zones = still_active

        # 1. Create new zone first.
        new_zone = detect_new_rejection_zone(df, i, atr)
        if new_zone is not None:
            active_zones.append(new_zone)
            if new_zone.direction == "long":
                diag["zones_created_long"] += 1
            else:
                diag["zones_created_short"] += 1

        if signals_today >= MAX_SIGNALS_PER_DAY:
            continue

        if (i - last_signal_i) < MIN_BARS_BETWEEN_SIGNALS:
            continue

        # 2. Existing zones must be touched at CE/zone before MSS.
        for zone in active_zones:
            if zone.used:
                continue

            if not price_touches_zone(candle, zone):
                continue

            diag["zone_touches"] += 1

            if not price_touches_ce(candle, zone):
                continue

            diag["ce_touches"] += 1
            mark_zone_touch(zone, candle, i)

            # 3. After CE/touch, require internal sweep.
            if sweep_after_touch(df, i, zone):
                zone.swept = True
                zone.sweep_i = i
                zone.sweep_ts = ts
                diag["sweeps_after_touch"] += 1

            if not zone.swept:
                continue

            # 4. MSS after CE touch.
            if not mss_after_touch(df, i, zone, atr):
                continue

            diag["mss_after_touch"] += 1

            fvg_tag = recent_fvg_tag(df, i, zone.direction, lookback=5)
            if fvg_tag:
                diag["fvg_tags"] += 1

            plan = build_trade_plan(candle, zone, fvg_tag=fvg_tag)
            if plan is None:
                continue

            trades.append(plan)
            zone.used = True
            signals_today += 1
            last_signal_i = i

            if zone.direction == "long":
                diag["long_signals"] += 1
            else:
                diag["short_signals"] += 1

            # One signal per bar.
            break

    _write_diag(diag)

    return pd.DataFrame(trades)
