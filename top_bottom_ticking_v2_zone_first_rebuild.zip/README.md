# Top Bottom Ticking V2 Zone-First Rebuild

This replaces:

```text
src/strategies/manual/ict_top_bottom_ticking_v2.py
```

It rebuilds the logic into:

```text
RB/CE zone first
→ price returns to CE
→ sweep at/near zone
→ MSS after CE
→ entry
```

Install:

```bash
cd /Users/Abdullahi/trading-project/trading_system

unzip /path/to/top_bottom_ticking_v2_zone_first_rebuild.zip -d /tmp/tbt_v2_zone_first

cp -R /tmp/tbt_v2_zone_first/src/* src/
```

Smoke test:

```bash
PYTHONPATH=. python -m src.backtesting.event_engine.run_event_backtest \
  --strategy top_bottom_ticking_v2 \
  --symbols MNQ \
  --prop-profile apex_50k_pa \
  --days-back 60 \
  --timeframe 1m \
  --no-tail \
  --commission-per-contract-side 2.0 \
  --target-r 2.0 \
  --min-planned-target-dollars 500 \
  --news-events src/strategies/manual/researched_prop_trend/news_events.csv \
  --output-prefix top_bottom_ticking_v2_zone_first_smoke
```

Diagnostics:

```bash
cat src/backtesting/event_engine/outputs/top_bottom_ticking_v2_zone_first_diagnostics.csv
```
