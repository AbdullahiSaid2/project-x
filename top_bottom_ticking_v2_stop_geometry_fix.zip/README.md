# Top Bottom Ticking V2 Stop Geometry Fix

This fixes the major issue from the zone-first smoke test:

```text
MNQ stops were too tight, sometimes around 1 point.
That created huge contract counts and commission drag.
```

This package replaces:

```text
src/strategies/manual/ict_top_bottom_ticking_v2.py
src/strategies/adapters/top_bottom_ticking_v2_event_adapter.py
```

## Install

```bash
cd /Users/Abdullahi/trading-project/trading_system

unzip /path/to/top_bottom_ticking_v2_stop_geometry_fix.zip -d /tmp/tbt_v2_stopgeo

cp -R /tmp/tbt_v2_stopgeo/src/* src/
```

## Smoke test

```bash
PYTHONPATH=. python -m src.backtesting.event_engine.run_event_backtest \
  --strategy top_bottom_ticking_v2 \
  --symbols MNQ \
  --prop-profile apex_50k_pa \
  --days-back 60 \
  --timeframe 1m \
  --no-tail \
  --commission-per-contract-side 2.0 \
  --target-r 2.0 \
  --min-planned-target-dollars 500 \
  --news-events src/strategies/manual/researched_prop_trend/news_events.csv \
  --output-prefix top_bottom_ticking_v2_stopgeo_smoke
```

Check diagnostics:

```bash
cat src/backtesting/event_engine/outputs/top_bottom_ticking_v2_zone_first_diagnostics.csv
```
