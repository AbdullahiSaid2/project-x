# Prop Dual Mode Lifecycle Simulator V8 Payout Acceleration

Adds payout acceleration controls:

--pa-payout-buffer-override
--pa-acceleration-daily-profit-target

Use this to test faster PA payouts without changing strategy code.

Recommended first faster payout test:

PYTHONPATH=. python -m src.strategies.manual.researched_prop_trend.prop_dual_mode_lifecycle_simulator \
  --eval-trade-log src/backtesting/event_engine/outputs/ict_fractal_v2_eval_365_event_trade_log.csv \
  --pa-trade-log src/backtesting/event_engine/outputs/ict_fractal_v2_quality_be_partial_no_mym_long_event_trade_log.csv \
  --profile apex_50k_dual_mode \
  --eval-risk-multiplier 2.5 \
  --pa-risk-multiplier 2.0 \
  --target-payout-frequency-days 7 \
  --min-weekly-payout-amount 1000 \
  --pa-min-payout-trading-days 5 \
  --pa-consistency-rule-pct 50 \
  --pa-min-payout-amount 250 \
  --pa-max-payout-amount 2000 \
  --pa-payout-buffer-override 1000 \
  --pa-acceleration-daily-profit-target 500 \
  --disable-consistency-repair \
  --aggressive-eval-until-pass

Install:
cd /Users/Abdullahi/trading-project/trading_system
unzip /path/to/prop_dual_mode_lifecycle_v8_payout_acceleration.zip -d /tmp/lifecycle_v8
cp -R /tmp/lifecycle_v8/src/* src/
