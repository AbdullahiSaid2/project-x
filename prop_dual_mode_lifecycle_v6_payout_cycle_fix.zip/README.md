# Prop Dual Mode Lifecycle Simulator V6 Payout Cycle Fix

Fixes payout logic so payouts are based on profit since the last payout, not fixed 10-day reporting windows.

Correct flow:
eval pass -> PA starts -> payout cycle accumulates -> payout -> payout cycle resets -> same PA continues.

Install:
cd /Users/Abdullahi/trading-project/trading_system
unzip /path/to/prop_dual_mode_lifecycle_v6_payout_cycle_fix.zip -d /tmp/lifecycle_v6
cp -R /tmp/lifecycle_v6/src/* src/
