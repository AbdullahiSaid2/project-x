# Prop Dual Mode Lifecycle Simulator V9 PA Volatility Smoother

Adds PA-only volatility smoother.

Risk is reduced temporarily when:
- previous PA day profit is high
- consecutive losses are reached
- immediately after payout
- retained buffer is thin

New options:
--disable-pa-volatility-smoother
--smoother-after-profit-day-threshold 750
--smoother-after-profit-risk-multiplier 0.75
--smoother-loss-streak-threshold 2
--smoother-after-loss-risk-multiplier 0.50
--smoother-post-payout-risk-multiplier 0.50
--smoother-buffer-floor 1000
--smoother-buffer-risk-multiplier 0.50

Recommended test:
PYTHONPATH=. python -m src.strategies.manual.researched_prop_trend.prop_dual_mode_lifecycle_simulator \
  --eval-trade-log src/backtesting/event_engine/outputs/ict_fractal_v2_eval_365_event_trade_log.csv \
  --pa-trade-log src/backtesting/event_engine/outputs/ict_fractal_v2_quality_be_partial_no_mym_long_event_trade_log.csv \
  --profile apex_50k_dual_mode \
  --eval-risk-multiplier 2.5 \
  --pa-risk-multiplier 3.0 \
  --target-payout-frequency-days 7 \
  --min-weekly-payout-amount 1000 \
  --pa-min-payout-trading-days 5 \
  --pa-consistency-rule-pct 50 \
  --pa-min-payout-amount 250 \
  --pa-max-payout-amount 2000 \
  --disable-consistency-repair \
  --aggressive-eval-until-pass
