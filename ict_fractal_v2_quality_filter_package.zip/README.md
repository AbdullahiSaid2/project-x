# ICT Fractal V2 Quality Filter Package

This package adds a new strategy adapter:

```text
--strategy ict_fractal_v2_quality
```

It does **not** overwrite:

```text
--strategy ict_fractal
--strategy ict_fractal_v2
```

## What it improves

Based on your latest 365-day ICT Fractal V2 result:

```text
Trades: 121
Net PnL: +$7,050.84
MNQ: +$4,634.70
MYM: +$2,230.89
MES: +$185.25
MGC: no useful accepted trades
```

Findings:

```text
SHORT setups were strongest.
ASIA_CONTINUATION_iFVG_B_SHORT was strong.
LONDON_CONTINUATION_iFVG_A_SHORT was strong.
LONDON_CONTINUATION_C2C3_A_SHORT was strong.
ASIA_CONTINUATION_iFVG_B_LONG was weak.
```

This adapter:
- wraps the existing ICT Fractal adapter
- blocks weak long setup family
- keeps/permits strongest short continuation setups
- blocks MGC for now
- applies session filters
- adds daily signal caps
- reduces clustered entries

## Install

```bash
cd /Users/Abdullahi/trading-project/trading_system

unzip /path/to/ict_fractal_v2_quality_filter_package.zip -d /tmp/ict_fractal_v2_quality

cp -R /tmp/ict_fractal_v2_quality/src/* src/
```

## Patch run_event_backtest.py

Open:

```text
src/backtesting/event_engine/run_event_backtest.py
```

Inside `load_adapter(name: str)`, add:

```python
if name == "ict_fractal_v2_quality":
    from src.strategies.adapters.ict_fractal_v2_quality_event_adapter import (
        ICTFractalV2QualityAdapter,
    )
    return ICTFractalV2QualityAdapter()
```

## Run

```bash
PYTHONPATH=. python -m src.backtesting.event_engine.run_event_backtest \
  --strategy ict_fractal_v2_quality \
  --symbols MNQ MES MYM MGC \
  --prop-profile apex_50k_pa \
  --days-back 365 \
  --timeframe 1m \
  --no-tail \
  --commission-per-contract-side 2.0 \
  --min-trend-score 4 \
  --target-r 10.0 \
  --min-planned-target-dollars 500 \
  --news-events src/strategies/manual/researched_prop_trend/news_events.csv \
  --output-prefix ict_fractal_v2_quality_365
```

## What to compare

Compare against previous:

```text
ict_fractal_v2_365
```

Key metrics:
- Net PnL
- trade count
- win rate
- daily lock counts
- consecutive loss days
- rejected signal count
- symbol contribution
