from __future__ import annotations

import math
from dataclasses import dataclass
from datetime import time
from typing import Any, Optional

import pandas as pd


# =========================================================
# ICT FRACTAL V2 QUALITY FILTER ADAPTER
# =========================================================
#
# Purpose:
#   Improve ict_fractal_v2 based on the 365-day run findings.
#
# Findings from latest run:
#
#   Total net PnL: +$7,050.84
#
#   Strong side:
#       SHORT: +$5,572.59
#
#   Weaker side:
#       LONG: +$1,478.25
#
#   Strong setup families:
#       ASIA_CONTINUATION_iFVG_B_SHORT
#       LONDON_CONTINUATION_iFVG_A_SHORT
#       LONDON_CONTINUATION_C2C3_A_SHORT
#
#   Weak setup to block:
#       ASIA_CONTINUATION_iFVG_B_LONG
#
#   Most profit came from:
#       daily_equity_profit_lock
#
#   Meaning:
#       The model is already useful, but quality control matters.
#
# This adapter is intentionally a wrapper around the original ict_fractal
# adapter. It does NOT overwrite the original strategy logic.
#
# It:
#   1. Loads the existing ICTFractalAdapter.
#   2. Applies extra setup-quality filters.
#   3. Blocks weak long setup families.
#   4. Keeps strongest short-continuation setups.
#   5. Adds session and symbol risk controls.
#
# Strategy name:
#
#   --strategy ict_fractal_v2_quality
#
# =========================================================


# =========================================================
# CONFIG
# =========================================================

STRATEGY_NAME = "ict_fractal_v2_quality"

# Strong setup families from analysis.
PREFERRED_SHORT_KEYWORDS = (
    "ASIA_CONTINUATION_iFVG_B_SHORT",
    "LONDON_CONTINUATION_iFVG_A_SHORT",
    "LONDON_CONTINUATION_C2C3_A_SHORT",
)

# Weak setup families to block.
BLOCKED_SETUP_KEYWORDS = (
    "ASIA_CONTINUATION_iFVG_B_LONG",
)

# Allow these long setup types only if score is strong enough.
# We do not kill all longs because the long side was still positive overall.
LONG_MIN_SCORE = 5.0

# Shorts were strongest. They can pass at slightly lower score.
SHORT_MIN_SCORE = 4.0

# General minimum setup score fallback.
DEFAULT_MIN_SCORE = 4.0

# Symbol filters from current evidence.
# MGC had no useful accepted trades in latest run, so skip for now.
BLOCKED_SYMBOLS = {
    "MGC",
}

# Keep core equity index symbols.
ALLOWED_SYMBOLS = {
    "MNQ",
    "MES",
    "MYM",
}

# Session windows in ET.
# These match ICT continuation windows but avoid late dead periods.
LONDON_START = time(2, 0)
LONDON_END = time(5, 30)

NY_AM_START = time(8, 30)
NY_AM_END = time(11, 30)

# Asia continuation is allowed because ASIA short iFVG was strong.
ASIA_START = time(18, 0)
ASIA_END = time(23, 59)

ASIA_START_2 = time(0, 0)
ASIA_END_2 = time(1, 30)

# Daily signal throttles at adapter level.
MAX_SIGNALS_PER_SYMBOL_PER_DAY = 4
MAX_TOTAL_SIGNALS_PER_DAY = 8

# Prevent over-clustering.
MIN_MINUTES_BETWEEN_SYMBOL_SIGNALS = 15

# Optional: keep shorts and longs both enabled, but longs are stricter.
ENABLE_LONGS = True
ENABLE_SHORTS = True


# =========================================================
# HELPERS
# =========================================================

def _to_et_timestamp(ts):
    ts = pd.Timestamp(ts)

    if ts.tzinfo is None:
        ts = ts.tz_localize("UTC")

    return ts.tz_convert("America/New_York")


def _date_et(ts):
    return _to_et_timestamp(ts).date()


def _time_et(ts):
    return _to_et_timestamp(ts).time()


def _in_window(t, start, end):
    return start <= t <= end


def _in_allowed_session(ts) -> bool:
    t = _time_et(ts)

    in_london = _in_window(t, LONDON_START, LONDON_END)
    in_ny_am = _in_window(t, NY_AM_START, NY_AM_END)
    in_asia = _in_window(t, ASIA_START, ASIA_END) or _in_window(t, ASIA_START_2, ASIA_END_2)

    return in_london or in_ny_am or in_asia


def _normalise_side(side: Any) -> str:
    s = str(side or "").upper()

    if s in {"BUY", "BULL", "BULLISH", "LONG"}:
        return "LONG"

    if s in {"SELL", "BEAR", "BEARISH", "SHORT"}:
        return "SHORT"

    return s


def _get_attr_or_key(obj: Any, name: str, default=None):
    if obj is None:
        return default

    if isinstance(obj, dict):
        return obj.get(name, default)

    return getattr(obj, name, default)


def _extract_trade_type(order: Any) -> str:
    for field in ("trade_type", "setup", "reason", "signal_name", "model_signal"):
        value = _get_attr_or_key(order, field, None)
        if value:
            return str(value)
    return ""


def _extract_score(order: Any) -> float:
    for field in ("setup_score", "trend_score", "score", "signal_score"):
        value = _get_attr_or_key(order, field, None)
        if value is None:
            continue
        try:
            return float(value)
        except Exception:
            pass

    return DEFAULT_MIN_SCORE


def _set_attr_if_possible(obj: Any, name: str, value: Any):
    if isinstance(obj, dict):
        obj[name] = value
        return obj

    try:
        setattr(obj, name, value)
    except Exception:
        pass

    return obj


def _minutes_between(a, b) -> float:
    if a is None or b is None:
        return 999999.0

    aa = pd.Timestamp(a)
    bb = pd.Timestamp(b)

    if aa.tzinfo is None:
        aa = aa.tz_localize("UTC")
    if bb.tzinfo is None:
        bb = bb.tz_localize("UTC")

    return abs((aa - bb).total_seconds()) / 60.0


# =========================================================
# QUALITY FILTER
# =========================================================

@dataclass
class FilterDecision:
    allowed: bool
    reason: str


class ICTFractalQualityFilter:
    def __init__(self):
        self.symbol_day_counts: dict[tuple[str, object], int] = {}
        self.total_day_counts: dict[object, int] = {}
        self.last_symbol_signal_ts: dict[str, object] = {}

    def reset(self):
        self.symbol_day_counts.clear()
        self.total_day_counts.clear()
        self.last_symbol_signal_ts.clear()

    def decide(self, symbol: str, row, order: Any) -> FilterDecision:
        if order is None:
            return FilterDecision(False, "no_order")

        symbol = str(symbol).upper()

        if symbol in BLOCKED_SYMBOLS:
            return FilterDecision(False, f"blocked_symbol_{symbol}")

        if ALLOWED_SYMBOLS and symbol not in ALLOWED_SYMBOLS:
            return FilterDecision(False, f"not_allowed_symbol_{symbol}")

        ts = getattr(row, "name", None)
        if ts is None:
            ts = _get_attr_or_key(order, "timestamp", None)

        if ts is None:
            return FilterDecision(False, "missing_timestamp")

        if not _in_allowed_session(ts):
            return FilterDecision(False, "blocked_session")

        side = _normalise_side(_get_attr_or_key(order, "side", ""))
        trade_type = _extract_trade_type(order)
        score = _extract_score(order)

        if side == "LONG" and not ENABLE_LONGS:
            return FilterDecision(False, "longs_disabled")

        if side == "SHORT" and not ENABLE_SHORTS:
            return FilterDecision(False, "shorts_disabled")

        # Block known weak setup families.
        for bad in BLOCKED_SETUP_KEYWORDS:
            if bad in trade_type:
                return FilterDecision(False, f"blocked_setup_{bad}")

        # Side-specific score gates.
        if side == "LONG" and score < LONG_MIN_SCORE:
            return FilterDecision(False, f"long_score_too_low_{score}")

        if side == "SHORT" and score < SHORT_MIN_SCORE:
            return FilterDecision(False, f"short_score_too_low_{score}")

        # If short setup is from a preferred family, allow it.
        # If not preferred, still allow but only if score is stronger.
        if side == "SHORT":
            is_preferred_short = any(k in trade_type for k in PREFERRED_SHORT_KEYWORDS)
            if not is_preferred_short and score < (SHORT_MIN_SCORE + 1.0):
                return FilterDecision(False, "non_preferred_short_score_too_low")

        # Daily throttles.
        day = _date_et(ts)
        symbol_key = (symbol, day)

        symbol_count = self.symbol_day_counts.get(symbol_key, 0)
        total_count = self.total_day_counts.get(day, 0)

        if symbol_count >= MAX_SIGNALS_PER_SYMBOL_PER_DAY:
            return FilterDecision(False, "symbol_daily_signal_cap")

        if total_count >= MAX_TOTAL_SIGNALS_PER_DAY:
            return FilterDecision(False, "total_daily_signal_cap")

        last_ts = self.last_symbol_signal_ts.get(symbol)
        if _minutes_between(ts, last_ts) < MIN_MINUTES_BETWEEN_SYMBOL_SIGNALS:
            return FilterDecision(False, "too_close_to_previous_symbol_signal")

        self.symbol_day_counts[symbol_key] = symbol_count + 1
        self.total_day_counts[day] = total_count + 1
        self.last_symbol_signal_ts[symbol] = ts

        return FilterDecision(True, "accepted")


# =========================================================
# ADAPTER
# =========================================================

class ICTFractalV2QualityAdapter:
    """
    Wrapper around the existing ICTFractalAdapter.

    It calls the original adapter first, then applies additional quality filters.
    """

    name = STRATEGY_NAME
    strategy_name = STRATEGY_NAME

    def __init__(self):
        from src.strategies.adapters.ict_fractal_event_adapter import (
            ICTFractalAdapter,
        )

        self.base = ICTFractalAdapter()
        self.filter = ICTFractalQualityFilter()

    def build_features(self, symbol, df):
        if hasattr(self.base, "build_features"):
            return self.base.build_features(symbol, df)
        return df.copy()

    def build_features_with_args(self, symbol, df, args=None):
        if hasattr(self.base, "build_features_with_args"):
            return self.base.build_features_with_args(symbol, df, args)
        if hasattr(self.base, "build_features"):
            return self.base.build_features(symbol, df)
        return df.copy()

    def signal_for_row(self, symbol, row, history, spec, profile, args):
        order = self.base.signal_for_row(
            symbol=symbol,
            row=row,
            history=history,
            spec=spec,
            profile=profile,
            args=args,
        )

        decision = self.filter.decide(symbol, row, order)

        if not decision.allowed:
            return None

        # Mark accepted strategy as V2 quality while preserving original reason/type.
        _set_attr_if_possible(order, "strategy_name", self.name)

        existing_reason = _get_attr_or_key(order, "reason", "")
        if existing_reason:
            _set_attr_if_possible(order, "reason", f"{existing_reason}|v2_quality")
        else:
            _set_attr_if_possible(order, "reason", "v2_quality")

        return order
