# ICT Fractal V2 Eval Package

Adds a separate eval-passing strategy:

```text
--strategy ict_fractal_v2_eval
```

## Why

Your current PA strategy is good for payout farming:

```text
ict_fractal_v2_quality
BE @ 1R
50% partial @ 2R
block MYM LONG
```

But it is low-frequency, so eval takes too long.

This package creates a faster eval variant that is more permissive.

## Files

```text
src/strategies/adapters/ict_fractal_v2_eval_event_adapter.py
```

If included in this package, also replace:

```text
src/backtesting/event_engine/run_event_backtest.py
```

so the engine recognises `ict_fractal_v2_eval`.

## Install

```bash
cd /Users/Abdullahi/trading-project/trading_system

unzip /path/to/ict_fractal_v2_eval_package.zip -d /tmp/ict_eval

cp -R /tmp/ict_eval/src/* src/
```

## Run eval backtest

```bash
PYTHONPATH=. python -m src.backtesting.event_engine.run_event_backtest \
  --strategy ict_fractal_v2_eval \
  --symbols MNQ MYM MES \
  --prop-profile apex_50k_pa \
  --days-back 365 \
  --timeframe 1m \
  --no-tail \
  --commission-per-contract-side 2.0 \
  --min-trend-score 3 \
  --target-r 10.0 \
  --min-planned-target-dollars 250 \
  --enable-breakeven \
  --breakeven-trigger-r 1.0 \
  --enable-partials \
  --partial-trigger-r 2.0 \
  --partial-close-pct 0.50 \
  --news-events src/strategies/manual/researched_prop_trend/news_events.csv \
  --output-prefix ict_fractal_v2_eval_365
```

## Then compare lifecycle

Use eval log for eval mode and PA log for PA mode once we add two-log lifecycle support.

For now, run this first and send the result.
