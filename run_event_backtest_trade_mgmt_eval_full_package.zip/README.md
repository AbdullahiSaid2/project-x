# Run Event Backtest Trade Management + Eval Strategy

Replace:

src/backtesting/event_engine/run_event_backtest.py

with the file in this package.

Also includes:

src/strategies/adapters/ict_fractal_v2_eval_event_adapter.py

Then rerun your ict_fractal_v2_eval command with breakeven and partial flags.
