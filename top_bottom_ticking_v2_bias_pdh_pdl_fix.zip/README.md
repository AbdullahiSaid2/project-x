# Top Bottom Ticking V2 Bias + PDH/PDL/PSH/PSL Fix

This replaces:

```text
src/strategies/manual/ict_top_bottom_ticking_v2.py
```

It adds:
- EMA trend/bias filter
- Previous Day High/Low sweeps
- Previous London session high/low sweeps
- Previous NY AM session high/low sweeps
- local sweep fallback

The adapter from the previous `target_r_fix` is still valid.

## Install

```bash
cd /Users/Abdullahi/trading-project/trading_system

unzip /path/to/top_bottom_ticking_v2_bias_pdh_pdl_fix.zip -d /tmp/tbt_v2_bias

cp -R /tmp/tbt_v2_bias/src/* src/
```

## Smoke test

Use lower min target for 2R testing:

```bash
PYTHONPATH=. python -m src.backtesting.event_engine.run_event_backtest \
  --strategy top_bottom_ticking_v2 \
  --symbols MNQ \
  --prop-profile apex_50k_pa \
  --days-back 60 \
  --timeframe 1m \
  --no-tail \
  --commission-per-contract-side 2.0 \
  --target-r 2.0 \
  --min-planned-target-dollars 250 \
  --news-events src/strategies/manual/researched_prop_trend/news_events.csv \
  --output-prefix top_bottom_ticking_v2_bias_smoke
```

Check diagnostics:

```bash
cat src/backtesting/event_engine/outputs/top_bottom_ticking_v2_zone_first_diagnostics.csv
```
