from __future__ import annotations

from dataclasses import dataclass
from datetime import time
from pathlib import Path
from typing import Optional

import pandas as pd


# =========================================================
# TOP BOTTOM TICKING V2 — BIAS + PDH/PDL/PSH/PSL SWEEP BUILD
# =========================================================
#
# Fixes added:
#
# 1. HTF / trend bias filter
#    - Uses EMA alignment to stop taking random countertrend reversals.
#    - LONG only allowed when trend/bias supports long.
#    - SHORT only allowed when trend/bias supports short.
#
# 2. PDH / PDL / PSH / PSL sweep logic
#    Previous V2 only used local rolling sweeps.
#    This version adds:
#      - Previous Day High / Low
#      - Previous London Session High / Low
#      - Previous NY AM Session High / Low
#
# 3. Liquidity quality filter
#    Valid sweeps can come from:
#      - PDH / PDL
#      - PSH / PSL
#      - local internal liquidity
#
#    But the setup is tagged so we can later analyse which sweep type works.
#
# 4. Keeps:
#    - zone-first RB/CE logic
#    - CE touch before MSS
#    - symbol-aware stop geometry
#    - target_r from CLI through adapter
#
# =========================================================


# =========================================================
# CONFIG
# =========================================================

DEFAULT_TARGET_R = 2.0

CE_TOLERANCE = 0.35
ZONE_EXPIRY_BARS = 80
CONFIRMATION_WINDOW_BARS = 15

LOCAL_SWEEP_LOOKBACK = 20
MSS_LOOKBACK = 6

MIN_RB_ATR_MULTIPLE = 0.65
MIN_RB_BODY_RATIO = 0.35

MIN_MSS_ATR_MULTIPLE = 0.75
MIN_MSS_BODY_RATIO = 0.45

MIN_VOLATILITY_RATIO = 0.45

MAX_SIGNALS_PER_DAY = 3
MIN_BARS_BETWEEN_SIGNALS = 20

# Trend / bias filter.
EMA_FAST = 50
EMA_SLOW = 200
ENABLE_EMA_BIAS_FILTER = True

# Allow local sweeps as fallback.
# If you want ONLY PDH/PDL/PSH/PSL sweeps later, set this to False.
ALLOW_LOCAL_SWEEP_FALLBACK = True

# ET session windows.
LONDON_KILLZONE = (time(2, 0), time(5, 30))
NY_AM = (time(8, 30), time(11, 30))
NY_PM = (time(13, 30), time(15, 30))

# Session definitions for PSH/PSL calculations in ET.
LONDON_SESSION = (time(2, 0), time(5, 30))
NY_AM_SESSION = (time(8, 30), time(11, 30))

SYMBOL_STOP_RULES = {
    "MNQ": {"min_stop": 6.0, "max_stop": 30.0, "buffer": 0.25},
    "MES": {"min_stop": 3.0, "max_stop": 15.0, "buffer": 0.25},
    "MYM": {"min_stop": 20.0, "max_stop": 120.0, "buffer": 1.0},
    "MGC": {"min_stop": 0.8, "max_stop": 6.0, "buffer": 0.1},
    "MCL": {"min_stop": 0.05, "max_stop": 0.6, "buffer": 0.01},
}

DEFAULT_STOP_RULES = {"min_stop": 3.0, "max_stop": 30.0, "buffer": 0.25}

DIAG_DIR = Path("src/backtesting/event_engine/outputs")
DIAG_DIR.mkdir(parents=True, exist_ok=True)
DIAG_PATH = DIAG_DIR / "top_bottom_ticking_v2_zone_first_diagnostics.csv"


# =========================================================
# DATA STRUCTURES
# =========================================================

@dataclass
class RejectionZone:
    direction: str
    high: float
    low: float
    ce: float
    created_i: int
    created_ts: object
    liquidity_type: str
    touched_i: Optional[int] = None
    touched_ts: Optional[object] = None
    swept: bool = False
    sweep_i: Optional[int] = None
    sweep_ts: Optional[object] = None
    sweep_type: str = ""
    used: bool = False

    @property
    def width(self) -> float:
        return self.high - self.low

    def expired(self, i: int) -> bool:
        return (i - self.created_i) > ZONE_EXPIRY_BARS


# =========================================================
# COLUMN / TIME HELPERS
# =========================================================

def _normalise_columns(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()

    rename_map = {
        "Open": "open",
        "High": "high",
        "Low": "low",
        "Close": "close",
        "Volume": "volume",
    }

    for old, new in rename_map.items():
        if old in out.columns and new not in out.columns:
            out[new] = out[old]

    required = ["open", "high", "low", "close"]
    missing = [c for c in required if c not in out.columns]

    if missing:
        raise ValueError(
            f"top_bottom_ticking_v2 missing required OHLC columns: {missing}. "
            f"Available columns: {list(out.columns)}"
        )

    return out


def _to_et_timestamp(ts):
    ts = pd.Timestamp(ts)
    if ts.tzinfo is None:
        ts = ts.tz_localize("UTC")
    return ts.tz_convert("America/New_York")


def _add_et_columns(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    et_index = pd.Series([_to_et_timestamp(x) for x in out.index], index=out.index)
    out["_et_ts"] = et_index
    out["_et_date"] = et_index.dt.date
    out["_et_time"] = et_index.dt.time
    return out


def allowed_session(ts) -> bool:
    ts_et = _to_et_timestamp(ts)
    t = ts_et.time()

    return (
        LONDON_KILLZONE[0] <= t <= LONDON_KILLZONE[1]
        or NY_AM[0] <= t <= NY_AM[1]
        or NY_PM[0] <= t <= NY_PM[1]
    )


def _time_in_window(t, window) -> bool:
    return window[0] <= t <= window[1]


def stop_rules_for_symbol(symbol: Optional[str]) -> dict:
    if not symbol:
        return DEFAULT_STOP_RULES
    return SYMBOL_STOP_RULES.get(str(symbol).upper(), DEFAULT_STOP_RULES)


# =========================================================
# INDICATORS
# =========================================================

def _atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
    high = df["high"]
    low = df["low"]
    close = df["close"]
    prev_close = close.shift(1)

    tr = pd.concat(
        [
            high - low,
            (high - prev_close).abs(),
            (low - prev_close).abs(),
        ],
        axis=1,
    ).max(axis=1)

    return tr.rolling(period, min_periods=period).mean()


def add_bias_columns(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["ema_fast"] = out["close"].ewm(span=EMA_FAST, adjust=False).mean()
    out["ema_slow"] = out["close"].ewm(span=EMA_SLOW, adjust=False).mean()

    out["bias_long"] = (
        (out["close"] > out["ema_fast"])
        & (out["ema_fast"] > out["ema_slow"])
    )

    out["bias_short"] = (
        (out["close"] < out["ema_fast"])
        & (out["ema_fast"] < out["ema_slow"])
    )

    return out


def bias_allows(direction: str, candle) -> bool:
    if not ENABLE_EMA_BIAS_FILTER:
        return True

    if direction == "long":
        return bool(candle.bias_long)

    return bool(candle.bias_short)


def add_liquidity_levels(df: pd.DataFrame) -> pd.DataFrame:
    """
    Adds:
      - previous day high / low
      - previous London session high / low
      - previous NY AM session high / low

    All based on ET dates/sessions.
    """
    out = _add_et_columns(df)

    # Previous day high / low.
    daily = out.groupby("_et_date").agg(
        day_high=("high", "max"),
        day_low=("low", "min"),
    )

    daily["pdh"] = daily["day_high"].shift(1)
    daily["pdl"] = daily["day_low"].shift(1)

    out = out.join(daily[["pdh", "pdl"]], on="_et_date")

    # Session labels.
    out["_session_name"] = ""
    out.loc[out["_et_time"].apply(lambda t: _time_in_window(t, LONDON_SESSION)), "_session_name"] = "london"
    out.loc[out["_et_time"].apply(lambda t: _time_in_window(t, NY_AM_SESSION)), "_session_name"] = "ny_am"

    session_rows = out[out["_session_name"].isin(["london", "ny_am"])].copy()

    if not session_rows.empty:
        session_levels = (
            session_rows
            .groupby(["_session_name", "_et_date"])
            .agg(
                session_high=("high", "max"),
                session_low=("low", "min"),
            )
            .reset_index()
            .sort_values(["_session_name", "_et_date"])
        )

        session_levels["psh"] = session_levels.groupby("_session_name")["session_high"].shift(1)
        session_levels["psl"] = session_levels.groupby("_session_name")["session_low"].shift(1)

        # Split and join back as previous London and previous NY levels.
        london = session_levels[session_levels["_session_name"] == "london"][
            ["_et_date", "psh", "psl"]
        ].rename(columns={"psh": "prev_london_high", "psl": "prev_london_low"})

        ny = session_levels[session_levels["_session_name"] == "ny_am"][
            ["_et_date", "psh", "psl"]
        ].rename(columns={"psh": "prev_ny_am_high", "psl": "prev_ny_am_low"})

        out = out.join(london.set_index("_et_date"), on="_et_date")
        out = out.join(ny.set_index("_et_date"), on="_et_date")
    else:
        out["prev_london_high"] = pd.NA
        out["prev_london_low"] = pd.NA
        out["prev_ny_am_high"] = pd.NA
        out["prev_ny_am_low"] = pd.NA

    return out


# =========================================================
# BASIC CANDLE HELPERS
# =========================================================

def candle_range(candle) -> float:
    return float(candle.high) - float(candle.low)


def candle_body(candle) -> float:
    return abs(float(candle.close) - float(candle.open))


def candle_body_ratio(candle) -> float:
    rng = candle_range(candle)
    if rng <= 0:
        return 0.0
    return candle_body(candle) / rng


def is_bullish(candle) -> bool:
    return float(candle.close) > float(candle.open)


def is_bearish(candle) -> bool:
    return float(candle.close) < float(candle.open)


def volatility_ok(current_atr, rolling_atr) -> bool:
    if pd.isna(current_atr) or pd.isna(rolling_atr):
        return False
    return float(current_atr) >= float(rolling_atr) * MIN_VOLATILITY_RATIO


# =========================================================
# LIQUIDITY SWEEP HELPERS
# =========================================================

def _sweep_level(value, level, direction: str) -> bool:
    if pd.isna(level):
        return False

    if direction == "low":
        return float(value) < float(level)

    return float(value) > float(level)


def external_sweep_type(candle, direction: str) -> str:
    """
    Returns the highest-quality external liquidity sweep type.

    For long setup:
      wants sweep below PDL or PSL.

    For short setup:
      wants sweep above PDH or PSH.
    """
    if direction == "long":
        if _sweep_level(candle.low, candle.pdl, "low"):
            return "PDL"
        if _sweep_level(candle.low, candle.prev_london_low, "low"):
            return "PSL_LONDON"
        if _sweep_level(candle.low, candle.prev_ny_am_low, "low"):
            return "PSL_NY_AM"
        return ""

    if _sweep_level(candle.high, candle.pdh, "high"):
        return "PDH"
    if _sweep_level(candle.high, candle.prev_london_high, "high"):
        return "PSH_LONDON"
    if _sweep_level(candle.high, candle.prev_ny_am_high, "high"):
        return "PSH_NY_AM"
    return ""


def local_sweep_type(df: pd.DataFrame, i: int, direction: str) -> str:
    if i - LOCAL_SWEEP_LOOKBACK < 0:
        return ""

    candle = df.iloc[i]

    if direction == "long":
        prior_low = float(df.iloc[i - LOCAL_SWEEP_LOOKBACK:i]["low"].min())
        if float(candle.low) < prior_low:
            return "LOCAL_LOW"

    else:
        prior_high = float(df.iloc[i - LOCAL_SWEEP_LOOKBACK:i]["high"].max())
        if float(candle.high) > prior_high:
            return "LOCAL_HIGH"

    return ""


def best_sweep_type(df: pd.DataFrame, i: int, direction: str) -> str:
    candle = df.iloc[i]

    ext = external_sweep_type(candle, direction)
    if ext:
        return ext

    if ALLOW_LOCAL_SWEEP_FALLBACK:
        return local_sweep_type(df, i, direction)

    return ""


# =========================================================
# REJECTION BLOCK / CE LOGIC
# =========================================================

def calculate_ce(high: float, low: float) -> float:
    return (float(high) + float(low)) / 2.0


def valid_rejection_candle(candle, atr: float) -> bool:
    if pd.isna(atr) or atr <= 0:
        return False

    return (
        candle_range(candle) >= float(atr) * MIN_RB_ATR_MULTIPLE
        and candle_body_ratio(candle) >= MIN_RB_BODY_RATIO
    )


def detect_new_rejection_zone(df: pd.DataFrame, i: int, atr: float) -> Optional[RejectionZone]:
    candle = df.iloc[i]
    ts = candle.name

    if not valid_rejection_candle(candle, atr):
        return None

    # Bullish RB: raid lows and reject upward, only if bias allows long.
    long_sweep = best_sweep_type(df, i, "long")
    if long_sweep and is_bullish(candle) and bias_allows("long", candle):
        return RejectionZone(
            direction="long",
            high=float(candle.high),
            low=float(candle.low),
            ce=calculate_ce(candle.high, candle.low),
            created_i=i,
            created_ts=ts,
            liquidity_type=long_sweep,
        )

    # Bearish RB: raid highs and reject downward, only if bias allows short.
    short_sweep = best_sweep_type(df, i, "short")
    if short_sweep and is_bearish(candle) and bias_allows("short", candle):
        return RejectionZone(
            direction="short",
            high=float(candle.high),
            low=float(candle.low),
            ce=calculate_ce(candle.high, candle.low),
            created_i=i,
            created_ts=ts,
            liquidity_type=short_sweep,
        )

    return None


def price_touches_zone(candle, zone: RejectionZone) -> bool:
    return float(candle.low) <= zone.high and float(candle.high) >= zone.low


def price_touches_ce(candle, zone: RejectionZone) -> bool:
    if zone.width <= 0:
        return False

    tolerance = zone.width * CE_TOLERANCE

    return (
        float(candle.low) <= zone.ce + tolerance
        and float(candle.high) >= zone.ce - tolerance
    )


def mark_zone_touch(zone: RejectionZone, candle, i: int):
    if zone.touched_i is None:
        zone.touched_i = i
        zone.touched_ts = candle.name


# =========================================================
# SWEEP + MSS AFTER CE TOUCH
# =========================================================

def sweep_after_touch(df: pd.DataFrame, i: int, zone: RejectionZone) -> str:
    return best_sweep_type(df, i, zone.direction)


def valid_mss_displacement(candle, atr: float) -> bool:
    if pd.isna(atr) or atr <= 0:
        return False

    return (
        candle_range(candle) >= float(atr) * MIN_MSS_ATR_MULTIPLE
        and candle_body_ratio(candle) >= MIN_MSS_BODY_RATIO
    )


def mss_after_touch(df: pd.DataFrame, i: int, zone: RejectionZone, atr: float) -> bool:
    if zone.touched_i is None:
        return False

    if i <= zone.touched_i:
        return False

    if (i - zone.touched_i) > CONFIRMATION_WINDOW_BARS:
        return False

    if i - MSS_LOOKBACK < 0:
        return False

    candle = df.iloc[i]

    if not valid_mss_displacement(candle, atr):
        return False

    if not bias_allows(zone.direction, candle):
        return False

    if zone.direction == "long":
        prior_high = float(df.iloc[i - MSS_LOOKBACK:i]["high"].max())
        return float(candle.close) > prior_high and is_bullish(candle)

    prior_low = float(df.iloc[i - MSS_LOOKBACK:i]["low"].min())
    return float(candle.close) < prior_low and is_bearish(candle)


# =========================================================
# OPTIONAL FVG TAGGING
# =========================================================

def bullish_fvg(c1, c2, c3) -> bool:
    return float(c1.high) < float(c3.low)


def bearish_fvg(c1, c2, c3) -> bool:
    return float(c1.low) > float(c3.high)


def recent_fvg_tag(df: pd.DataFrame, i: int, direction: str, lookback: int = 5) -> bool:
    start = max(2, i - lookback + 1)

    for j in range(i, start - 1, -1):
        if direction == "long" and bullish_fvg(df.iloc[j - 2], df.iloc[j - 1], df.iloc[j]):
            return True
        if direction == "short" and bearish_fvg(df.iloc[j - 2], df.iloc[j - 1], df.iloc[j]):
            return True

    return False


# =========================================================
# ORDER PLAN WITH SYMBOL STOP GEOMETRY
# =========================================================

def adjust_long_stop(entry: float, raw_stop: float, rules: dict) -> Optional[float]:
    min_stop = float(rules["min_stop"])
    max_stop = float(rules["max_stop"])

    risk = entry - raw_stop

    if risk <= 0:
        return None

    if risk < min_stop:
        raw_stop = entry - min_stop
        risk = min_stop

    if risk > max_stop:
        return None

    return raw_stop


def adjust_short_stop(entry: float, raw_stop: float, rules: dict) -> Optional[float]:
    min_stop = float(rules["min_stop"])
    max_stop = float(rules["max_stop"])

    risk = raw_stop - entry

    if risk <= 0:
        return None

    if risk < min_stop:
        raw_stop = entry + min_stop
        risk = min_stop

    if risk > max_stop:
        return None

    return raw_stop


def build_trade_plan(
    candle,
    zone: RejectionZone,
    fvg_tag: bool,
    symbol: Optional[str],
    target_r: float,
) -> Optional[dict]:
    rules = stop_rules_for_symbol(symbol)
    buffer = float(rules["buffer"])
    entry = float(candle.close)

    if zone.direction == "long":
        raw_stop = float(zone.low) - buffer
        stop = adjust_long_stop(entry, raw_stop, rules)

        if stop is None:
            return None

        risk = entry - stop

        return {
            "timestamp": candle.name,
            "side": "LONG",
            "entry": entry,
            "stop": stop,
            "target": entry + (risk * target_r),
            "risk": risk,
            "target_r": target_r,
            "setup": (
                "top_bottom_ticking_v2_long_"
                + zone.liquidity_type
                + "_"
                + ("fvg_" if fvg_tag else "")
                + "ce_sweep_mss_bias"
            ),
            "liquidity_type": zone.liquidity_type,
            "zone_created_ts": zone.created_ts,
            "zone_high": zone.high,
            "zone_low": zone.low,
            "zone_ce": zone.ce,
        }

    raw_stop = float(zone.high) + buffer
    stop = adjust_short_stop(entry, raw_stop, rules)

    if stop is None:
        return None

    risk = stop - entry

    return {
        "timestamp": candle.name,
        "side": "SHORT",
        "entry": entry,
        "stop": stop,
        "target": entry - (risk * target_r),
        "risk": risk,
        "target_r": target_r,
        "setup": (
            "top_bottom_ticking_v2_short_"
            + zone.liquidity_type
            + "_"
            + ("fvg_" if fvg_tag else "")
            + "ce_sweep_mss_bias"
        ),
        "liquidity_type": zone.liquidity_type,
        "zone_created_ts": zone.created_ts,
        "zone_high": zone.high,
        "zone_low": zone.low,
        "zone_ce": zone.ce,
    }


# =========================================================
# DIAGNOSTICS
# =========================================================

def _empty_diag() -> dict:
    return {
        "bars_seen": 0,
        "blocked_session": 0,
        "blocked_atr": 0,
        "blocked_volatility": 0,
        "zones_created_long": 0,
        "zones_created_short": 0,
        "zones_expired": 0,
        "zone_touches": 0,
        "ce_touches": 0,
        "sweeps_after_touch": 0,
        "mss_after_touch": 0,
        "fvg_tags": 0,
        "rejected_stop_geometry": 0,
        "long_signals": 0,
        "short_signals": 0,
        "target_r_used": 0,
        "pdh_sweeps": 0,
        "pdl_sweeps": 0,
        "psh_sweeps": 0,
        "psl_sweeps": 0,
        "local_sweeps": 0,
    }


def _track_liquidity_diag(diag: dict, sweep_type: str):
    if sweep_type == "PDH":
        diag["pdh_sweeps"] += 1
    elif sweep_type == "PDL":
        diag["pdl_sweeps"] += 1
    elif sweep_type.startswith("PSH"):
        diag["psh_sweeps"] += 1
    elif sweep_type.startswith("PSL"):
        diag["psl_sweeps"] += 1
    elif sweep_type.startswith("LOCAL"):
        diag["local_sweeps"] += 1


def _write_diag(diag: dict):
    pd.DataFrame([diag]).to_csv(DIAG_PATH, index=False)


# =========================================================
# MAIN SIGNAL GENERATOR
# =========================================================

def generate_top_bottom_ticking_v2_signals(
    df: pd.DataFrame,
    symbol: Optional[str] = None,
    target_r: Optional[float] = None,
) -> pd.DataFrame:
    """
    Zone-first signal generator with:
      - EMA trend/bias filter
      - PDH/PDL/PSH/PSL sweep levels
      - local sweep fallback
      - symbol-aware stop geometry
      - target_r from CLI via adapter
    """
    if target_r is None:
        target_r = DEFAULT_TARGET_R

    target_r = float(target_r)

    df = _normalise_columns(df)
    df = _add_et_columns(df)
    df = add_liquidity_levels(df)
    df = add_bias_columns(df)

    if "atr" not in df.columns:
        df["atr"] = _atr(df, 14)

    df["rolling_atr"] = df["atr"].rolling(50, min_periods=50).mean()

    active_zones: list[RejectionZone] = []
    trades: list[dict] = []
    diag = _empty_diag()
    diag["target_r_used"] = target_r

    current_day = None
    signals_today = 0
    last_signal_i = -999999

    for i in range(60, len(df) - 1):
        diag["bars_seen"] += 1

        candle = df.iloc[i]
        ts = candle.name
        ts_et = _to_et_timestamp(ts)

        if current_day != ts_et.date():
            current_day = ts_et.date()
            signals_today = 0

        if not allowed_session(ts):
            diag["blocked_session"] += 1
            continue

        atr = candle.atr
        rolling_atr = candle.rolling_atr

        if pd.isna(atr) or pd.isna(rolling_atr):
            diag["blocked_atr"] += 1
            continue

        if not volatility_ok(atr, rolling_atr):
            diag["blocked_volatility"] += 1
            continue

        still_active = []
        for z in active_zones:
            if z.used:
                continue
            if z.expired(i):
                diag["zones_expired"] += 1
                continue
            still_active.append(z)
        active_zones = still_active

        new_zone = detect_new_rejection_zone(df, i, atr)
        if new_zone is not None:
            active_zones.append(new_zone)
            _track_liquidity_diag(diag, new_zone.liquidity_type)

            if new_zone.direction == "long":
                diag["zones_created_long"] += 1
            else:
                diag["zones_created_short"] += 1

        if signals_today >= MAX_SIGNALS_PER_DAY:
            continue

        if (i - last_signal_i) < MIN_BARS_BETWEEN_SIGNALS:
            continue

        for zone in active_zones:
            if zone.used:
                continue

            if not price_touches_zone(candle, zone):
                continue

            diag["zone_touches"] += 1

            if not price_touches_ce(candle, zone):
                continue

            diag["ce_touches"] += 1
            mark_zone_touch(zone, candle, i)

            sweep_type = sweep_after_touch(df, i, zone)
            if sweep_type:
                zone.swept = True
                zone.sweep_i = i
                zone.sweep_ts = ts
                zone.sweep_type = sweep_type
                diag["sweeps_after_touch"] += 1

            if not zone.swept:
                continue

            if not mss_after_touch(df, i, zone, atr):
                continue

            diag["mss_after_touch"] += 1

            fvg_tag = recent_fvg_tag(df, i, zone.direction, lookback=5)
            if fvg_tag:
                diag["fvg_tags"] += 1

            plan = build_trade_plan(
                candle=candle,
                zone=zone,
                fvg_tag=fvg_tag,
                symbol=symbol,
                target_r=target_r,
            )

            if plan is None:
                diag["rejected_stop_geometry"] += 1
                zone.used = True
                continue

            trades.append(plan)
            zone.used = True
            signals_today += 1
            last_signal_i = i

            if zone.direction == "long":
                diag["long_signals"] += 1
            else:
                diag["short_signals"] += 1

            break

    _write_diag(diag)

    return pd.DataFrame(trades)
