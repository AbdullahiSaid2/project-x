# Prop Dual Mode Lifecycle Simulator V3 — PA Payout Rules

This version keeps eval aggressive/fast and applies these rules only to PA payouts:

```text
PA min active trading days before payout: 5
PA consistency rule: best single day <= 50% of payout-cycle profit
PA minimum payout: $250
PA maximum payout cap/target: $2,000
```

## Install

```bash
cd /Users/Abdullahi/trading-project/trading_system
unzip /path/to/prop_dual_mode_lifecycle_v3_pa_payout_rules.zip -d /tmp/lifecycle_v3
cp -R /tmp/lifecycle_v3/src/* src/
```

## Run

```bash
PYTHONPATH=. python -m src.strategies.manual.researched_prop_trend.prop_dual_mode_lifecycle_simulator \
  --trade-log src/backtesting/event_engine/outputs/ict_fractal_v2_quality_be_partial_no_mym_long_event_trade_log.csv \
  --profile apex_50k_dual_mode \
  --eval-risk-multiplier 2.0 \
  --pa-risk-multiplier 1.0 \
  --target-payout-frequency-days 10 \
  --min-weekly-payout-amount 1000 \
  --pa-min-payout-trading-days 5 \
  --pa-consistency-rule-pct 50 \
  --pa-min-payout-amount 250 \
  --pa-max-payout-amount 2000 \
  --aggressive-eval-until-pass
```

New payout CSV columns include:
- payout_cycle_active_days
- payout_cycle_trades
- payout_cycle_profit
- best_payout_cycle_day
- consistency_limit
- consistency_ok
- min_days_ok
- min_payout_ok
