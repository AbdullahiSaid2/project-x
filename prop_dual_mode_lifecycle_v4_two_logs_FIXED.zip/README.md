# Prop Dual Mode Lifecycle Simulator V4 Fixed

Fixes two-log mode hanging by advancing the correct index in PA skip/lock branches.

## Install

```bash
cd /Users/Abdullahi/trading-project/trading_system
unzip /path/to/prop_dual_mode_lifecycle_v4_two_logs_FIXED.zip -d /tmp/lifecycle_v4_fixed
cp -R /tmp/lifecycle_v4_fixed/src/* src/
```

## Run

```bash
PYTHONPATH=. python -m src.strategies.manual.researched_prop_trend.prop_dual_mode_lifecycle_simulator \
  --eval-trade-log src/backtesting/event_engine/outputs/ict_fractal_v2_eval_365_event_trade_log.csv \
  --pa-trade-log src/backtesting/event_engine/outputs/ict_fractal_v2_quality_be_partial_no_mym_long_event_trade_log.csv \
  --profile apex_50k_dual_mode \
  --eval-risk-multiplier 2.0 \
  --pa-risk-multiplier 1.0 \
  --target-payout-frequency-days 10 \
  --min-weekly-payout-amount 1000 \
  --pa-min-payout-trading-days 5 \
  --pa-consistency-rule-pct 50 \
  --pa-min-payout-amount 250 \
  --pa-max-payout-amount 2000 \
  --aggressive-eval-until-pass
```
