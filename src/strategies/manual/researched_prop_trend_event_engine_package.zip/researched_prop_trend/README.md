# Researched Prop Trend v9 Event Engine

This package adds the production-style validation layer we discussed.

Files:

```text
prop_event_engine_backtest.py        # true multi-symbol event-driven simulator
diagnostics_report.py                # diagnostics for any generated trade log
prop_profiles.yaml                   # 50K prop rules
symbol_specs.yaml                    # micro futures specs
```

The new engine fixes the main research limitations:

```text
Backtesting.py candle-fill assumptions: conservative stop-first collision handling
Post-processed portfolio guard: replaced with one live account event loop
Possible double daily-stop logic: removed; one account daily stop only
Same-bar exits: flagged and reported
Losses larger than planned risk: planned vs actual risk breach report
Not true event-driven simulator: replaced with multi-symbol timestamp loop
```

Recommended command:

```bash
PYTHONPATH=. python -m src.strategies.manual.researched_prop_trend.prop_event_engine_backtest \
  --symbols MNQ MES MYM MGC \
  --prop-profile apex_50k_eod_eval \
  --days-back 1825 \
  --timeframe 1m \
  --no-tail \
  --commission-per-contract-side 2.0 \
  --min-trend-score 3 \
  --target-r 10.0 \
  --min-planned-target-dollars 500
```

Diagnostics:

```bash
PYTHONPATH=. python -m src.strategies.manual.researched_prop_trend.diagnostics_report \
  --trade-log src/strategies/manual/researched_prop_trend/event_trade_log.csv
```
