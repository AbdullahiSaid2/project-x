# Researched Prop Trend v9 Event Engine

This package adds the production-style validation layer we discussed.

Files:

```text
prop_event_engine_backtest.py        # true multi-symbol event-driven simulator
diagnostics_report.py                # diagnostics for any generated trade log
prop_profiles.yaml                   # 50K prop rules
symbol_specs.yaml                    # micro futures specs
```

The new engine fixes the main research limitations:

```text
Backtesting.py candle-fill assumptions: conservative stop-first collision handling
Post-processed portfolio guard: replaced with one live account event loop
Possible double daily-stop logic: removed; one account daily stop only
Same-bar exits: flagged and reported
Losses larger than planned risk: planned vs actual risk breach report
Not true event-driven simulator: replaced with multi-symbol timestamp loop
```

Recommended command:

```bash
PYTHONPATH=. python -m src.strategies.manual.researched_prop_trend.prop_event_engine_backtest \
  --symbols MNQ MES MYM MGC \
  --prop-profile apex_50k_eod_eval \
  --days-back 1825 \
  --timeframe 1m \
  --no-tail \
  --commission-per-contract-side 2.0 \
  --min-trend-score 3 \
  --target-r 10.0 \
  --min-planned-target-dollars 500
```

Diagnostics:

```bash
PYTHONPATH=. python -m src.strategies.manual.researched_prop_trend.diagnostics_report \
  --trade-log src/strategies/manual/researched_prop_trend/event_trade_log.csv
```


---

## v10 update: Apex 50K evaluation simulator

`apex_eval_simulator.py` reads the event-engine trade log and simulates prop-firm evaluation pass/fail rules.

It answers:

```text
Did the account pass the $3,000 profit target?
Did it fail the $2,000 drawdown first?
How many days to pass/fail?
Worst drawdown before pass/fail
Sequential attempt pass rate
```

### Single evaluation attempt

```bash
PYTHONPATH=. python -m src.strategies.manual.researched_prop_trend.apex_eval_simulator \
  --trade-log src/strategies/manual/researched_prop_trend/event_trade_log.csv \
  --prop-profile apex_50k_eod_eval \
  --mode single
```

### Sequential 30-day attempts

This splits the 5-year trade log into repeated eval attempts. Each attempt starts where the prior attempt ended.

```bash
PYTHONPATH=. python -m src.strategies.manual.researched_prop_trend.apex_eval_simulator \
  --trade-log src/strategies/manual/researched_prop_trend/event_trade_log.csv \
  --prop-profile apex_50k_eod_eval \
  --mode sequential \
  --max-calendar-days 30
```

### Outputs

```text
apex_eval_single_result.csv
apex_eval_attempts.csv
apex_eval_daily_curve.csv
apex_eval_summary.txt
```
