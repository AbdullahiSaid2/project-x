from __future__ import annotations

from pathlib import Path
import importlib.util
import json
import traceback
from types import ModuleType
from typing import Any, Iterable, Optional

import pandas as pd

from v470_policy import POLICY

ROOT = Path.cwd()
MANUAL_DIR = ROOT / "src" / "strategies" / "manual"

OUT_TRADE_CSV = ROOT / "v470_trade_log.csv"
OUT_METADATA_CSV = ROOT / "v470_trade_metadata_log.csv"
OUT_MONTHLY_CSV = ROOT / "v470_monthly_pnl_summary.csv"
OUT_APEX_MONTHLY_CSV = ROOT / "v470_apex_50k_monthly_summary.csv"
OUT_APEX_DAILY_CSV = ROOT / "v470_apex_50k_daily_summary.csv"
OUT_CALENDAR_DAILY_CSV = ROOT / "v470_daily_pnl_calendar_et.csv"
OUT_APEX_SESSION_DAILY_CSV = ROOT / "v470_daily_pnl_apex_session.csv"
OUT_POLICY_JSON = ROOT / "v470_policy_snapshot.json"

def print_policy_banner() -> None:
    print("✅ V470 policy: A-tier only | London+NYPM only | fixed 10 MNQ | min RR 5 | min target $500 | Apex 50k")

def write_policy_snapshot() -> None:
    OUT_POLICY_JSON.write_text(json.dumps(POLICY.to_dict(), indent=2))

def candidate_paths() -> list[Path]:
    return [
        MANUAL_DIR / "tmp_test_ict_multi_setup_v469.py",
        MANUAL_DIR / "tmp_test_ict_multi_setup_v468.py",
        MANUAL_DIR / "tmp_test_ict_multi_setup_v467.py",
        MANUAL_DIR / "tmp_test_ict_multi_setup_v466.py",
        MANUAL_DIR / "tmp_test_ict_multi_setup_v465.py",
        MANUAL_DIR / "tmp_test_ict_multi_setup_v464.py",
    ]

def _load_module_from_path(path: Path) -> ModuleType:
    mod_name = f"_v470_source_{path.stem}"
    spec = importlib.util.spec_from_file_location(mod_name, str(path))
    if spec is None or spec.loader is None:
        raise ImportError(f"Could not create import spec for {path}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

def _patch_module_globals(mod: Any) -> None:
    patch_values = {
        "ACCOUNT_SIZE": POLICY.account_size,
        "APEX_ACCOUNT_SIZE": POLICY.account_size,
        "FIXED_CONTRACTS": POLICY.fixed_contracts,
        "REPORT_CONTRACTS": POLICY.fixed_contracts,
        "MIN_RR": POLICY.min_planned_rr,
        "MIN_PLANNED_RR": POLICY.min_planned_rr,
        "MIN_TARGET_DOLLARS": POLICY.min_profit_target_dollars,
        "PROP_DAILY_LOSS_LIMIT": POLICY.prop_daily_loss_limit,
        "PROP_MAX_DRAWDOWN_LIMIT": POLICY.prop_max_drawdown_limit,
        "ALLOWED_SETUP_TIERS": POLICY.allowed_setup_tiers,
        "ALLOWED_SETUP_TYPES": POLICY.allowed_setup_types,
        "ALLOWED_ENTRY_VARIANTS": POLICY.allowed_entry_variants,
    }
    for k, v in patch_values.items():
        if hasattr(mod, k):
            try:
                setattr(mod, k, v)
            except Exception:
                pass

def _extract_frames_from_result(result: Any, mod: Any) -> tuple[Optional[pd.DataFrame], Optional[pd.DataFrame]]:
    if isinstance(result, tuple) and len(result) >= 1:
        trades = result[0]
        meta = result[1] if len(result) > 1 else None
        if isinstance(trades, pd.DataFrame):
            return trades, meta if isinstance(meta, pd.DataFrame) else None
    if isinstance(result, pd.DataFrame):
        return result, None
    trades = getattr(mod, "trade_log_df", None)
    meta = getattr(mod, "trade_metadata_df", None)
    return trades if isinstance(trades, pd.DataFrame) else None, meta if isinstance(meta, pd.DataFrame) else None

def try_run_base_engine() -> tuple[pd.DataFrame, Optional[pd.DataFrame], str]:
    errors = []
    available = [p for p in candidate_paths() if p.exists()]
    if not available:
        raise RuntimeError("Could not find any compatible prior engine file. Checked:\n" + "\n".join(str(p) for p in candidate_paths()))

    for path in available:
        try:
            mod = _load_module_from_path(path)
            _patch_module_globals(mod)

            for fn_name in ("main", "run", "run_backtest"):
                fn = getattr(mod, fn_name, None)
                if callable(fn):
                    result = fn()
                    trades, meta = _extract_frames_from_result(result, mod)
                    if isinstance(trades, pd.DataFrame):
                        return trades, meta, str(path)

            trades, meta = _extract_frames_from_result(None, mod)
            if isinstance(trades, pd.DataFrame):
                return trades, meta, str(path)

            errors.append(f"{path}: loaded but no DataFrame trade log was returned or exposed")
        except Exception as e:
            errors.append(f"{path}: {e}\n{traceback.format_exc()}")

    raise RuntimeError("Could not run any compatible prior engine. Errors:\n\n" + "\n\n".join(errors))

def _normalise_trade_log(df: pd.DataFrame) -> pd.DataFrame:
    if df is None or df.empty:
        return pd.DataFrame()

    out = df.copy()

    if "report_contracts" not in out.columns:
        if "Size" in out.columns:
            out["report_contracts"] = pd.to_numeric(out["Size"], errors="coerce").abs().fillna(POLICY.fixed_contracts)
        else:
            out["report_contracts"] = POLICY.fixed_contracts

    if "setup_tier" in out.columns:
        out = out[out["setup_tier"].astype(str).isin(POLICY.allowed_setup_tiers)]

    if "setup_type" in out.columns:
        out = out[out["setup_type"].astype(str).isin(POLICY.allowed_setup_types)]

    if "entry_variant" in out.columns:
        out = out[out["entry_variant"].astype(str).isin(POLICY.allowed_entry_variants)]

    if "planned_rr" in out.columns:
        out = out[pd.to_numeric(out["planned_rr"], errors="coerce") >= POLICY.min_planned_rr]

    if "tp_points" in out.columns:
        out = out[pd.to_numeric(out["tp_points"], errors="coerce") >= POLICY.min_profit_target_points_per_contract]

    out["report_contracts"] = POLICY.fixed_contracts

    if "realized_dollars_dynamic_contracts" not in out.columns:
        if "realized_points" in out.columns:
            out["realized_dollars_dynamic_contracts"] = (
                pd.to_numeric(out["realized_points"], errors="coerce").fillna(0.0)
                * POLICY.fixed_contracts
                * POLICY.dollar_per_point_per_contract
            )
        elif "PnL" in out.columns:
            out["realized_dollars_dynamic_contracts"] = pd.to_numeric(out["PnL"], errors="coerce").fillna(0.0)
        else:
            out["realized_dollars_dynamic_contracts"] = 0.0

    return out.reset_index(drop=True)

def save_trade_outputs(trades: pd.DataFrame, meta: Optional[pd.DataFrame] = None) -> pd.DataFrame:
    norm = _normalise_trade_log(trades)
    norm.to_csv(OUT_TRADE_CSV, index=False)
    if isinstance(meta, pd.DataFrame) and not meta.empty:
        meta_norm = _normalise_trade_log(meta)
        meta_norm.to_csv(OUT_METADATA_CSV, index=False)
    write_policy_snapshot()
    return norm

def load_v470_trades() -> pd.DataFrame:
    if not OUT_TRADE_CSV.exists():
        raise FileNotFoundError(f"Missing {OUT_TRADE_CSV}")
    return pd.read_csv(OUT_TRADE_CSV)

def _pick_col(df: pd.DataFrame, names: Iterable[str]) -> Optional[str]:
    for n in names:
        if n in df.columns:
            return n
    return None

def build_monthly_summary(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return pd.DataFrame()

    month_col = _pick_col(df, ["exit_month_et", "entry_month_et"])
    if month_col is None:
        raise KeyError("No monthly column found in trade log.")

    pnl_col = _pick_col(df, ["realized_dollars_dynamic_contracts", "PnL", "pnl"])
    if pnl_col is None:
        raise KeyError("No PnL column found in trade log.")

    points_col = _pick_col(df, ["realized_points"])

    work = df.copy()
    work[pnl_col] = pd.to_numeric(work[pnl_col], errors="coerce").fillna(0.0)
    if points_col:
        work[points_col] = pd.to_numeric(work[points_col], errors="coerce").fillna(0.0)
    else:
        work["realized_points"] = work[pnl_col] / (POLICY.fixed_contracts * POLICY.dollar_per_point_per_contract)
        points_col = "realized_points"

    grp = work.groupby(month_col, dropna=False)
    out = grp.agg(
        trades=(month_col, "size"),
        gross_pnl_dollars_dynamic=(pnl_col, "sum"),
        gross_points=(points_col, "sum"),
    ).reset_index().rename(columns={month_col: "exit_month_et"})

    out["gross_pnl_dollars_5_mnq"] = out["gross_points"] * 10.0
    out["gross_pnl_dollars_10_mnq"] = out["gross_points"] * 20.0
    out["avg_trade_dollars_dynamic"] = out["gross_pnl_dollars_dynamic"] / out["trades"]
    out["avg_points_per_trade"] = out["gross_points"] / out["trades"]

    if "return_pct" in work.columns:
        win = grp["return_pct"].apply(lambda s: (pd.to_numeric(s, errors="coerce").fillna(0.0) > 0).mean() * 100.0)
    else:
        win = grp[pnl_col].apply(lambda s: (pd.to_numeric(s, errors="coerce").fillna(0.0) > 0).mean() * 100.0)
    out["win_rate_pct"] = out["exit_month_et"].map(win.to_dict())
    out["cumulative_pnl_dollars_dynamic"] = out["gross_pnl_dollars_dynamic"].cumsum()
    return out

def build_daily_summary(df: pd.DataFrame, date_col_name: str) -> pd.DataFrame:
    pnl_col = _pick_col(df, ["realized_dollars_dynamic_contracts", "PnL", "pnl"])
    if pnl_col is None:
        raise KeyError("No PnL column found in trade log.")
    points_col = _pick_col(df, ["realized_points"])

    work = df.copy()
    work[pnl_col] = pd.to_numeric(work[pnl_col], errors="coerce").fillna(0.0)
    if points_col:
        work[points_col] = pd.to_numeric(work[points_col], errors="coerce").fillna(0.0)
    else:
        work["realized_points"] = work[pnl_col] / (POLICY.fixed_contracts * POLICY.dollar_per_point_per_contract)
        points_col = "realized_points"

    grp = work.groupby(date_col_name, dropna=False)
    out = grp.agg(
        trades=(date_col_name, "size"),
        gross_pnl_dollars=(pnl_col, "sum"),
        gross_points=(points_col, "sum"),
    ).reset_index()
    out["avg_trade_dollars"] = out["gross_pnl_dollars"] / out["trades"]
    if "return_pct" in work.columns:
        win = grp["return_pct"].apply(lambda s: (pd.to_numeric(s, errors='coerce').fillna(0.0) > 0).mean() * 100.0)
    else:
        win = grp[pnl_col].apply(lambda s: (pd.to_numeric(s, errors='coerce').fillna(0.0) > 0).mean() * 100.0)
    out["win_rate_pct"] = out[out.columns[0]].map(win.to_dict())
    out["cumulative_pnl_dollars"] = out["gross_pnl_dollars"].cumsum()
    return out

def build_apex_monthly_summary(df: pd.DataFrame):
    monthly = build_monthly_summary(df).copy()
    daily_date_col = _pick_col(df, ["exit_apex_session_date", "entry_apex_session_date", "calendar_exit_date_et"])
    if daily_date_col is None:
        raise KeyError("No apex/session daily date column found in trade log.")
    daily = build_daily_summary(df, daily_date_col).copy()

    month_source_col = _pick_col(df, ["exit_month_et", "entry_month_et"])
    if month_source_col is None:
        raise KeyError("No monthly source column found in trade log.")

    month_map = df[[daily_date_col, month_source_col]].drop_duplicates().set_index(daily_date_col)[month_source_col].to_dict()
    daily["exit_month_et"] = daily[daily_date_col].map(month_map)

    by_month = daily.groupby("exit_month_et")["gross_pnl_dollars"]
    extra = pd.DataFrame({
        "exit_month_et": list(by_month.groups.keys()),
        "trading_days": by_month.size().values,
        "green_days": by_month.apply(lambda s: (s > 0).sum()).values,
        "red_days": by_month.apply(lambda s: (s < 0).sum()).values,
        "worst_day_dollars": by_month.min().values,
        "best_day_dollars": by_month.max().values,
        "avg_day_dollars": by_month.mean().values,
        "soft_loss_cap_breach_days": by_month.apply(lambda s: (s <= POLICY.prop_daily_loss_limit).sum()).values,
    })

    out = monthly.merge(extra, on="exit_month_et", how="left")
    out = out.rename(columns={
        "gross_pnl_dollars_dynamic": "gross_pnl_dollars",
        "avg_trade_dollars_dynamic": "avg_trade_dollars",
        "cumulative_pnl_dollars_dynamic": "cumulative_pnl_dollars",
    })
    out["account_balance_est"] = POLICY.account_size + out["cumulative_pnl_dollars"]
    out["month_green"] = out["gross_pnl_dollars"] > 0
    out["strong_month_flag"] = out["gross_pnl_dollars"] >= 3000
    out["equity_peak_est"] = out["account_balance_est"].cummax()
    out["drawdown_from_peak_dollars"] = out["account_balance_est"] - out["equity_peak_est"]
    return out, daily
