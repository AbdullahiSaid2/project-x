from __future__ import annotations
import pandas as pd
from v470_shared import load_v470_trades, build_apex_monthly_summary, OUT_APEX_MONTHLY_CSV, OUT_APEX_DAILY_CSV

def main():
    df = load_v470_trades()
    monthly, daily = build_apex_monthly_summary(df)
    monthly.to_csv(OUT_APEX_MONTHLY_CSV, index=False)
    daily.to_csv(OUT_APEX_DAILY_CSV, index=False)
    with pd.ExcelWriter("v470_apex_50k_monthly_payout_export.xlsx", engine="openpyxl") as writer:
        monthly.to_excel(writer, index=False, sheet_name="monthly_summary")
        daily.to_excel(writer, index=False, sheet_name="daily_summary")
    print("4) Export complete")
    print("Excel: v470_apex_50k_monthly_payout_export.xlsx")
    print(f"Monthly CSV: {OUT_APEX_MONTHLY_CSV}")
    print(f"Daily CSV: {OUT_APEX_DAILY_CSV}")
    print("\n5) Apex 50k monthly payout-style summary")
    print(monthly.to_string(index=False))

if __name__ == "__main__":
    main()
