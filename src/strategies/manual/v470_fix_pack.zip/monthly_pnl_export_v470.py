from __future__ import annotations
import pandas as pd
from v470_shared import load_v470_trades, build_monthly_summary, OUT_MONTHLY_CSV

def main():
    df = load_v470_trades()
    monthly = build_monthly_summary(df)
    monthly.to_csv(OUT_MONTHLY_CSV, index=False)
    with pd.ExcelWriter("v470_monthly_pnl_export.xlsx", engine="openpyxl") as writer:
        monthly.to_excel(writer, index=False, sheet_name="monthly_summary")
    print("4) Export complete")
    print("Excel: v470_monthly_pnl_export.xlsx")
    print(f"Monthly CSV: {OUT_MONTHLY_CSV}")
    print("\n5) Monthly summary")
    print(monthly.to_string(index=False))

if __name__ == "__main__":
    main()
