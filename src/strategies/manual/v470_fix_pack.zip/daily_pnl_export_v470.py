from __future__ import annotations
from v470_shared import load_v470_trades, build_daily_summary, OUT_CALENDAR_DAILY_CSV, OUT_APEX_SESSION_DAILY_CSV

def main():
    df = load_v470_trades()
    if "calendar_exit_date_et" in df.columns:
        cal = build_daily_summary(df, "calendar_exit_date_et")
        cal.to_csv(OUT_CALENDAR_DAILY_CSV, index=False)
        print(f"Calendar daily CSV: {OUT_CALENDAR_DAILY_CSV}")
        print("\nCalendar ET daily PnL")
        print(cal.to_string(index=False))
    apex_col = "exit_apex_session_date" if "exit_apex_session_date" in df.columns else ("entry_apex_session_date" if "entry_apex_session_date" in df.columns else None)
    if apex_col:
        apex = build_daily_summary(df, apex_col)
        apex.to_csv(OUT_APEX_SESSION_DAILY_CSV, index=False)
        print(f"\nApex-session daily CSV: {OUT_APEX_SESSION_DAILY_CSV}")
        print("\nApex session daily PnL")
        print(apex.to_string(index=False))

if __name__ == "__main__":
    main()
