from __future__ import annotations
import pandas as pd
from v470_shared import load_v470_trades, build_monthly_summary

def _group_stats(df: pd.DataFrame, by_cols):
    pnl_col = "realized_dollars_dynamic_contracts" if "realized_dollars_dynamic_contracts" in df.columns else ("PnL" if "PnL" in df.columns else "pnl")
    grp = df.groupby(by_cols, dropna=False)
    out = grp.agg(
        trades=(by_cols[0] if isinstance(by_cols, list) else by_cols, "size"),
        total_pnl_dollars=(pnl_col, "sum"),
        avg_trade_dollars=(pnl_col, "mean"),
    ).reset_index()
    if "realized_points" in df.columns:
        out["total_points"] = grp["realized_points"].sum().values
        out["avg_points"] = grp["realized_points"].mean().values
    if "return_pct" in df.columns:
        out["win_rate_pct"] = grp["return_pct"].apply(lambda s: (pd.to_numeric(s, errors="coerce").fillna(0.0) > 0).mean() * 100.0).values
    else:
        out["win_rate_pct"] = grp[pnl_col].apply(lambda s: (pd.to_numeric(s, errors="coerce").fillna(0.0) > 0).mean() * 100.0).values
    return out

def main():
    df = load_v470_trades()
    print("1) Loaded V470 trade log")
    print(f"Trades: {len(df)}")
    for label, cols in [
        ("By setup_type", ["setup_type"]),
        ("By bridge_type", ["bridge_type"]),
        ("By setup_type + bridge_type", ["setup_type", "bridge_type"]),
        ("By setup_tier", ["setup_tier"]),
        ("Direction split", ["side"]),
        ("Entry variant", ["entry_variant"]),
    ]:
        if all(c in df.columns for c in cols):
            print(f"\n{label}")
            print(_group_stats(df, cols).to_string(index=False))
    print("\nMonthly realized PnL")
    print(build_monthly_summary(df).to_string(index=False))

if __name__ == "__main__":
    main()
