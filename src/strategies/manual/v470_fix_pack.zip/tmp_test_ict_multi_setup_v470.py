from __future__ import annotations
from v470_shared import try_run_base_engine, save_trade_outputs, print_policy_banner

def main():
    print("1) Loading NQ data...")
    print("📦 Using local cache: expected existing repo cache path")
    print_policy_banner()
    print("2) Running compatible prior engine with V470 export layer...")
    trades, meta, source = try_run_base_engine()
    print(f"3) Base source file used: {source}")
    norm = save_trade_outputs(trades, meta)
    print("4) V470 export complete")
    print(f"Trades exported: {len(norm)}")
    print("Trade CSV: v470_trade_log.csv")
    return norm

if __name__ == "__main__":
    main()
