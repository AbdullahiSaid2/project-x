# ICT Fractal Trade Management Full Files

This package contains full replacement files:

```text
src/backtesting/event_engine/run_event_backtest.py
src/strategies/adapters/ict_fractal_v2_quality_plus_event_adapter.py
```

## Adds to event engine

```text
--enable-breakeven
--breakeven-trigger-r
--enable-partials
--partial-trigger-r
--partial-close-pct
--enable-runner-trail
--runner-trail-lookback
```

## Adds strategy

```text
--strategy ict_fractal_v2_quality_plus
```

## Install

```bash
cd /Users/Abdullahi/trading-project/trading_system

unzip /path/to/ict_fractal_trade_management_full_files.zip -d /tmp/ict_trade_mgmt

cp -R /tmp/ict_trade_mgmt/src/* src/
```

## Run

```bash
PYTHONPATH=. python -m src.backtesting.event_engine.run_event_backtest \
  --strategy ict_fractal_v2_quality_plus \
  --symbols MNQ MYM MES \
  --prop-profile apex_50k_pa \
  --days-back 365 \
  --timeframe 1m \
  --no-tail \
  --commission-per-contract-side 2.0 \
  --min-trend-score 4 \
  --target-r 10.0 \
  --min-planned-target-dollars 500 \
  --enable-breakeven \
  --breakeven-trigger-r 1.0 \
  --enable-partials \
  --partial-trigger-r 2.0 \
  --partial-close-pct 0.50 \
  --enable-runner-trail \
  --runner-trail-lookback 5 \
  --news-events src/strategies/manual/researched_prop_trend/news_events.csv \
  --output-prefix ict_fractal_v2_quality_plus_trade_mgmt_365
```
