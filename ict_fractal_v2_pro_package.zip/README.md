# ICT Fractal V2 Pro Package

Adds:

```text
--strategy ict_fractal_v2_pro
```

This is a stronger refinement layer over `ict_fractal_v2`.

## Install

```bash
cd /Users/Abdullahi/trading-project/trading_system

unzip /path/to/ict_fractal_v2_pro_package.zip -d /tmp/ict_v2_pro

cp -R /tmp/ict_v2_pro/src/* src/
```

## Patch run_event_backtest.py

Inside `load_adapter(name: str)`, add:

```python
if name == "ict_fractal_v2_pro":
    from src.strategies.adapters.ict_fractal_v2_pro_event_adapter import (
        ICTFractalV2ProAdapter,
    )
    return ICTFractalV2ProAdapter()
```

Inside `parse_args()`, add this to strategy choices:

```python
"ict_fractal_v2_pro"
```

## Run

```bash
PYTHONPATH=. python -m src.backtesting.event_engine.run_event_backtest \
  --strategy ict_fractal_v2_pro \
  --symbols MNQ MES MYM MGC \
  --prop-profile apex_50k_pa \
  --days-back 365 \
  --timeframe 1m \
  --no-tail \
  --commission-per-contract-side 2.0 \
  --min-trend-score 4 \
  --target-r 10.0 \
  --min-planned-target-dollars 500 \
  --news-events src/strategies/manual/researched_prop_trend/news_events.csv \
  --output-prefix ict_fractal_v2_pro_365
```

Diagnostics:

```bash
cat src/backtesting/event_engine/outputs/ict_fractal_v2_pro_filter_diagnostics.csv
```
