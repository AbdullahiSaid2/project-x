# ICT Fractal V2 Quality — Block MYM Long

This package replaces:

```text
src/strategies/adapters/ict_fractal_v2_quality_event_adapter.py
```

It keeps:

```text
--strategy ict_fractal_v2_quality
```

No `run_event_backtest.py` patch is needed.

## What changed

The latest BE + partial-only run showed:

```text
MYM LONG: -$1,243.12
```

So this version blocks:

```text
MYM LONG
```

It also continues blocking:

```text
ASIA_CONTINUATION_iFVG_B_LONG
```

## Install

```bash
cd /Users/Abdullahi/trading-project/trading_system

unzip /path/to/ict_fractal_v2_quality_block_mym_long.zip -d /tmp/ict_block_mym_long

cp -R /tmp/ict_block_mym_long/src/* src/
```

## Run

```bash
PYTHONPATH=. python -m src.backtesting.event_engine.run_event_backtest \
  --strategy ict_fractal_v2_quality \
  --symbols MNQ MYM MES \
  --prop-profile apex_50k_pa \
  --days-back 365 \
  --timeframe 1m \
  --no-tail \
  --commission-per-contract-side 2.0 \
  --min-trend-score 4 \
  --target-r 10.0 \
  --min-planned-target-dollars 500 \
  --enable-breakeven \
  --breakeven-trigger-r 1.0 \
  --enable-partials \
  --partial-trigger-r 2.0 \
  --partial-close-pct 0.50 \
  --news-events src/strategies/manual/researched_prop_trend/news_events.csv \
  --output-prefix ict_fractal_v2_quality_be_partial_no_mym_long
```

## Diagnostics

```bash
cat src/backtesting/event_engine/outputs/ict_fractal_v2_quality_filter_diagnostics.csv
```
