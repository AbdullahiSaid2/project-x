from __future__ import annotations

from datetime import time
from pathlib import Path

import pandas as pd


# =========================================================
# TOP BOTTOM TICKING V2 — DIAGNOSTIC DISCOVERY BUILD
# =========================================================
#
# Purpose:
#   The previous strict and relaxed V2 builds produced 0 trades.
#   This build does two things:
#
#   1. Adds diagnostic counters so we can see exactly which filters
#      are blocking signals.
#
#   2. Adds DISCOVERY_MODE so the strategy can generate controlled
#      candidate trades from the intended model:
#
#          liquidity sweep
#          + directional rejection
#          + local structure shift
#          + CE/RB interaction
#
#   Then we can measure trade quality and tighten step by step.
#
# Important:
#   This is NOT the final live model. It is a research/diagnostic
#   version to discover where the real edge is.
# =========================================================


# =========================================================
# CONFIG
# =========================================================

TARGET_R = 10.0

STOP_BUFFER = 0.10

# Wider CE tolerance for discovery.
CE_TOLERANCE = 0.75

# Very relaxed thresholds for discovery.
MIN_DISPLACEMENT_ATR = 0.35
MIN_BODY_RATIO = 0.20

MIN_RB_DISPLACEMENT = 0.25
MIN_RB_BODY_RATIO = 0.15

MIN_VOLATILITY_RATIO = 0.30
EXPANSION_THRESHOLD = 0.30

MAX_TRADES_PER_DAY = 4

# Discovery mode allows signals without mandatory FVG and without requiring
# all strict conditions to fire on the same candle.
DISCOVERY_MODE = True

# ET windows.
LONDON_KILLZONE = (time(2, 0), time(5, 30))
NY_AM = (time(8, 30), time(11, 30))
NY_PM = (time(13, 30), time(15, 30))

# Where diagnostics are written.
DIAG_DIR = Path("src/backtesting/event_engine/outputs")
DIAG_DIR.mkdir(parents=True, exist_ok=True)
DIAG_PATH = DIAG_DIR / "top_bottom_ticking_v2_signal_diagnostics.csv"


# =========================================================
# COLUMN NORMALIZATION
# =========================================================

def _normalise_columns(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()

    rename_map = {
        "Open": "open",
        "High": "high",
        "Low": "low",
        "Close": "close",
        "Volume": "volume",
    }

    for old, new in rename_map.items():
        if old in out.columns and new not in out.columns:
            out[new] = out[old]

    required = ["open", "high", "low", "close"]
    missing = [c for c in required if c not in out.columns]

    if missing:
        raise ValueError(
            f"top_bottom_ticking_v2 missing required columns: {missing}. "
            f"Available columns: {list(out.columns)}"
        )

    return out


# =========================================================
# SIGNAL-LEVEL DAILY THROTTLE
# =========================================================

class PayoutRiskManager:
    def __init__(self):
        self.daily_trades = 0
        self.locked = False

    def reset_day(self):
        self.daily_trades = 0
        self.locked = False

    def can_trade(self):
        return not self.locked

    def register_signal(self):
        self.daily_trades += 1

        if self.daily_trades >= MAX_TRADES_PER_DAY:
            self.locked = True


# =========================================================
# TIME / SESSION
# =========================================================

def _to_et_timestamp(ts):
    ts = pd.Timestamp(ts)

    if ts.tzinfo is None:
        ts = ts.tz_localize("UTC")

    return ts.tz_convert("America/New_York")


def allowed_session(timestamp_value):
    ts_et = _to_et_timestamp(timestamp_value)
    t = ts_et.time()

    return (
        LONDON_KILLZONE[0] <= t <= LONDON_KILLZONE[1]
        or NY_AM[0] <= t <= NY_AM[1]
        or NY_PM[0] <= t <= NY_PM[1]
    )


# =========================================================
# ATR / VOLATILITY
# =========================================================

def _atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
    high = df["high"]
    low = df["low"]
    close = df["close"]
    prev_close = close.shift(1)

    tr = pd.concat(
        [
            high - low,
            (high - prev_close).abs(),
            (low - prev_close).abs(),
        ],
        axis=1,
    ).max(axis=1)

    return tr.rolling(period, min_periods=period).mean()


def volatility_ok(current_atr, rolling_atr):
    if pd.isna(current_atr) or pd.isna(rolling_atr):
        return False

    return float(current_atr) >= float(rolling_atr) * MIN_VOLATILITY_RATIO


def expansion_regime(current_atr, rolling_atr):
    if pd.isna(current_atr) or pd.isna(rolling_atr):
        return False

    return float(current_atr) >= float(rolling_atr) * EXPANSION_THRESHOLD


# =========================================================
# BASIC CANDLE / STRUCTURE HELPERS
# =========================================================

def candle_range(candle):
    return float(candle.high) - float(candle.low)


def candle_body(candle):
    return abs(float(candle.close) - float(candle.open))


def candle_body_ratio(candle):
    rng = candle_range(candle)

    if rng <= 0:
        return 0.0

    return candle_body(candle) / rng


def displacement_strength(candle, atr):
    return candle_range(candle) / max(float(atr), 0.01)


def valid_displacement(candle, atr):
    return (
        displacement_strength(candle, atr) >= MIN_DISPLACEMENT_ATR
        and candle_body_ratio(candle) >= MIN_BODY_RATIO
    )


def bullish_rejection(candle):
    # Rejection candle closes above open and ideally away from lows.
    return float(candle.close) > float(candle.open)


def bearish_rejection(candle):
    # Rejection candle closes below open and ideally away from highs.
    return float(candle.close) < float(candle.open)


# =========================================================
# LIQUIDITY SWEEPS
# =========================================================

def bullish_sweep_window(df: pd.DataFrame, i: int, lookback: int = 20) -> bool:
    if i - lookback < 0:
        return False

    current_low = float(df.iloc[i]["low"])
    prior_low = float(df.iloc[i - lookback:i]["low"].min())

    return current_low < prior_low


def bearish_sweep_window(df: pd.DataFrame, i: int, lookback: int = 20) -> bool:
    if i - lookback < 0:
        return False

    current_high = float(df.iloc[i]["high"])
    prior_high = float(df.iloc[i - lookback:i]["high"].max())

    return current_high > prior_high


# =========================================================
# MSS / STRUCTURE SHIFT
# =========================================================

def bullish_structure_shift(df: pd.DataFrame, i: int, lookback: int = 5) -> bool:
    if i - lookback < 0:
        return False

    prior_high = float(df.iloc[i - lookback:i]["high"].max())
    close = float(df.iloc[i]["close"])

    return close > prior_high


def bearish_structure_shift(df: pd.DataFrame, i: int, lookback: int = 5) -> bool:
    if i - lookback < 0:
        return False

    prior_low = float(df.iloc[i - lookback:i]["low"].min())
    close = float(df.iloc[i]["close"])

    return close < prior_low


# =========================================================
# REJECTION BLOCKS
# =========================================================

def calculate_ce(high, low):
    return (float(high) + float(low)) / 2.0


def valid_rejection_block(candle, atr):
    return (
        displacement_strength(candle, atr) >= MIN_RB_DISPLACEMENT
        and candle_body_ratio(candle) >= MIN_RB_BODY_RATIO
    )


def build_rejection_block(candle, direction, atr):
    if not valid_rejection_block(candle, atr):
        return None

    return {
        "direction": direction,
        "high": float(candle.high),
        "low": float(candle.low),
        "open": float(candle.open),
        "close": float(candle.close),
        "ce": calculate_ce(candle.high, candle.low),
        "timestamp": candle.name,
    }


def find_recent_rejection_block(
    df: pd.DataFrame,
    i: int,
    direction: str,
    atr: float,
    lookback: int = 20,
):
    start = max(2, i - lookback)

    for j in range(i, start - 1, -1):
        candle = df.iloc[j]

        if direction == "bullish" and not bullish_rejection(candle):
            continue

        if direction == "bearish" and not bearish_rejection(candle):
            continue

        rb = build_rejection_block(candle, direction, atr)

        if rb is not None:
            return rb

    return None


# =========================================================
# FAIR VALUE GAPS
# =========================================================

def bullish_fvg(c1, c2, c3):
    if float(c1.high) < float(c3.low):
        return {
            "direction": "bullish",
            "upper": float(c3.low),
            "lower": float(c1.high),
            "midpoint": (float(c3.low) + float(c1.high)) / 2.0,
        }

    return None


def bearish_fvg(c1, c2, c3):
    if float(c1.low) > float(c3.high):
        return {
            "direction": "bearish",
            "upper": float(c1.low),
            "lower": float(c3.high),
            "midpoint": (float(c1.low) + float(c3.high)) / 2.0,
        }

    return None


def recent_bullish_fvg(df: pd.DataFrame, i: int, lookback: int = 5):
    start = max(2, i - lookback + 1)

    for j in range(i, start - 1, -1):
        fvg = bullish_fvg(df.iloc[j - 2], df.iloc[j - 1], df.iloc[j])
        if fvg:
            return fvg

    return None


def recent_bearish_fvg(df: pd.DataFrame, i: int, lookback: int = 5):
    start = max(2, i - lookback + 1)

    for j in range(i, start - 1, -1):
        fvg = bearish_fvg(df.iloc[j - 2], df.iloc[j - 1], df.iloc[j])
        if fvg:
            return fvg

    return None


# =========================================================
# ENTRY HELPERS
# =========================================================

def near_ce(price, ce_level, rb_range):
    if rb_range <= 0:
        return False

    tolerance = rb_range * CE_TOLERANCE

    return abs(float(price) - float(ce_level)) <= tolerance


def inside_rb(price, rb):
    return float(rb["low"]) <= float(price) <= float(rb["high"])


def long_plan(timestamp, candle, rb, setup):
    entry = float(candle.close)
    stop = float(rb["low"]) - STOP_BUFFER
    risk = entry - stop

    if risk <= 0:
        return None

    return {
        "timestamp": timestamp,
        "side": "LONG",
        "entry": entry,
        "stop": stop,
        "target": entry + (risk * TARGET_R),
        "risk": risk,
        "setup": setup,
    }


def short_plan(timestamp, candle, rb, setup):
    entry = float(candle.close)
    stop = float(rb["high"]) + STOP_BUFFER
    risk = stop - entry

    if risk <= 0:
        return None

    return {
        "timestamp": timestamp,
        "side": "SHORT",
        "entry": entry,
        "stop": stop,
        "target": entry - (risk * TARGET_R),
        "risk": risk,
        "setup": setup,
    }


# =========================================================
# DIAGNOSTICS
# =========================================================

def _empty_diag():
    return {
        "bars_seen": 0,
        "blocked_session": 0,
        "blocked_atr": 0,
        "blocked_volatility": 0,
        "blocked_expansion": 0,
        "bull_sweep": 0,
        "bear_sweep": 0,
        "bull_shift": 0,
        "bear_shift": 0,
        "bull_displacement": 0,
        "bear_displacement": 0,
        "bull_rb": 0,
        "bear_rb": 0,
        "bull_fvg": 0,
        "bear_fvg": 0,
        "bull_ce_or_rb_touch": 0,
        "bear_ce_or_rb_touch": 0,
        "long_signals": 0,
        "short_signals": 0,
    }


def _write_diag(diag: dict):
    df = pd.DataFrame([diag])
    df.to_csv(DIAG_PATH, index=False)


# =========================================================
# MAIN STRATEGY ENGINE
# =========================================================

def generate_top_bottom_ticking_v2_signals(df: pd.DataFrame) -> pd.DataFrame:
    """
    Generates planned entry signals only.

    Event engine handles:
      - position sizing
      - fills
      - commissions
      - stop/target execution
      - same-bar prevention
      - prop account controls

    This diagnostic discovery build is meant to reveal which filters create
    usable trade flow.
    """
    df = _normalise_columns(df)

    trades = []
    diag = _empty_diag()
    risk_manager = PayoutRiskManager()

    if "atr" not in df.columns:
        df["atr"] = _atr(df, 14)

    df["rolling_atr"] = df["atr"].rolling(50, min_periods=50).mean()

    current_day = None

    for i in range(60, len(df) - 1):
        diag["bars_seen"] += 1

        candle = df.iloc[i]
        timestamp = candle.name
        timestamp_et = _to_et_timestamp(timestamp)

        if current_day != timestamp_et.date():
            current_day = timestamp_et.date()
            risk_manager.reset_day()

        if not risk_manager.can_trade():
            continue

        if not allowed_session(timestamp):
            diag["blocked_session"] += 1
            continue

        atr = candle.atr
        rolling_atr = candle.rolling_atr

        if pd.isna(atr) or pd.isna(rolling_atr):
            diag["blocked_atr"] += 1
            continue

        if not volatility_ok(atr, rolling_atr):
            diag["blocked_volatility"] += 1
            continue

        if not expansion_regime(atr, rolling_atr):
            diag["blocked_expansion"] += 1
            continue

        bull_sweep = bullish_sweep_window(df, i, lookback=20)
        bear_sweep = bearish_sweep_window(df, i, lookback=20)

        if bull_sweep:
            diag["bull_sweep"] += 1

        if bear_sweep:
            diag["bear_sweep"] += 1

        bull_shift = bullish_structure_shift(df, i, lookback=5)
        bear_shift = bearish_structure_shift(df, i, lookback=5)

        if bull_shift:
            diag["bull_shift"] += 1

        if bear_shift:
            diag["bear_shift"] += 1

        displacement_ok = valid_displacement(candle, atr)

        if displacement_ok and bull_shift:
            diag["bull_displacement"] += 1

        if displacement_ok and bear_shift:
            diag["bear_displacement"] += 1

        bullish_rb = find_recent_rejection_block(
            df=df,
            i=i,
            direction="bullish",
            atr=atr,
            lookback=20,
        )

        bearish_rb = find_recent_rejection_block(
            df=df,
            i=i,
            direction="bearish",
            atr=atr,
            lookback=20,
        )

        if bullish_rb:
            diag["bull_rb"] += 1

        if bearish_rb:
            diag["bear_rb"] += 1

        bull_fvg = recent_bullish_fvg(df, i, lookback=5)
        bear_fvg = recent_bearish_fvg(df, i, lookback=5)

        if bull_fvg:
            diag["bull_fvg"] += 1

        if bear_fvg:
            diag["bear_fvg"] += 1

        # =====================================================
        # LONG DISCOVERY SETUP
        # =====================================================

        if bull_sweep and bull_shift and displacement_ok and bullish_rb:
            rb_range = bullish_rb["high"] - bullish_rb["low"]

            ce_ok = near_ce(candle.close, bullish_rb["ce"], rb_range)
            touch_ok = inside_rb(candle.close, bullish_rb)

            if ce_ok or touch_ok or DISCOVERY_MODE:
                diag["bull_ce_or_rb_touch"] += 1

                setup = (
                    "top_bottom_ticking_v2_long_"
                    + ("fvg_" if bull_fvg else "")
                    + "sweep_shift_rb"
                    + ("_ce" if ce_ok else "_discovery")
                )

                plan = long_plan(timestamp, candle, bullish_rb, setup)

                if plan:
                    trades.append(plan)
                    diag["long_signals"] += 1
                    risk_manager.register_signal()

        # =====================================================
        # SHORT DISCOVERY SETUP
        # =====================================================

        if bear_sweep and bear_shift and displacement_ok and bearish_rb:
            rb_range = bearish_rb["high"] - bearish_rb["low"]

            ce_ok = near_ce(candle.close, bearish_rb["ce"], rb_range)
            touch_ok = inside_rb(candle.close, bearish_rb)

            if ce_ok or touch_ok or DISCOVERY_MODE:
                diag["bear_ce_or_rb_touch"] += 1

                setup = (
                    "top_bottom_ticking_v2_short_"
                    + ("fvg_" if bear_fvg else "")
                    + "sweep_shift_rb"
                    + ("_ce" if ce_ok else "_discovery")
                )

                plan = short_plan(timestamp, candle, bearish_rb, setup)

                if plan:
                    trades.append(plan)
                    diag["short_signals"] += 1
                    risk_manager.register_signal()

    _write_diag(diag)

    return pd.DataFrame(trades)
