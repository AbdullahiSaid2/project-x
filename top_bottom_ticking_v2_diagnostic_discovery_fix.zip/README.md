# Top Bottom Ticking V2 Diagnostic Discovery Fix

This replaces:

```text
src/strategies/manual/ict_top_bottom_ticking_v2.py
```

It adds diagnostics and discovery mode.

Diagnostics file:

```text
src/backtesting/event_engine/outputs/top_bottom_ticking_v2_signal_diagnostics.csv
```

Install:

```bash
cd /Users/Abdullahi/trading-project/trading_system

unzip /path/to/top_bottom_ticking_v2_diagnostic_discovery_fix.zip -d /tmp/tbt_v2_diag

cp -R /tmp/tbt_v2_diag/src/* src/
```

Run smoke test again:

```bash
PYTHONPATH=. python -m src.backtesting.event_engine.run_event_backtest \
  --strategy top_bottom_ticking_v2 \
  --symbols MNQ \
  --prop-profile apex_50k_pa \
  --days-back 60 \
  --timeframe 1m \
  --no-tail \
  --commission-per-contract-side 2.0 \
  --target-r 10.0 \
  --min-planned-target-dollars 500 \
  --news-events src/strategies/manual/researched_prop_trend/news_events.csv \
  --output-prefix top_bottom_ticking_v2_smoke
```

Then inspect:

```bash
cat src/backtesting/event_engine/outputs/top_bottom_ticking_v2_signal_diagnostics.csv
```
