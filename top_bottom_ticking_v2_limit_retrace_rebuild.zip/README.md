# Top Bottom Ticking V2 Limit Retrace Rebuild

This replaces:

```text
src/strategies/manual/ict_top_bottom_ticking_v2.py
```

Core fix:

```text
MSS confirmation does NOT enter immediately.
MSS arms a retrace entry.
The trade only triggers if price returns to RB CE or FVG midpoint.
```

Flow:

```text
external sweep
→ pending setup
→ rejection block
→ CE touch
→ internal sweep
→ MSS/displacement
→ arm retrace entry
→ entry fills only on retrace
```

## Install

```bash
cd /Users/Abdullahi/trading-project/trading_system

unzip /path/to/top_bottom_ticking_v2_limit_retrace_rebuild.zip -d /tmp/tbt_v2_limit

cp -R /tmp/tbt_v2_limit/src/* src/
```

## Run MNQ 365 raw test

```bash
PYTHONPATH=. python -m src.backtesting.event_engine.run_event_backtest \
  --strategy top_bottom_ticking_v2 \
  --symbols MNQ \
  --prop-profile apex_50k_pa \
  --days-back 365 \
  --timeframe 1m \
  --no-tail \
  --commission-per-contract-side 2.0 \
  --target-r 10.0 \
  --min-planned-target-dollars 500 \
  --disable-account-drawdown-lock \
  --news-events src/strategies/manual/researched_prop_trend/news_events.csv \
  --output-prefix top_bottom_ticking_v2_limit_mnq_365_raw
```

Diagnostics:

```bash
cat src/backtesting/event_engine/outputs/top_bottom_ticking_v2_limit_retrace_diagnostics.csv
```
