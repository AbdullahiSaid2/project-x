# Top Bottom Ticking V2 Sweep Confirmation Rebuild

This replaces:

```text
src/strategies/manual/ict_top_bottom_ticking_v2.py
```

Core fix:

```text
Liquidity sweep is NOT an entry signal.
It only creates a pending setup.
Then the bot waits for:
  rejection block
  CE revisit
  internal sweep
  MSS/displacement
  entry
```

## Install

```bash
cd /Users/Abdullahi/trading-project/trading_system

unzip /path/to/top_bottom_ticking_v2_sweep_confirmation_rebuild.zip -d /tmp/tbt_v2_confirm

cp -R /tmp/tbt_v2_confirm/src/* src/
```

## Run MNQ 365 raw test

```bash
PYTHONPATH=. python -m src.backtesting.event_engine.run_event_backtest \
  --strategy top_bottom_ticking_v2 \
  --symbols MNQ \
  --prop-profile apex_50k_pa \
  --days-back 365 \
  --timeframe 1m \
  --no-tail \
  --commission-per-contract-side 2.0 \
  --target-r 10.0 \
  --min-planned-target-dollars 500 \
  --disable-account-drawdown-lock \
  --news-events src/strategies/manual/researched_prop_trend/news_events.csv \
  --output-prefix top_bottom_ticking_v2_confirm_mnq_365_raw
```

Diagnostics:

```bash
cat src/backtesting/event_engine/outputs/top_bottom_ticking_v2_sweep_confirmation_diagnostics.csv
```
