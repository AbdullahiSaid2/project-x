from __future__ import annotations

from datetime import time

import pandas as pd


# =========================================================
# TOP BOTTOM TICKING V2 — RELAXED SIGNAL FIX
# =========================================================
#
# This version fixes the zero-trade issue from the first strict V2 build.
#
# Why the first V2 produced 0 trades:
#   1. London session was incorrectly treated as 08:00-11:30 ET.
#      True London killzone in ET is closer to 02:00-05:00.
#
#   2. The combined filters were too strict:
#      - displacement >= 1.5 ATR
#      - body ratio >= 0.60
#      - expansion regime only
#      - exact CE interaction
#      - mandatory FVG
#
#   3. It required all filters on the same candle, which is too restrictive.
#
# New approach:
#   - Keep the intended model:
#       rejection block CE
#       liquidity sweep
#       MSS/displacement
#       tight SL
#       high target-R
#
#   - But relax the first pass so the engine can actually generate trades.
#
# Once we see trades, we tune stricter again using diagnostics.
# =========================================================


# =========================================================
# CONFIG
# =========================================================

TARGET_R = 10.0

# Small extra stop buffer in points.
# Event engine still controls position sizing and prop risk.
STOP_BUFFER = 0.10

# First strict version used 0.10. That meant close had to be almost exactly
# at CE. For discovery, we allow wider CE interaction.
CE_TOLERANCE = 0.50

# Relaxed displacement rules.
MIN_DISPLACEMENT_ATR = 0.80
MIN_BODY_RATIO = 0.40

# Relaxed rejection block rules.
MIN_RB_DISPLACEMENT = 0.50
MIN_RB_BODY_RATIO = 0.30

# Volatility filters.
MIN_VOLATILITY_RATIO = 0.50
EXPANSION_THRESHOLD = 0.60

# Daily signal throttle. This is signal-level only.
MAX_TRADES_PER_DAY = 4

# These are placeholders for future realised-R tracking.
MAX_CONSECUTIVE_LOSSES = 2
MAX_DAILY_R_LOSS = -2.0
DAILY_PROFIT_LOCK = 4.0

PARTIAL_R = 2.0
PARTIAL_CLOSE = 0.50

# Times below are ET.
# London killzone roughly 02:00-05:00 ET.
LONDON_KILLZONE = (time(2, 0), time(5, 0))

# NY AM roughly 08:30-11:30 ET.
NY_AM = (time(8, 30), time(11, 30))

# NY PM optional continuation/reversal window.
NY_PM = (time(13, 30), time(15, 30))


# =========================================================
# COLUMN NORMALIZATION
# =========================================================

def _normalise_columns(df: pd.DataFrame) -> pd.DataFrame:
    """
    Supports both event-engine OHLC and lowercase OHLC.

    Event engine usually uses:
        Open, High, Low, Close

    Some old/manual strategy files use:
        open, high, low, close
    """
    out = df.copy()

    rename_map = {
        "Open": "open",
        "High": "high",
        "Low": "low",
        "Close": "close",
        "Volume": "volume",
    }

    for old, new in rename_map.items():
        if old in out.columns and new not in out.columns:
            out[new] = out[old]

    required = ["open", "high", "low", "close"]
    missing = [c for c in required if c not in out.columns]

    if missing:
        raise ValueError(
            f"top_bottom_ticking_v2 missing required columns: {missing}. "
            f"Available columns: {list(out.columns)}"
        )

    return out


# =========================================================
# PAYOUT / SIGNAL THROTTLE MANAGER
# =========================================================

class PayoutRiskManager:
    """
    This is only a signal-level throttle.

    Actual:
      - fills
      - stop hits
      - target hits
      - commissions
      - daily realised loss
      - prop drawdown

    are handled by the event engine and lifecycle simulator.
    """

    def __init__(self):
        self.daily_r = 0.0
        self.daily_trades = 0
        self.consecutive_losses = 0
        self.locked = False

    def reset_day(self):
        self.daily_r = 0.0
        self.daily_trades = 0
        self.consecutive_losses = 0
        self.locked = False

    def can_trade(self):
        return not self.locked

    def register_signal(self):
        self.daily_trades += 1

        if self.daily_trades >= MAX_TRADES_PER_DAY:
            self.locked = True


# =========================================================
# TIMEZONE / SESSION HELPERS
# =========================================================

def _to_et_timestamp(ts):
    ts = pd.Timestamp(ts)

    if ts.tzinfo is None:
        ts = ts.tz_localize("UTC")

    return ts.tz_convert("America/New_York")


def allowed_session(timestamp_value):
    """
    Trade only active futures windows.

    Note:
      timestamp input is normally UTC from Databento cache.
      We convert it to ET before checking sessions.
    """
    ts_et = _to_et_timestamp(timestamp_value)
    t = ts_et.time()

    return (
        LONDON_KILLZONE[0] <= t <= LONDON_KILLZONE[1]
        or NY_AM[0] <= t <= NY_AM[1]
        or NY_PM[0] <= t <= NY_PM[1]
    )


# =========================================================
# ATR / VOLATILITY / REGIME FILTERS
# =========================================================

def _atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
    high = df["high"]
    low = df["low"]
    close = df["close"]
    prev_close = close.shift(1)

    tr = pd.concat(
        [
            high - low,
            (high - prev_close).abs(),
            (low - prev_close).abs(),
        ],
        axis=1,
    ).max(axis=1)

    return tr.rolling(period, min_periods=period).mean()


def volatility_ok(current_atr, rolling_atr):
    if pd.isna(current_atr) or pd.isna(rolling_atr):
        return False

    return current_atr >= (rolling_atr * MIN_VOLATILITY_RATIO)


def expansion_regime(current_atr, rolling_atr):
    if pd.isna(current_atr) or pd.isna(rolling_atr):
        return False

    return current_atr > (rolling_atr * EXPANSION_THRESHOLD)


# =========================================================
# LIQUIDITY SWEEPS
# =========================================================

def bullish_sweep(current_low, previous_low):
    return float(current_low) < float(previous_low)


def bearish_sweep(current_high, previous_high):
    return float(current_high) > float(previous_high)


def bullish_sweep_window(df: pd.DataFrame, i: int, lookback: int = 10) -> bool:
    """
    Sweeps any prior low in a short local window.
    More realistic than only comparing to previous candle.
    """
    if i - lookback < 0:
        return False

    current_low = float(df.iloc[i]["low"])
    prior_low = float(df.iloc[i - lookback:i]["low"].min())

    return current_low < prior_low


def bearish_sweep_window(df: pd.DataFrame, i: int, lookback: int = 10) -> bool:
    """
    Sweeps any prior high in a short local window.
    """
    if i - lookback < 0:
        return False

    current_high = float(df.iloc[i]["high"])
    prior_high = float(df.iloc[i - lookback:i]["high"].max())

    return current_high > prior_high


# =========================================================
# MSS LOGIC
# =========================================================

def displacement_strength(candle, atr):
    return (float(candle.high) - float(candle.low)) / max(float(atr), 0.01)


def candle_body_ratio(candle):
    rng = float(candle.high) - float(candle.low)

    if rng <= 0:
        return 0.0

    return abs(float(candle.close) - float(candle.open)) / rng


def valid_displacement(candle, atr):
    return (
        displacement_strength(candle, atr) >= MIN_DISPLACEMENT_ATR
        and candle_body_ratio(candle) >= MIN_BODY_RATIO
    )


def bullish_mss(candle, prior_high, atr):
    """
    Relaxed but still structure-based:
      - displacement candle
      - body closes above local prior high
    """
    return valid_displacement(candle, atr) and float(candle.close) > float(prior_high)


def bearish_mss(candle, prior_low, atr):
    """
    Relaxed but still structure-based:
      - displacement candle
      - body closes below local prior low
    """
    return valid_displacement(candle, atr) and float(candle.close) < float(prior_low)


# =========================================================
# REJECTION BLOCKS
# =========================================================

def calculate_ce(high, low):
    return (float(high) + float(low)) / 2.0


def valid_rejection_block(candle, atr):
    body = candle_body_ratio(candle)
    displacement = (float(candle.high) - float(candle.low)) / max(float(atr), 0.01)

    return (
        displacement >= MIN_RB_DISPLACEMENT
        and body >= MIN_RB_BODY_RATIO
    )


def build_rejection_block(candle, direction, atr):
    if not valid_rejection_block(candle, atr):
        return None

    return {
        "direction": direction,
        "high": float(candle.high),
        "low": float(candle.low),
        "open": float(candle.open),
        "close": float(candle.close),
        "ce": calculate_ce(candle.high, candle.low),
        "timestamp": candle.name,
    }


def find_recent_rejection_block(
    df: pd.DataFrame,
    i: int,
    direction: str,
    atr: float,
    lookback: int = 8,
):
    """
    Finds a recent rejection block instead of requiring the immediately
    previous candle to be the RB.

    This fixes the zero-trade issue caused by making RB, sweep, MSS, FVG and
    CE all happen in an unrealistically tight sequence.
    """
    start = max(2, i - lookback)

    for j in range(i - 1, start - 1, -1):
        candle = df.iloc[j]
        rb = build_rejection_block(candle, direction, atr)

        if rb is not None:
            return rb

    return None


# =========================================================
# FAIR VALUE GAPS
# =========================================================

def bullish_fvg(c1, c2, c3):
    if float(c1.high) < float(c3.low):
        return {
            "direction": "bullish",
            "upper": float(c3.low),
            "lower": float(c1.high),
            "midpoint": (float(c3.low) + float(c1.high)) / 2.0,
        }

    return None


def bearish_fvg(c1, c2, c3):
    if float(c1.low) > float(c3.high):
        return {
            "direction": "bearish",
            "upper": float(c1.low),
            "lower": float(c3.high),
            "midpoint": (float(c1.low) + float(c3.high)) / 2.0,
        }

    return None


def recent_bullish_fvg(df: pd.DataFrame, i: int, lookback: int = 3):
    """
    Looks for a recent bullish FVG around the MSS candle.
    """
    start = max(2, i - lookback + 1)

    for j in range(i, start - 1, -1):
        fvg = bullish_fvg(df.iloc[j - 2], df.iloc[j - 1], df.iloc[j])
        if fvg:
            return fvg

    return None


def recent_bearish_fvg(df: pd.DataFrame, i: int, lookback: int = 3):
    """
    Looks for a recent bearish FVG around the MSS candle.
    """
    start = max(2, i - lookback + 1)

    for j in range(i, start - 1, -1):
        fvg = bearish_fvg(df.iloc[j - 2], df.iloc[j - 1], df.iloc[j])
        if fvg:
            return fvg

    return None


# =========================================================
# ENTRY HELPERS
# =========================================================

def near_ce(price, ce_level, rb_range):
    if rb_range <= 0:
        return False

    tolerance = rb_range * CE_TOLERANCE

    return abs(float(price) - float(ce_level)) <= tolerance


def inside_rb(price, rb):
    return float(rb["low"]) <= float(price) <= float(rb["high"])


# =========================================================
# PARTIALS PLACEHOLDERS
# =========================================================

def should_take_partial(current_r):
    return current_r >= PARTIAL_R


def partial_size(position_size):
    return max(1, int(position_size * PARTIAL_CLOSE))


# =========================================================
# MAIN STRATEGY ENGINE
# =========================================================

def generate_top_bottom_ticking_v2_signals(df: pd.DataFrame) -> pd.DataFrame:
    """
    Generates planned entry signals only.

    Event engine is still responsible for:
      - position sizing
      - entry/stop/target fill simulation
      - commission
      - daily prop/risk logic
      - lifecycle and payout testing

    This version intentionally generates some trades first.
    Once results exist, tighten filters step-by-step.
    """
    df = _normalise_columns(df)

    trades = []
    risk_manager = PayoutRiskManager()

    if "atr" not in df.columns:
        df["atr"] = _atr(df, 14)

    df["rolling_atr"] = df["atr"].rolling(50, min_periods=50).mean()

    current_day = None

    for i in range(60, len(df) - 1):
        candle = df.iloc[i]
        timestamp = candle.name
        timestamp_et = _to_et_timestamp(timestamp)

        if current_day != timestamp_et.date():
            current_day = timestamp_et.date()
            risk_manager.reset_day()

        if not risk_manager.can_trade():
            continue

        if not allowed_session(timestamp):
            continue

        atr = candle.atr
        rolling_atr = candle.rolling_atr

        if pd.isna(atr) or pd.isna(rolling_atr):
            continue

        if not volatility_ok(atr, rolling_atr):
            continue

        if not expansion_regime(atr, rolling_atr):
            continue

        # Local structure levels.
        prior_high = float(df.iloc[i - 10:i]["high"].max())
        prior_low = float(df.iloc[i - 10:i]["low"].min())

        bullish_sweep_ok = bullish_sweep_window(df, i, lookback=10)
        bearish_sweep_ok = bearish_sweep_window(df, i, lookback=10)

        bullish_mss_ok = bullish_mss(candle, prior_high, atr)
        bearish_mss_ok = bearish_mss(candle, prior_low, atr)

        # Find recent RB rather than requiring previous candle.
        bullish_rb = find_recent_rejection_block(
            df=df,
            i=i,
            direction="bullish",
            atr=atr,
            lookback=8,
        )

        bearish_rb = find_recent_rejection_block(
            df=df,
            i=i,
            direction="bearish",
            atr=atr,
            lookback=8,
        )

        # FVG is preferred but no longer mandatory in the first relaxed pass.
        bull_fvg = recent_bullish_fvg(df, i, lookback=3)
        bear_fvg = recent_bearish_fvg(df, i, lookback=3)

        # =====================================================
        # LONG SETUP
        # =====================================================

        if bullish_sweep_ok and bullish_mss_ok and bullish_rb:
            rb_range = bullish_rb["high"] - bullish_rb["low"]

            ce_ok = near_ce(candle.close, bullish_rb["ce"], rb_range)
            rb_touch_ok = inside_rb(candle.close, bullish_rb)

            if ce_ok or rb_touch_ok:
                entry = float(candle.close)
                stop = float(bullish_rb["low"]) - STOP_BUFFER
                risk = entry - stop

                if risk > 0:
                    target = entry + (risk * TARGET_R)

                    trades.append(
                        {
                            "timestamp": timestamp,
                            "side": "LONG",
                            "entry": entry,
                            "stop": stop,
                            "target": target,
                            "risk": risk,
                            "setup": (
                                "top_bottom_ticking_v2_long_"
                                + ("fvg_" if bull_fvg else "")
                                + "sweep_mss_rb_ce"
                            ),
                        }
                    )

                    risk_manager.register_signal()

        # =====================================================
        # SHORT SETUP
        # =====================================================

        if bearish_sweep_ok and bearish_mss_ok and bearish_rb:
            rb_range = bearish_rb["high"] - bearish_rb["low"]

            ce_ok = near_ce(candle.close, bearish_rb["ce"], rb_range)
            rb_touch_ok = inside_rb(candle.close, bearish_rb)

            if ce_ok or rb_touch_ok:
                entry = float(candle.close)
                stop = float(bearish_rb["high"]) + STOP_BUFFER
                risk = stop - entry

                if risk > 0:
                    target = entry - (risk * TARGET_R)

                    trades.append(
                        {
                            "timestamp": timestamp,
                            "side": "SHORT",
                            "entry": entry,
                            "stop": stop,
                            "target": target,
                            "risk": risk,
                            "setup": (
                                "top_bottom_ticking_v2_short_"
                                + ("fvg_" if bear_fvg else "")
                                + "sweep_mss_rb_ce"
                            ),
                        }
                    )

                    risk_manager.register_signal()

    return pd.DataFrame(trades)
