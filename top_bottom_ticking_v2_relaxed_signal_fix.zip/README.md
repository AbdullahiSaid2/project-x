# Top Bottom Ticking V2 Relaxed Signal Fix

This replaces only:

```text
src/strategies/manual/ict_top_bottom_ticking_v2.py
```

The adapter stays the same.

## Why

The first strict V2 generated 0 trades. This version relaxes:
- session timing
- CE tolerance
- displacement threshold
- rejection block threshold
- FVG mandatory requirement
- same-candle sequencing

## Install

```bash
cd /Users/Abdullahi/trading-project/trading_system

unzip /path/to/top_bottom_ticking_v2_relaxed_signal_fix.zip -d /tmp/tbt_v2_relaxed

cp -R /tmp/tbt_v2_relaxed/src/* src/
```

## Smoke test first

```bash
PYTHONPATH=. python -m src.backtesting.event_engine.run_event_backtest \
  --strategy top_bottom_ticking_v2 \
  --symbols MNQ \
  --prop-profile apex_50k_pa \
  --days-back 60 \
  --timeframe 1m \
  --no-tail \
  --commission-per-contract-side 2.0 \
  --target-r 10.0 \
  --min-planned-target-dollars 500 \
  --news-events src/strategies/manual/researched_prop_trend/news_events.csv \
  --output-prefix top_bottom_ticking_v2_smoke
```

Then run the full 365-day command.
