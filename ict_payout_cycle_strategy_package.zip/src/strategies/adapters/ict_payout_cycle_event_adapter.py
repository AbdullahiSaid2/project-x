
from __future__ import annotations

"""
ICT Payout Cycle Model v1.

Mechanical ICT strategy for prop-firm payout behaviour:
HTF bias -> liquidity sweep -> displacement/FVG -> pullback to FVG CE -> structural stop -> PA-friendly target.
"""
from dataclasses import dataclass
from typing import Dict, Optional
import numpy as np
import pandas as pd
from src.backtesting.event_engine.models import OrderPlan, SymbolSpec, PropProfile


def ema(s: pd.Series, n: int) -> pd.Series:
    return s.ewm(span=n, adjust=False).mean()


def atr(df: pd.DataFrame, n: int = 14) -> pd.Series:
    pc = df['Close'].shift(1)
    tr = pd.concat([(df['High']-df['Low']), (df['High']-pc).abs(), (df['Low']-pc).abs()], axis=1).max(axis=1)
    return tr.rolling(n, min_periods=n).mean()


def resample_ohlc(df: pd.DataFrame, rule: str) -> pd.DataFrame:
    return df[['Open','High','Low','Close']].resample(rule).agg({'Open':'first','High':'max','Low':'min','Close':'last'}).dropna()


def swing_high(s: pd.Series, left=2, right=2) -> pd.Series:
    ok = pd.Series(True, index=s.index)
    for i in range(1, left+1): ok &= s > s.shift(i)
    for i in range(1, right+1): ok &= s >= s.shift(-i)
    return s.where(ok).ffill().shift(1)


def swing_low(s: pd.Series, left=2, right=2) -> pd.Series:
    ok = pd.Series(True, index=s.index)
    for i in range(1, left+1): ok &= s < s.shift(i)
    for i in range(1, right+1): ok &= s <= s.shift(-i)
    return s.where(ok).ffill().shift(1)


@dataclass
class PendingFVG:
    direction: str = ''
    expiry_index: int = -1
    sweep_level: float = np.nan
    sweep_extreme: float = np.nan
    fvg_low: float = np.nan
    fvg_high: float = np.nan
    fvg_ce: float = np.nan
    stop: float = np.nan
    setup_score: float = 0.0
    reason: str = ''


class ICTPayoutCycleAdapter:
    name = 'ict_payout_cycle_v1'

    def __init__(self):
        self.pending: Dict[str, PendingFVG] = {}

    def state(self, symbol: str) -> PendingFVG:
        if symbol not in self.pending: self.pending[symbol] = PendingFVG()
        return self.pending[symbol]

    def build_features(self, symbol: str, df: pd.DataFrame) -> pd.DataFrame:
        out = df.copy()
        out['atr14'] = atr(out, 14)
        out['ema20'] = ema(out['Close'], 20); out['ema50'] = ema(out['Close'], 50); out['ema200'] = ema(out['Close'], 200)
        out['body'] = (out['Close']-out['Open']).abs(); out['range'] = (out['High']-out['Low']).replace(0, np.nan)
        out['close_pos'] = (out['Close']-out['Low']) / out['range']
        out['prior_high_60'] = out['High'].rolling(60, min_periods=60).max().shift(1)
        out['prior_low_60'] = out['Low'].rolling(60, min_periods=60).min().shift(1)
        out['swing_high'] = swing_high(out['High']); out['swing_low'] = swing_low(out['Low'])

        # FVGs: bullish gap High[-2] < Low[0]; bearish gap Low[-2] > High[0]
        out['bull_fvg_low'] = out['High'].shift(2); out['bull_fvg_high'] = out['Low']; out['bull_fvg'] = out['bull_fvg_high'] > out['bull_fvg_low']
        out['bear_fvg_low'] = out['High']; out['bear_fvg_high'] = out['Low'].shift(2); out['bear_fvg'] = out['bear_fvg_high'] > out['bear_fvg_low']
        out['bull_displacement'] = (out['Close'] > out['Open']) & (out['body'] >= out['atr14']*0.65) & (out['close_pos'] >= 0.65)
        out['bear_displacement'] = (out['Close'] < out['Open']) & (out['body'] >= out['atr14']*0.65) & (out['close_pos'] <= 0.35)

        # ET session/date features.
        idx = out.index
        et = idx.tz_localize('UTC').tz_convert('America/New_York') if idx.tz is None else idx.tz_convert('America/New_York')
        tmp = out.copy(); tmp['_date'] = et.date; tmp['_hour'] = et.hour; tmp['_minute'] = et.minute
        daily = tmp.groupby('_date').agg(day_high=('High','max'), day_low=('Low','min'))
        daily['prev_day_high'] = daily['day_high'].shift(1); daily['prev_day_low'] = daily['day_low'].shift(1)
        out['prev_day_high'] = tmp['_date'].map(daily['prev_day_high']); out['prev_day_low'] = tmp['_date'].map(daily['prev_day_low'])
        session_dates = [((t+pd.Timedelta(days=1)).date() if t.hour >= 18 else t.date()) for t in et]
        tmp['_session'] = session_dates
        asia = tmp[tmp['_hour'].between(18,23)].groupby('_session').agg(asia_high=('High','max'), asia_low=('Low','min'))
        out['asia_high'] = pd.Series(session_dates, index=out.index).map(asia['asia_high'])
        out['asia_low'] = pd.Series(session_dates, index=out.index).map(asia['asia_low'])

        for frame, prefix, rule in [(None,'h1','1h'), (None,'h4','4h'), (None,'m15','15min')]:
            frame = resample_ohlc(out, rule)
            frame[f'{prefix}_ema20'] = ema(frame['Close'], 20); frame[f'{prefix}_ema50'] = ema(frame['Close'], 50)
            frame[f'{prefix}_ema200'] = ema(frame['Close'], 200); frame[f'{prefix}_atr14'] = atr(frame, 14)
            feats = frame[[f'{prefix}_ema20', f'{prefix}_ema50', f'{prefix}_ema200', f'{prefix}_atr14']].shift(1)
            out = out.join(feats.reindex(out.index, method='ffill'))

        out['bull_htf_bias'] = (out['Close'] > out['h1_ema50']) & (out['h1_ema20'] > out['h1_ema50']) & (out['h4_ema20'] > out['h4_ema50'])
        out['bear_htf_bias'] = (out['Close'] < out['h1_ema50']) & (out['h1_ema20'] < out['h1_ema50']) & (out['h4_ema20'] < out['h4_ema50'])
        mins = et.hour*60 + et.minute
        out['is_london'] = (mins >= 2*60) & (mins <= 5*60)
        out['is_nyam'] = (mins >= 8*60+30) & (mins <= 11*60)
        out['is_nypm'] = (mins >= 13*60+30) & (mins <= 15*60+30)
        out['is_valid_entry_window'] = out['is_london'] | out['is_nyam'] | out['is_nypm']
        return out

    def score_long(self, row) -> float:
        return float(int(bool(row.get('bull_htf_bias', False))) + int(bool(row.get('bull_displacement', False))) + int(bool(row.get('bull_fvg', False))) + int(bool(row.get('is_valid_entry_window', False))) + int(float(row.get('Close', 0)) > float(row.get('h1_ema50', np.inf))))

    def score_short(self, row) -> float:
        return float(int(bool(row.get('bear_htf_bias', False))) + int(bool(row.get('bear_displacement', False))) + int(bool(row.get('bear_fvg', False))) + int(bool(row.get('is_valid_entry_window', False))) + int(float(row.get('Close', 0)) < float(row.get('h1_ema50', -np.inf))))

    def long_sweep(self, row) -> Optional[float]:
        low = float(row['Low']); levels = [row.get('prev_day_low'), row.get('asia_low'), row.get('prior_low_60'), row.get('swing_low')]
        valid = [float(x) for x in levels if pd.notna(x) and low < float(x)]
        return max(valid) if valid else None

    def short_sweep(self, row) -> Optional[float]:
        high = float(row['High']); levels = [row.get('prev_day_high'), row.get('asia_high'), row.get('prior_high_60'), row.get('swing_high')]
        valid = [float(x) for x in levels if pd.notna(x) and high > float(x)]
        return min(valid) if valid else None

    def arm_long(self, symbol, row, i, args):
        sweep = self.long_sweep(row)
        if sweep is None: return
        if not (float(row['Close']) > sweep and bool(row.get('bull_displacement', False)) and bool(row.get('bull_fvg', False))): return
        score = self.score_long(row)
        if score < float(getattr(args, 'min_ict_payout_score', 4.0)): return
        fvg_low, fvg_high = float(row['bull_fvg_low']), float(row['bull_fvg_high']); ce = (fvg_low + fvg_high) / 2
        atrv = float(row['atr14']) if pd.notna(row.get('atr14')) else 0.0
        stop = float(row['Low']) - atrv*float(getattr(args, 'stop_buffer_atr', 0.15))
        if stop >= ce: return
        self.pending[symbol] = PendingFVG('LONG', i+int(getattr(args,'fvg_expiry_bars',20)), sweep, float(row['Low']), fvg_low, fvg_high, ce, stop, score, 'bull_sweep_reclaim_displacement_fvg')

    def arm_short(self, symbol, row, i, args):
        sweep = self.short_sweep(row)
        if sweep is None: return
        if not (float(row['Close']) < sweep and bool(row.get('bear_displacement', False)) and bool(row.get('bear_fvg', False))): return
        score = self.score_short(row)
        if score < float(getattr(args, 'min_ict_payout_score', 4.0)): return
        fvg_low, fvg_high = float(row['bear_fvg_low']), float(row['bear_fvg_high']); ce = (fvg_low + fvg_high) / 2
        atrv = float(row['atr14']) if pd.notna(row.get('atr14')) else 0.0
        stop = float(row['High']) + atrv*float(getattr(args, 'stop_buffer_atr', 0.15))
        if stop <= ce: return
        self.pending[symbol] = PendingFVG('SHORT', i+int(getattr(args,'fvg_expiry_bars',20)), sweep, float(row['High']), fvg_low, fvg_high, ce, stop, score, 'bear_sweep_reclaim_displacement_fvg')

    def pending_order(self, symbol, p, row, args) -> Optional[OrderPlan]:
        target_r = float(getattr(args, 'target_r', 5.0)); entry_mode = str(getattr(args, 'entry_mode', 'ce')).lower()
        touched = float(row['Low']) <= p.fvg_high and float(row['High']) >= p.fvg_low
        if not touched: return None
        if p.direction == 'LONG':
            entry = p.fvg_ce if entry_mode == 'ce' else min(float(row['Close']), p.fvg_high)
            stop = min(p.stop, p.sweep_extreme - 0.25); risk = entry - stop
            if risk <= 0: return None
            return OrderPlan(symbol, 'LONG', float(entry), float(stop), float(entry + risk*target_r), 'ict_payout_cycle_long', p.reason, self.name, p.setup_score)
        if p.direction == 'SHORT':
            entry = p.fvg_ce if entry_mode == 'ce' else max(float(row['Close']), p.fvg_low)
            stop = max(p.stop, p.sweep_extreme + 0.25); risk = stop - entry
            if risk <= 0: return None
            return OrderPlan(symbol, 'SHORT', float(entry), float(stop), float(entry - risk*target_r), 'ict_payout_cycle_short', p.reason, self.name, p.setup_score)
        return None

    def signal_for_row(self, symbol: str, row: pd.Series, history: pd.DataFrame, spec: SymbolSpec, profile: PropProfile, args):
        i = len(history) - 1
        if i < int(getattr(args, 'warmup_bars', 500)): return None
        p = self.state(symbol)
        if p.direction and i > p.expiry_index:
            self.pending[symbol] = PendingFVG(); p = self.pending[symbol]
        if p.direction:
            order = self.pending_order(symbol, p, row, args)
            if order is not None: self.pending[symbol] = PendingFVG(); return order
            return None
        if not bool(row.get('is_valid_entry_window', False)): return None
        if bool(row.get('bull_htf_bias', False)): self.arm_long(symbol, row, i, args)
        if bool(row.get('bear_htf_bias', False)): self.arm_short(symbol, row, i, args)
        return None
