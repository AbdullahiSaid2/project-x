
from __future__ import annotations
import argparse, sys
from dataclasses import replace
from pathlib import Path
from typing import Dict
import pandas as pd
ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path: sys.path.insert(0, str(ROOT))
from src.data.fetcher import get_ohlcv
from src.backtesting.event_engine.defaults import SYMBOL_SPECS, PROP_PROFILES
from src.backtesting.event_engine.models import Position
from src.backtesting.event_engine.time_rules import to_et, is_allowed_futures_time, should_force_flat, session_date, load_news_events, news_blackout_status
from src.strategies.adapters.ict_payout_cycle_event_adapter import ICTPayoutCycleAdapter
OUT_DIR = Path('src/backtesting/event_engine/outputs'); OUT_DIR.mkdir(parents=True, exist_ok=True)

def patch_profile(p,args):
    updates={}
    for a,k,t in [('risk_per_trade','risk_per_trade',float),('daily_profit_target','daily_profit_target',float),('daily_soft_loss_stop','daily_soft_loss_stop',float),('max_trades_per_day','max_trades_per_day',int),('pause_after_consecutive_losses','pause_after_consecutive_losses',int)]:
        v=getattr(args,a,None)
        if v is not None: updates[k]=t(v)
    return replace(p, **updates) if updates else p

def contracts(profile,spec,entry,stop):
    rpc=abs(entry-stop)*spec.dollars_per_point
    if rpc<=0: return 0,rpc,0
    n=int(profile.risk_per_trade//rpc)
    return (n,rpc,rpc*n) if n>=1 else (0,rpc,0)

def unreal(pos,spec,mark):
    pts=(mark-pos.entry_price) if pos.side=='LONG' else (pos.entry_price-mark)
    return pts*spec.dollars_per_point*pos.size

def close(pos,spec,ts,row,price,reason,comm):
    pts=(price-pos.entry_price) if pos.side=='LONG' else (pos.entry_price-price)
    gross=pts*spec.dollars_per_point*pos.size; fees=comm*2*pos.size; net=gross-fees
    return {'strategy_name':pos.strategy_name,'symbol':pos.symbol,'side':pos.side,'size':pos.size,'entry_time_et':to_et(pos.entry_time),'exit_time_et':to_et(ts),'entry_price':pos.entry_price,'exit_price':price,'realized_points':pts,'dollars_per_point':spec.dollars_per_point,'gross_pnl_dollars':gross,'commissions_dollars':fees,'net_pnl_dollars':net,'trade_type':pos.trade_type,'exit_reason':reason,'planned_risk_dollars':pos.planned_risk_dollars,'planned_target_dollars':pos.planned_target_dollars,'same_bar_exit':False}

def flatten(positions,data,ts,reason,comm):
    out=[]
    for sym in list(positions.keys()):
        if ts not in data[sym].index: continue
        row=data[sym].loc[ts]; out.append(close(positions[sym], SYMBOL_SPECS[sym], ts, row, float(row['Close']), reason, comm)); del positions[sym]
    return out

def maybe_exit(pos,spec,ts,idx,row,comm):
    if idx<=pos.entry_bar_index: return None
    h,l=float(row['High']),float(row['Low'])
    if pos.side=='LONG':
        if l<=pos.stop_price: return close(pos,spec,ts,row,pos.stop_price,'stop_loss',comm)
        if h>=pos.target_price: return close(pos,spec,ts,row,pos.target_price,'take_profit',comm)
    else:
        if h>=pos.stop_price: return close(pos,spec,ts,row,pos.stop_price,'stop_loss',comm)
        if l<=pos.target_price: return close(pos,spec,ts,row,pos.target_price,'take_profit',comm)
    return None

def parse_args():
    p=argparse.ArgumentParser()
    p.add_argument('--symbols',nargs='+',default=['MNQ','MES','MYM','MGC']); p.add_argument('--prop-profile',default='apex_50k_pa',choices=list(PROP_PROFILES.keys()))
    p.add_argument('--days-back',type=int,default=365); p.add_argument('--timeframe',default='1m'); p.add_argument('--tail-rows',type=int,default=180000); p.add_argument('--no-tail',action='store_true')
    p.add_argument('--commission-per-contract-side',type=float,default=2.0); p.add_argument('--target-r',type=float,default=5.0); p.add_argument('--min-planned-target-dollars',type=float,default=500.0)
    p.add_argument('--news-events',default=''); p.add_argument('--output-prefix',default='ict_payout_cycle')
    p.add_argument('--min-ict-payout-score',type=float,default=4.0); p.add_argument('--fvg-expiry-bars',type=int,default=20); p.add_argument('--stop-buffer-atr',type=float,default=0.15); p.add_argument('--entry-mode',default='ce',choices=['ce','close']); p.add_argument('--warmup-bars',type=int,default=500)
    p.add_argument('--risk-per-trade',type=float,default=150); p.add_argument('--daily-profit-target',type=float,default=650); p.add_argument('--daily-soft-loss-stop',type=float,default=350); p.add_argument('--max-trades-per-day',type=int,default=6); p.add_argument('--pause-after-consecutive-losses',type=int,default=2); p.add_argument('--disable-unrealized-daily-lock',action='store_true')
    return p.parse_args()

def main():
    args=parse_args(); adapter=ICTPayoutCycleAdapter(); profile=patch_profile(PROP_PROFILES[args.prop_profile],args); news=load_news_events(args.news_events) if profile.news_blackout_enabled else pd.DataFrame()
    data={}; idxmaps={}; symbols=[s.upper() for s in args.symbols]
    print('Loading data and building ICT Payout Cycle features...')
    for sym in symbols:
        print(f'\n=== loading {sym} ==='); df=get_ohlcv(sym,exchange='tradovate',timeframe=args.timeframe,days_back=args.days_back)
        if not args.no_tail: df=df.tail(args.tail_rows)
        df=adapter.build_features(sym,df); data[sym]=df; idxmaps[sym]={ts:i for i,ts in enumerate(df.index)}; print(f'{sym}: rows={len(df)} start={df.index.min()} end={df.index.max()}')
    times=sorted(set().union(*[set(df.index) for df in data.values()])); print(f'\nRunning {adapter.name} over {len(times)} timestamps...')
    pos:Dict[str,Position]={}; trades=[]; rejects=[]; daily=[]; bal=profile.account_size; peak=bal; eod_peak=bal; floor=profile.account_size-profile.max_drawdown
    session=None; day_pnl=0.0; day_trades=0; consec_losses=0; locked=False; lock_reason=''
    def rec(tr):
        nonlocal bal, day_pnl, peak, consec_losses
        trades.append(tr); pnl=float(tr['net_pnl_dollars']); bal+=pnl; day_pnl+=pnl; peak=max(peak,bal); consec_losses=consec_losses+1 if pnl<0 else 0
    def new_session(sess):
        nonlocal session, day_pnl, day_trades, consec_losses, locked, lock_reason, eod_peak, floor
        if session is not None:
            eod_peak=max(eod_peak,bal); nf=eod_peak-profile.max_drawdown
            if profile.drawdown_stop_level is not None: nf=min(nf,profile.drawdown_stop_level)
            floor=max(floor,nf)
            daily.append({'session_date':session,'balance':bal,'daily_net_pnl':day_pnl,'daily_trades':day_trades,'eod_peak_balance':eod_peak,'drawdown_floor':floor,'day_locked':locked,'day_lock_reason':lock_reason})
        session=sess; day_pnl=0.0; day_trades=0; consec_losses=0; locked=False; lock_reason=''
    for ts in times:
        et=to_et(ts); sess=session_date(et,reopen_time=profile.reopen_time_et)
        if sess!=session: new_session(sess)
        in_news,_=news_blackout_status(et,news,profile.news_minutes_before,profile.news_minutes_after) if profile.news_blackout_enabled else (False,'')
        force=should_force_flat(et,flatten_time=profile.flatten_time_et) or not is_allowed_futures_time(et,flatten_time=profile.flatten_time_et,reopen_time=profile.reopen_time_et)
        if in_news and profile.flatten_before_news: force=True
        if force and pos:
            for tr in flatten(pos,data,ts,'force_flat_news' if in_news else 'force_flat_session',args.commission_per_contract_side): rec(tr)
        for sym in list(pos.keys()):
            if ts not in data[sym].index: continue
            row=data[sym].loc[ts]; tr=maybe_exit(pos[sym],SYMBOL_SPECS[sym],ts,idxmaps[sym][ts],row,args.commission_per_contract_side)
            if tr: rec(tr); del pos[sym]
        open_u=sum(unreal(p,SYMBOL_SPECS[sym],float(data[sym].loc[ts]['Close'])) for sym,p in pos.items() if ts in data[sym].index)
        eq_day=day_pnl+open_u
        if not args.disable_unrealized_daily_lock and pos:
            if profile.daily_profit_target is not None and eq_day>=profile.daily_profit_target:
                for tr in flatten(pos,data,ts,'daily_equity_profit_lock',args.commission_per_contract_side): rec(tr)
                locked=True; lock_reason='daily_equity_profit_lock'
            elif profile.daily_soft_loss_stop is not None and eq_day<=-abs(profile.daily_soft_loss_stop):
                for tr in flatten(pos,data,ts,'daily_equity_soft_loss_lock',args.commission_per_contract_side): rec(tr)
                locked=True; lock_reason='daily_equity_soft_loss_lock'
        if profile.daily_loss_limit is not None and day_pnl<=-abs(profile.daily_loss_limit): locked=True; lock_reason='daily_loss_limit'
        if profile.daily_soft_loss_stop is not None and day_pnl<=-abs(profile.daily_soft_loss_stop): locked=True; lock_reason='daily_soft_loss_stop'
        if profile.daily_profit_target is not None and day_pnl>=profile.daily_profit_target: locked=True; lock_reason='daily_profit_target'
        if profile.max_trades_per_day is not None and day_trades>=profile.max_trades_per_day: locked=True; lock_reason='max_trades_per_day'
        if profile.pause_after_consecutive_losses is not None and consec_losses>=profile.pause_after_consecutive_losses: locked=True; lock_reason='consecutive_losses'
        if bal<=floor: locked=True; lock_reason='max_drawdown_breach'
        if force or locked or in_news: continue
        for sym in symbols:
            if sym in pos or ts not in data[sym].index: continue
            df=data[sym]; i=idxmaps[sym][ts]; row=df.iloc[i]; order=adapter.signal_for_row(sym,row,df.iloc[:i+1],SYMBOL_SPECS[sym],profile,args)
            if order is None: continue
            n,rpc,pr=contracts(profile,SYMBOL_SPECS[sym],order.entry_price,order.stop_price)
            if n<1:
                rejects.append({'timestamp_et':et,'symbol':sym,'reject_reason':'risk_too_large_for_one_contract','trade_type':order.trade_type,'risk_per_contract':rpc,'setup_score':order.setup_score}); continue
            pt=abs(order.target_price-order.entry_price)*SYMBOL_SPECS[sym].dollars_per_point*n
            if pt<args.min_planned_target_dollars:
                rejects.append({'timestamp_et':et,'symbol':sym,'reject_reason':'planned_target_too_small','trade_type':order.trade_type,'planned_target_dollars':pt,'setup_score':order.setup_score}); continue
            pos[sym]=Position(sym,order.side,n,order.entry_price,order.stop_price,order.target_price,ts,i,order.trade_type,order.strategy_name,pr,pt); day_trades+=1
    for sym in list(pos.keys()):
        df=data[sym]; ts=df.index[-1]; row=df.iloc[-1]; rec(close(pos[sym],SYMBOL_SPECS[sym],ts,row,float(row['Close']),'end_of_test',args.commission_per_contract_side)); del pos[sym]
    new_session(None)
    tdf=pd.DataFrame(trades); rdf=pd.DataFrame(rejects); ddf=pd.DataFrame(daily); prefix=args.output_prefix
    out_trade=OUT_DIR/f'{prefix}_event_trade_log.csv'; out_rej=OUT_DIR/f'{prefix}_event_rejected_signals.csv'; out_day=OUT_DIR/f'{prefix}_event_daily_summary.csv'
    tdf.to_csv(out_trade,index=False); rdf.to_csv(out_rej,index=False); ddf.to_csv(out_day,index=False)
    gross=tdf['gross_pnl_dollars'].sum() if not tdf.empty else 0.0; fees=tdf['commissions_dollars'].sum() if not tdf.empty else 0.0; net=tdf['net_pnl_dollars'].sum() if not tdf.empty else 0.0
    print('\n================ ICT PAYOUT CYCLE FINAL REPORT ================')
    print(f'Strategy:                 {adapter.name}'); print(f'Profile:                  {profile.name}'); print(f'Risk per trade:            ${profile.risk_per_trade:,.2f}'); print(f'Daily profit target:       {profile.daily_profit_target}'); print(f'Daily soft loss stop:      {profile.daily_soft_loss_stop}'); print(f'Target R:                  {args.target_r}'); print(f'Trades:                   {len(tdf)}'); print(f'Gross PnL:                ${gross:,.2f}'); print(f'Commissions:              ${fees:,.2f}'); print(f'Net PnL:                  ${net:,.2f}'); print(f'Final balance:            ${profile.account_size+net:,.2f}'); print(f'Rejected signals:         {len(rdf)}')
    if not tdf.empty:
        by=tdf.groupby('symbol').agg(trades=('net_pnl_dollars','size'),net_pnl_dollars=('net_pnl_dollars','sum'),avg_trade=('net_pnl_dollars','mean'),median_trade=('net_pnl_dollars','median'),win_rate_pct=('net_pnl_dollars',lambda s:(s>0).mean()*100),worst_trade=('net_pnl_dollars','min'),best_trade=('net_pnl_dollars','max')).reset_index().sort_values('net_pnl_dollars',ascending=False); print('\nBy symbol:'); print(by.to_string(index=False))
    if not ddf.empty: print('\nDaily lock counts:'); print(ddf['day_lock_reason'].fillna('').replace('', 'none').value_counts().to_string())
    print('\nWrote files:'); print(f'  {out_trade}'); print(f'  {out_rej}'); print(f'  {out_day}')
if __name__=='__main__': main()
